package com.example.livesignalassistant

import android.app.*
import android.content.*
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.hardware.display.*
import android.media.ImageReader
import android.media.projection.*
import android.os.*
import android.provider.Settings
import android.view.*
import android.widget.*
import androidx.core.app.NotificationCompat
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean
import java.util.UUID
import kotlin.math.*

class CaptureService:Service(){
 companion object{const val EXTRA_RESULT_CODE="result_code";const val EXTRA_RESULT_DATA="result_data";const val ACTION_EXPORT="lsa.export";private const val CHANNEL="lsa_v70";private const val NID=1700}
 private var projection:MediaProjection?=null;private var reader:ImageReader?=null;private var display:VirtualDisplay?=null
 private var wm:WindowManager?=null;private var brain:TextView?=null;private val bubbles=mutableListOf<View>();private val main=Handler(Looper.getMainLooper());private val worker=Executors.newSingleThreadExecutor();private val evidenceWorker=Executors.newSingleThreadExecutor();private val busy=AtomicBoolean(false)
 private lateinit var memory:MemoryStore;private lateinit var experience:ExperienceStore;private var lastFrameAt=0L;private var lastEvidenceAt=0L;private var cycleStart=SystemClock.elapsedRealtime();private var nextDecisionAt=cycleStart+90000L;private var nextObservationAt=cycleStart+1000L;private val observations=mutableListOf<SignalResult>();private var cycle=1
 override fun onCreate(){super.onCreate();memory=MemoryStore(this);experience=ExperienceStore(this);channel();startForeground(NID,NotificationCompat.Builder(this,CHANNEL).setContentTitle("90S Vision Brain · 2M/3M").setContentText("80s deep vision · 10s final verify · 2m/3m expiry").setSmallIcon(android.R.drawable.ic_menu_view).setOngoing(true).build());memory.event("SESSION_START")}
 override fun onStartCommand(i:Intent?,f:Int,id:Int):Int{
  if(i?.action==ACTION_EXPORT){val p=memory.exportZip();Toast.makeText(this,"Memory exported: $p",Toast.LENGTH_LONG).show();return START_NOT_STICKY}
  if(!Settings.canDrawOverlays(this)){stopSelf();return START_NOT_STICKY};showBrain();val code=i?.getIntExtra(EXTRA_RESULT_CODE,Activity.RESULT_CANCELED)?:Activity.RESULT_CANCELED;val data:Intent?=if(Build.VERSION.SDK_INT>=33)i?.getParcelableExtra(EXTRA_RESULT_DATA,Intent::class.java) else @Suppress("DEPRECATION") i?.getParcelableExtra(EXTRA_RESULT_DATA)
  if(code!=Activity.RESULT_OK||data==null){stopSelf();return START_NOT_STICKY};if(projection!=null)return START_NOT_STICKY;val mgr=getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager;projection=mgr.getMediaProjection(code,data);projection?.registerCallback(object:MediaProjection.Callback(){override fun onStop(){stopSelf()}},main);startCapture();return START_NOT_STICKY
 }
 private fun glass(stroke:Int=0x55FFFFFF)=GradientDrawable().apply{setColor(0xB8FFFFFF.toInt());cornerRadius=42f;setStroke(2,stroke)}
 private fun showBrain(){main.post{if(brain!=null)return@post;wm=getSystemService(WINDOW_SERVICE) as WindowManager;val v=TextView(this).apply{text="90S VISION · 2M/3M\ncycle 1";textSize=13f;setTextColor(Color.BLACK);gravity=Gravity.CENTER;setPadding(18,12,18,12);background=glass();elevation=16f};val lp=params(Gravity.TOP or Gravity.END,18,190);wm!!.addView(v,lp);brain=v}}
 private fun params(g:Int,x:Int,y:Int)=WindowManager.LayoutParams(WindowManager.LayoutParams.WRAP_CONTENT,WindowManager.LayoutParams.WRAP_CONTENT,if(Build.VERSION.SDK_INT>=26)WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,PixelFormat.TRANSLUCENT).apply{gravity=g;this.x=x;this.y=y}
 private fun startCapture(){val m=resources.displayMetrics;reader=ImageReader.newInstance(m.widthPixels,m.heightPixels,PixelFormat.RGBA_8888,2);display=projection?.createVirtualDisplay("LSA70",m.widthPixels,m.heightPixels,m.densityDpi,DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,reader!!.surface,null,main);reader?.setOnImageAvailableListener({r->val now=SystemClock.elapsedRealtime();val im=r.acquireLatestImage()?:return@setOnImageAvailableListener;if(now-lastFrameAt<250||busy.get()){im.close();return@setOnImageAvailableListener};lastFrameAt=now;busy.set(true);try{val p=im.planes[0];val pad=p.rowStride-p.pixelStride*im.width;val tmp=Bitmap.createBitmap(im.width+pad/p.pixelStride,im.height,Bitmap.Config.ARGB_8888);tmp.copyPixelsFromBuffer(p.buffer);val b=Bitmap.createBitmap(tmp,0,0,im.width,im.height);tmp.recycle();worker.execute{try{processFrame(b,now)}finally{b.recycle();busy.set(false)}}}catch(_:Throwable){busy.set(false)}finally{im.close()}},main)}
 private fun recordFrameAsync(b:Bitmap,tag:String){
  val copy=b.copy(Bitmap.Config.ARGB_8888,false)
  evidenceWorker.execute{try{memory.frame(copy,tag)}catch(t:Throwable){memory.event("RECORDER_ERROR",mapOf("message" to (t.message?:t.javaClass.simpleName)))}finally{copy.recycle()}}
 }
 private fun processFrame(b:Bitmap,now:Long){
  // Black-box screenshots are sampled every 3s; analysis still runs at its normal cadence.
  // This cuts session storage sharply without weakening the live analyzer.
  if(now-lastEvidenceAt>=3000L){recordFrameAsync(b,"observe");lastEvidenceAt=now}
  val elapsed=now-cycleStart
  // 1M path clock: one analyzed observation each second. Capture itself may run faster;
  // decision timing is monotonic and independent from frame-arrival jitter.
  if(now>=nextObservationAt && now<nextDecisionAt){
   val raw=SignalAnalyzer.analyze(b);val r=raw.copy(diagnostics=raw.diagnostics+mapOf("cycle_elapsed_ms" to elapsed,"observation_mono_ms" to now));synchronized(observations){observations+=r}
   memory.event("BOT_OBSERVATION",mapOf("cycle" to cycle,"cycle_elapsed_ms" to elapsed,"phase" to if(elapsed<80000L)"DEEP_OBSERVATION" else "FINAL_WINDOW","direction" to r.direction,"expiry_s" to r.expirySeconds,"raw_confidence" to r.confidence,"entry" to r.entryQuality,"conflict" to r.conflict,"reason" to r.reason,"up" to r.upScore,"down" to r.downScore,"diagnostics" to r.diagnostics))
   do{nextObservationAt+=1000L}while(nextObservationAt<=now)
  }
  val left=max(0,((nextDecisionAt-now+999)/1000).toInt())
   val phase=if(elapsed<80000L)"DEEP OBSERVATION" else "FINAL DECISION"
   main.post{brain?.text="90S VISION · $phase ${left}s\n2M/3M · cycle $cycle"}
  if(now>=nextDecisionAt){
   finishCycle(b,nextDecisionAt)
   // Anchor cycles to the monotonic schedule, never to a late frame; this prevents cumulative drift.
   val late=now-nextDecisionAt
    // If Android was paused long enough to miss a boundary, skip stale cycles instead of emitting catch-up signals.
    cycleStart=nextDecisionAt
    nextDecisionAt+=90000L
    if(late>=90000L){
     val skipped=late/90000L
     cycleStart+=skipped*90000L
     nextDecisionAt=cycleStart+90000L
     memory.event("STALE_CYCLES_SKIPPED",mapOf("count" to skipped,"late_ms" to late))
    }
    nextObservationAt=cycleStart+1000L;cycle++
   synchronized(observations){observations.clear()}
  }
 }
 private fun finishCycle(b:Bitmap,boundaryMono:Long){
   val list=synchronized(observations){observations.toList()}
   val visionGood=list.filter{((it.diagnostics["vision_coverage"] as? Number)?.toDouble()?:0.0)>=.42 && ((it.diagnostics["vision_continuity"] as? Number)?.toDouble()?:0.0)>=.72}
   // V2 evidence engine: WAIT observations are still market evidence. We aggregate the
   // independent 2M/3M directional score edges from every vision-valid observation instead
   // of counting only observations that already crossed the per-frame publish threshold.
   val usable=visionGood.filter{
    fun q(k:String)=((it.diagnostics[k] as? Number)?.toDouble())
    q("score_2m_up")!=null&&q("score_2m_down")!=null&&q("score_3m_up")!=null&&q("score_3m_down")!=null
   }
   fun w(i:Int,n:Int):Double{val x=(i+1).toDouble()/n.coerceAtLeast(1);return .42+.58*x*x}
   data class Key(val side:String,val exp:Int)
   val support=mutableMapOf<Key,Double>()
   fun q(r:SignalResult,k:String)=((r.diagnostics[k] as? Number)?.toDouble())?:50.0
   usable.forEachIndexed{i,r->
    val vw=((r.diagnostics["vision_coverage"] as? Number)?.toDouble()?:0.0).coerceIn(.35,1.0)
    fun add(exp:Int,upK:String,dnK:String){
     val up=q(r,upK);val dn=q(r,dnK);val edge=up-dn
     val strength=(abs(edge)/18.0).coerceIn(0.0,1.8)*vw*w(i,usable.size)
     if(edge>0)support[Key("UP",exp)]=(support[Key("UP",exp)]?:0.0)+strength
     else if(edge<0)support[Key("DOWN",exp)]=(support[Key("DOWN",exp)]?:0.0)+strength
    }
    add(120,"score_2m_up","score_2m_down");add(180,"score_3m_up","score_3m_down")
   }
   val ranked=support.entries.sortedByDescending{it.value}
   val best=ranked.firstOrNull();val second=ranked.getOrNull(1)
   val total=support.values.sum();val consistency=if(best==null||total<=0.0)0.0 else best.value/total
   val chosen=if(best==null) emptyList() else usable.filter{r->
    val edge=if(best.key.exp==120) q(r,"score_2m_up")-q(r,"score_2m_down") else q(r,"score_3m_up")-q(r,"score_3m_down")
    if(best.key.side=="UP")edge>0 else edge<0
   }
   val recentSides=usable.takeLast(min(16,usable.size)).map{r->
    val e=(q(r,"score_2m_up")+q(r,"score_3m_up"))-(q(r,"score_2m_down")+q(r,"score_3m_down"))
    if(e>4)1 else if(e< -4)-1 else 0
   }.filter{it!=0}
   val flips=recentSides.zipWithNext().count{(a,c)->a!=c}
   fun d(r:SignalResult,k:String)=((r.diagnostics[k] as? Number)?.toDouble())
   data class Pt(val t:Long,val p:Double,val floor:Double)
   val path=list.mapNotNull{r->val t=(r.diagnostics["observation_mono_ms"] as? Number)?.toLong();val pr=d(r,"trace_right");val fl=d(r,"trace_floor");if(t!=null&&pr!=null&&fl!=null)Pt(t,pr,fl.coerceAtLeast(.01))else null}
   fun tail(sec:Int)=if(path.isEmpty()) emptyList() else path.filter{it.t>=path.last().t-sec*1000L}
   fun slope(q:List<Pt>):Double{if(q.size<2)return 0.0;val dt=((q.last().t-q.first().t).coerceAtLeast(1))/1000.0;val fl=q.map{it.floor}.average().coerceAtLeast(.01);return(q.last().p-q.first().p)/(fl*dt)}
   val s3=slope(tail(3));val s6=slope(tail(6));val s10=slope(tail(10));val s20=slope(tail(20));val s40=slope(tail(40));val s80=slope(tail(80))
   val finalSign=when{(.45*s3+.30*s6+.25*s10)>.035->1;(.45*s3+.30*s6+.25*s10)<-.035->-1;else->0}
   val proposed=best?.key?.side?:"WAIT";val proposedSign=if(proposed=="UP")1 else if(proposed=="DOWN")-1 else 0
   val counter=max(0.0,-proposedSign*(.45*s3+.30*s6+.25*s10));val decay=max(0.0,proposedSign*s40-proposedSign*s6);val jerk=(s3-s6)-(s10-s20)
   val finalOpposes=proposedSign!=0&&finalSign==-proposedSign&&counter>.055&&listOf(s3,s6,s10).count{if(finalSign>0)it>.02 else it<-.02}>=2
   val deterministic=if(finalOpposes)"WAIT" else proposed
   val expiry=best?.key?.exp?:120
   val expFeatures=mapOf<String,Any?>("expiry_s" to expiry,"counter_magnitude" to counter,"persistence_decay" to decay,"trajectory_jerk" to jerk,"slope_6s" to s6,"slope_20s" to s20,"recent_direction_flips" to flips,"trend_regime" to if(abs(s40)>.035)1.0 else 0.0,"range_regime" to if(abs(s40)<=.035)1.0 else 0.0)
   val advice=experience.advise(proposed,if(finalSign>0)"UP" else if(finalSign<0)"DOWN" else "WAIT",deterministic,expFeatures)
   val side=advice.side
   val visionRatio=visionGood.size.toDouble()/list.size.coerceAtLeast(1)
   val separation=if(best==null)0.0 else best.value-(second?.value?:0.0)
   val evidenceCoverage=usable.size.toDouble()/list.size.coerceAtLeast(1)
   // Require a genuinely observed cycle, coherent edge and a stable final window, but do not
   // demand that individual frames had already emitted UP/DOWN.
   val enough=list.size>=55 && visionRatio>=.62 && evidenceCoverage>=.55 && chosen.size>=18 && consistency>=.30 && separation>=1.25 && flips<=7
   val result=if(side!="WAIT"&&enough){
    val rep=(chosen.takeLast(min(18,chosen.size)).maxByOrNull{r->
     val edge=if(expiry==120)abs(q(r,"score_2m_up")-q(r,"score_2m_down")) else abs(q(r,"score_3m_up")-q(r,"score_3m_down"))
     edge+r.entryQuality*.12-r.conflict*.08
    }?:chosen.last())
    rep.copy(direction=side,expirySeconds=expiry,confidence=-1,diagnostics=rep.diagnostics+expFeatures+mapOf(
     "cycle_mode" to "90S_80_PLUS_10_2M3M_V2","vision_good_ratio" to visionRatio,"evidence_coverage" to evidenceCoverage,"path_consistency" to consistency,"path_usable" to usable.size,"path_chosen" to chosen.size,"support_separation" to separation,
     "slope_3s" to s3,"slope_6s" to s6,"slope_10s" to s10,"slope_20s" to s20,"slope_40s" to s40,"slope_80s" to s80,"final_veto" to finalOpposes,
     "base_side" to proposed,"final_recent_side" to (if(finalSign>0)"UP" else if(finalSign<0)"DOWN" else "WAIT"),"experience_applied" to advice.applied,"experience_samples" to advice.samples,"experience_delta" to advice.learnedDelta,"experience_key" to advice.key))
   }else SignalResult("WAIT",expiry,-1,reason=when{visionRatio<.62->"VISION_NOT_TRUSTED";evidenceCoverage<.55->"TOO_LITTLE_EVIDENCE";finalOpposes->"FINAL_WINDOW_VETO";flips>7->"PATH_UNSTABLE";separation<1.25->"HORIZON_DIRECTION_AMBIGUOUS";else->"CYCLE_INCOHERENT"})
   recordFrameAsync(b,"decision")
   val actual=SystemClock.elapsedRealtime();memory.event("NINETY_SECOND_DECISION",mapOf("cycle" to cycle,"cycle_mode" to "90S_80_PLUS_10_2M3M_V2","scheduled_boundary_mono_ms" to boundaryMono,"actual_decision_mono_ms" to actual,"decision_latency_ms" to (actual-boundaryMono).coerceAtLeast(0),"direction" to result.direction,"expiry_s" to result.expirySeconds,"observations" to list.size,"vision_good" to visionGood.size,"usable" to usable.size,"consistency" to consistency,"support_separation" to separation,"recent_flips" to flips,"reason" to result.reason,"diagnostics" to result.diagnostics))
   main.post{brain?.text=if(result.direction=="WAIT")"WAIT · 90S VISION\ncycle $cycle" else "${if(result.direction=="UP")"↑" else "↓"} ${result.direction} · ${result.expirySeconds/60}m\nFINAL";if(result.direction!="WAIT")spawn(result)}
  }
 private fun dp(v:Int)=(v*resources.displayMetrics.density).roundToInt()
 private fun spawn(r:SignalResult){
  val manager=wm?:return;val arrow=if(r.direction=="UP")"↑" else "↓";val signalId=UUID.randomUUID().toString()
  val percentText=if(r.signalQuality>0)"SCORE ${r.signalQuality}" else "SCORE --"
  val v=TextView(this).apply{text="$arrow ${r.direction} · ${r.expirySeconds/60}m · $percentText\nOPEN";textSize=11f;setTextColor(Color.BLACK);gravity=Gravity.CENTER;setPadding(dp(8),dp(5),dp(8),dp(5));background=glass();elevation=18f}
  val lp=params(Gravity.TOP or Gravity.START,dp(4),dp(120)+bubbles.size*dp(52));manager.addView(v,lp);bubbles+=v;restack()
  memory.event("SIGNAL_PUBLISHED",mapOf("signal_id" to signalId,"direction" to r.direction,"expiry_s" to r.expirySeconds,"confidence_state" to "CALIBRATING","model_score" to r.signalQuality,"auto_expire_s" to 15,"diagnostics" to r.diagnostics));var locked=false
  val expire=Runnable{if(!locked){memory.event("SIGNAL_NOT_EXECUTED_TIMEOUT",mapOf("signal_id" to signalId,"direction" to r.direction,"expiry_s" to r.expirySeconds,"model_score" to r.signalQuality,"visible_for_s" to 15));try{manager.removeView(v)}catch(_:Throwable){};bubbles.remove(v);restack()}}
  main.postDelayed(expire,15000L)
  v.setOnClickListener{if(locked)return@setOnClickListener;locked=true;main.removeCallbacks(expire);val startedNs=SystemClock.elapsedRealtimeNanos();val targetNs=startedNs+r.expirySeconds*1_000_000_000L;memory.event("TRADE_USER_OPENED",mapOf("signal_id" to signalId,"direction" to r.direction,"expiry_s" to r.expirySeconds,"entry_mono_ns" to startedNs,"target_mono_ns" to targetNs,"model_score" to r.signalQuality));fun tick(){val nowNs=SystemClock.elapsedRealtimeNanos();val remainNs=(targetNs-nowNs).coerceAtLeast(0L);if(remainNs>0){val cs=(remainNs/10_000_000L);val sec=cs/100;val hundredths=cs%100;v.text="$arrow ${r.direction} · $percentText\nLOCKED · ${sec}.${hundredths.toString().padStart(2,'0')}s";main.postDelayed({tick()},10)}else{memory.event("EXPIRY_CLOCK",mapOf("signal_id" to signalId,"target_mono_ns" to targetNs,"actual_mono_ns" to nowNs,"timer_error_ns" to (nowNs-targetNs).coerceAtLeast(0L)));showResultButtons(v,r,signalId)}};tick()}
 }
 private fun showResultButtons(old:TextView,r:SignalResult,signalId:String){val manager=wm?:return;val lp=old.layoutParams as WindowManager.LayoutParams;try{manager.removeView(old)}catch(_:Throwable){};bubbles.remove(old);val row=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;background=glass();setPadding(8,6,8,6)};fun btn(t:String){row.addView(Button(this).apply{text=t;textSize=10f;setOnClickListener{
   memory.event("TRADE_RESULT",mapOf("signal_id" to signalId,"result" to t,"direction" to r.direction,"expiry_s" to r.expirySeconds,"model_score" to r.signalQuality,"diagnostics" to r.diagnostics))
   if(t=="WIN"||t=="LOSS"){
    val base=(r.diagnostics["base_side"] as? String)?:"WAIT"
    val recent=(r.diagnostics["final_recent_side"] as? String)?:"WAIT"
    experience.learn(base,recent,r.direction,t,r.diagnostics)
    val st=experience.stats();memory.event("EXPERIENCE_LEARNED",mapOf("signal_id" to signalId,"result" to t,"lifetime_results" to st.first,"profiles" to st.second))
   }
   try{manager.removeView(row)}catch(_:Throwable){};bubbles.remove(row);restack()
  }})};btn("WIN");btn("LOSS");btn("VOID");manager.addView(row,lp);bubbles+=row;restack();memory.event("RESULT_REQUESTED",mapOf("signal_id" to signalId,"direction" to r.direction,"expiry_s" to r.expirySeconds,"model_score" to r.signalQuality))}
 private fun restack(){bubbles.forEachIndexed{i,v->try{val lp=v.layoutParams as WindowManager.LayoutParams;lp.y=dp(120)+i*dp(52);wm?.updateViewLayout(v,lp)}catch(_:Throwable){}}}
 private fun channel(){if(Build.VERSION.SDK_INT>=26)getSystemService(NotificationManager::class.java).createNotificationChannel(NotificationChannel(CHANNEL,"Live Signal 7.1 Memory",NotificationManager.IMPORTANCE_LOW))}
 override fun onDestroy(){memory.event("SESSION_STOP");reader?.setOnImageAvailableListener(null,null);display?.release();reader?.close();try{projection?.stop()}catch(_:Throwable){};worker.shutdownNow();evidenceWorker.shutdown();main.post{try{brain?.let{wm?.removeView(it)}}catch(_:Throwable){};bubbles.toList().forEach{try{wm?.removeView(it)}catch(_:Throwable){}}};super.onDestroy()}
 override fun onBind(i:Intent?):IBinder?=null
}
