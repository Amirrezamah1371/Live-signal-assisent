package com.example.livesignalassistant

import android.graphics.Bitmap
import android.os.SystemClock
import kotlin.math.*

data class SignalResult(
    val direction:String, val expirySeconds:Int, val confidence:Int,
    val entryQuality:Int=0, val conflict:Int=100, val reason:String="",
    val upScore:Int=0, val downScore:Int=0, val signalQuality:Int=0,
    val diagnostics:Map<String,Any?> = emptyMap()
)

/**
 * 2M/3M VISION SPECIALIST.
 * The eye is deliberately conservative: it extracts the UPPER EDGE of the blue area chart,
 * rejects dominant horizontal UI/price lines, measures continuity, and abstains when vision is weak.
 * Scores are model-strength diagnostics, never win probabilities.
 */
object SignalAnalyzer {
    private data class Eye(val p:List<Double>, val coverage:Double, val continuity:Double, val horizontalRejects:Int, val floor:Double, val kind:String, val anchors:Int)
    private data class H(val sign:Int,val expiry:Int,val score:Double,val entry:Double,val conflict:Double,val reason:String)
    private var lastRight:Double?=null
    private var lastAt=0L
    private var lastVelocity=0.0

    @Synchronized fun reset(){ lastRight=null; lastAt=0L; lastVelocity=0.0 }

    @Synchronized fun analyze(b:Bitmap):SignalResult{
        val eye=extractEye(b) ?: return wait("VISION_REJECT")
        if(eye.p.size<70 || eye.coverage<.42 || eye.continuity<.72) return wait("VISION_WEAK", eye)
        val p=smooth(eye.p,2); val n=p.size
        fun seg(a:Double)=p.subList((n*a).toInt().coerceIn(0,n-3),n)
        val wide=seg(.05); val structure=seg(.28); val entry=seg(.60); val micro=seg(.80)
        val right=median(micro.takeLast(max(3,micro.size/6)))
        val now=SystemClock.elapsedRealtime(); val dt=((now-lastAt).coerceAtLeast(1))/1000.0
        val velocity=lastRight?.let{(right-it)/dt}?:0.0
        val accel=(velocity-lastVelocity)/dt
        lastRight=right; lastVelocity=velocity; lastAt=now

        val candidates=listOf(
            horizon(1,120,wide,structure,entry,micro,eye.floor,velocity,accel),
            horizon(-1,120,wide,structure,entry,micro,eye.floor,velocity,accel),
            horizon(1,180,wide,structure,entry,micro,eye.floor,velocity,accel),
            horizon(-1,180,wide,structure,entry,micro,eye.floor,velocity,accel)
        ).sortedByDescending{it.score}
        val best=candidates[0]; val second=candidates[1]
        val margin=best.score-second.score
        val oppositeSameH=candidates.first{it.expiry==best.expiry && it.sign==-best.sign}
        val directionalMargin=best.score-oppositeSameH.score
        val up=candidates.filter{it.sign>0}.maxOf{it.score}.roundToInt()
        val down=candidates.filter{it.sign<0}.maxOf{it.score}.roundToInt()
        val diag=mapOf<String,Any?>(
            "mode" to "2M_3M_VISION_SPECIALIST","observation_mono_ms" to now,
            "vision_coverage" to eye.coverage,"vision_continuity" to eye.continuity,
            "vision_horizontal_rejects" to eye.horizontalRejects,"trace_points" to eye.p.size,"vision_kind" to eye.kind,"vision_anchors" to eye.anchors,
            "trace_right" to right,"trace_floor" to eye.floor,"velocity" to velocity,"acceleration" to accel,
            "score_2m_up" to candidates.first{it.expiry==120&&it.sign>0}.score,
            "score_2m_down" to candidates.first{it.expiry==120&&it.sign<0}.score,
            "score_3m_up" to candidates.first{it.expiry==180&&it.sign>0}.score,
            "score_3m_down" to candidates.first{it.expiry==180&&it.sign<0}.score,
            "horizon_margin" to margin,"directional_margin" to directionalMargin
        )
        // Strong abstention: no signal from ambiguous eyesight or near-tied horizons/directions.
        if(best.score<66.0 || best.entry<52.0 || best.conflict>52.0 || directionalMargin<8.0 || margin<2.5)
            return SignalResult("WAIT",best.expiry,best.score.roundToInt(),best.entry.roundToInt(),best.conflict.roundToInt(),"EVIDENCE_INSUFFICIENT",up,down,0,diag)
        return SignalResult(if(best.sign>0)"UP" else "DOWN",best.expiry,best.score.roundToInt(),best.entry.roundToInt(),best.conflict.roundToInt(),best.reason,up,down,best.score.roundToInt(),diag)
    }

    private fun extractEye(b:Bitmap):Eye?{
        val candle=extractCandles(b)
        if(candle!=null) return candle
        return extractArea(b)
    }

    /** Detect Pocket Option candle bodies first. This prevents the area/blue extractor from
     * interpreting candles, price lines and controls as one giant trace. */
    private fun extractCandles(b:Bitmap):Eye?{
        val w=b.width; val h=b.height
        if(w<240||h<360)return null
        val x0=(w*.045).toInt(); val x1=(w*.82).toInt(); val y0=(h*.13).toInt(); val y1=(h*.64).toInt()
        data class Hit(val x:Int,val y:Int,val up:Boolean)
        val hits=ArrayList<Hit>()
        for(x in x0 until x1 step 2) for(y in y0 until y1 step 2){
            val c=b.getPixel(x,y); val r=(c shr 16)and 255; val g=(c shr 8)and 255; val bl=c and 255
            val green=g>=105 && g-r>=35 && g-bl>=18
            val red=r>=150 && r-g>=45 && r-bl>=25
            if(green||red) hits+=Hit(x,y,green)
        }
        if(hits.size<90)return null
        val xs=hits.groupBy{it.x}.keys.sorted(); if(xs.size<12)return null
        val runs=ArrayList<List<Int>>(); var cur=ArrayList<Int>(); var last=-999
        for(x in xs){if(cur.isNotEmpty()&&x-last>6){runs+=cur;cur=ArrayList()};cur+=x;last=x};if(cur.isNotEmpty())runs+=cur
        data class C(val x:Double,val close:Double)
        val cs=ArrayList<C>()
        for(run in runs){
            if(run.size<3)continue
            val lo=run.first();val hi=run.last();val q=hits.filter{it.x in lo..hi};if(q.size<18)continue
            val green=q.count{it.up}>=q.size/2; val ys=q.map{it.y}
            // Green candle closes at body top; red closes at body bottom. Robust quantiles ignore thin wicks.
            val sy=ys.sorted(); val closeY=if(green) sy[(sy.size*.12).toInt().coerceIn(0,sy.lastIndex)] else sy[(sy.size*.88).toInt().coerceIn(0,sy.lastIndex)]
            cs+=C((lo+hi)/2.0,-closeY.toDouble())
        }
        if(cs.size<3)return null
        val raw=ArrayList<Double>()
        for(i in 0 until cs.size-1){val a=cs[i];val z=cs[i+1];val n=((z.x-a.x)/2.0).roundToInt().coerceAtLeast(3);for(k in 0 until n){val f=k.toDouble()/n;raw+=a.close+(z.close-a.close)*f}}
        raw+=cs.last().close
        if(raw.size<60){val src=raw.toList();raw.clear();for(i in 0 until 80){val f=i/79.0;val pos=f*(src.size-1);val a=floor(pos).toInt();val z=min(src.lastIndex,a+1);val q=pos-a;raw+=src[a]*(1-q)+src[z]*q}}
        val dif=raw.zipWithNext{a,c->abs(c-a)};val fl=max(h*.0012,median(dif).coerceAtLeast(.65));
        return Eye(raw, min(1.0,hits.size/900.0), .96, 0, fl, "CANDLE", cs.size)
    }

    private fun extractArea(b:Bitmap):Eye?{
        val w=b.width; val h=b.height
        if(w<240||h<360)return null
        val x0=(w*.055).toInt(); val x1=(w*.79).toInt(); val y0=(h*.12).toInt(); val y1=(h*.79).toInt()
        val step=max(2,(x1-x0)/320)
        data class Col(val x:Int,val ys:List<Int>)
        val cols=ArrayList<Col>(); var x=x0
        while(x<x1){
            val edges=ArrayList<Int>(); var y=y0+2; var prevBlue=false
            while(y<y1-2){
                val c=b.getPixel(x,y); val r=(c shr 16)and 255; val g=(c shr 8)and 255; val bl=c and 255
                val blue=bl>=100 && bl-r>=24 && g-r>=5 && bl>=g-12 && r<200
                if(blue && !prevBlue)edges+=y
                prevBlue=blue; y+=2
            }
            if(edges.isNotEmpty())cols+=Col(x,edges)
            x+=step
        }
        val total=((x1-x0)/step).coerceAtLeast(1)
        if(cols.size<total*.35)return null
        // Horizontal UI/current-price lines repeat at almost exactly one y across many columns.
        val hist=HashMap<Int,Int>()
        cols.forEach{c->c.ys.forEach{yy->val k=yy/3;hist[k]=(hist[k]?:0)+1}}
        val bad=hist.filterValues{it>=max(12,(cols.size*.28).toInt())}.keys
        var rejects=0; val raw=ArrayList<Double>(); var prev:Double?=null; var jumps=0; var links=0
        cols.forEach{c->
            val candidates=c.ys.filter{(it/3) !in bad}
            if(candidates.isNotEmpty()){
                // Upper edge is the actual area-chart trace; continuity breaks ties and rejects text/buttons.
                val pick=if(prev==null)candidates.minOrNull()!! else candidates.minByOrNull{yy->abs(yy-prev!!)+max(0,yy-candidates.minOrNull()!!)*.18}!!
                if(prev==null || abs(pick-prev!!)<=h*.085){
                    if(prev!=null){links++;if(abs(pick-prev!!)>h*.025)jumps++}
                    raw+=-pick.toDouble();prev=pick.toDouble()
                }
            } else rejects++
        }
        if(raw.size<60)return null
        val dif=raw.zipWithNext{a,c->abs(c-a)}
        val floor=max(h*.0015,median(dif).coerceAtLeast(1.0)*.90)
        val continuity=(1.0-jumps.toDouble()/links.coerceAtLeast(1)).coerceIn(0.0,1.0)
        return Eye(raw,raw.size.toDouble()/total,continuity,rejects,floor,"AREA",raw.size)
    }

    private fun horizon(sign:Int,e:Int,w:List<Double>,s:List<Double>,en:List<Double>,m:List<Double>,floor:Double,velocity:Double,accel:Double):H{
        fun mv(v:List<Double>,a:Double,b:Double):Double{val n=v.size;val i=(n*a).toInt().coerceIn(0,n-2);val j=(n*b).toInt().coerceIn(i+2,n);val q=max(2,(j-i)/5);return median(v.subList(j-q,j))-median(v.subList(i,i+q))}
        fun al(v:Double,k:Double)=((sign*v)/(floor*k)).coerceIn(-1.0,1.0)
        val wa=al(mv(w,.05,.95),3.8); val sa=al(mv(s,.18,.98),2.8); val ea=al(mv(en,.30,1.0),1.9); val ma=al(mv(m,.35,1.0),1.15)
        val va=al(velocity,1.3); val aa=al(accel,2.4)
        val longWeight=if(e==180).34 else .25; val microWeight=if(e==120).25 else .16
        val positive=max(0.0,wa)*longWeight+max(0.0,sa)*.25+max(0.0,ea)*.24+max(0.0,ma)*microWeight+max(0.0,va)*.06
        val opposite=max(0.0,-sa)*.30+max(0.0,-ea)*.30+max(0.0,-ma)*.28+max(0.0,-wa)*.12
        val ds=m.zipWithNext{a,c->c-a}; var flips=0; var last=0
        ds.forEach{d->val z=if(d>floor*.12)1 else if(d< -floor*.12)-1 else 0;if(z!=0){if(last!=0&&z!=last)flips++;last=z}}
        val chop=flips.toDouble()/max(1,ds.size-1)
        val continuation=(max(0.0,sa)*max(0.0,ea)*max(0.0,ma)).coerceIn(0.0,1.0)
        val exhaustion=(max(0.0,sa)*max(0.0,ea)*max(0.0,-ma-aa*.25)).coerceIn(0.0,1.0)
        val score=(50+positive*52-opposite*38-chop*20-exhaustion*20).coerceIn(0.0,92.0)
        val entryQ=(48+max(0.0,ma)*30+max(0.0,ea)*18-opposite*32-chop*22-exhaustion*28).coerceIn(0.0,100.0)
        val conflict=(opposite*65+chop*42+exhaustion*28).coerceIn(0.0,100.0)
        val reason=when{exhaustion>.55->"EXHAUSTION";continuation>.38->"CONTINUATION";max(0.0,ma)>.55&&max(0.0,sa)>.25->"FRESH_IMPULSE";else->"STRUCTURE"}
        return H(sign,e,score,entryQ,conflict,reason)
    }

    private fun wait(reason:String,eye:Eye?=null)=SignalResult("WAIT",120,0,0,100,reason,diagnostics=mapOf(
        "mode" to "2M_3M_VISION_SPECIALIST","vision_coverage" to (eye?.coverage?:0.0),"vision_continuity" to (eye?.continuity?:0.0),"trace_points" to (eye?.p?.size?:0),"vision_kind" to (eye?.kind?:"NONE"),"vision_anchors" to (eye?.anchors?:0)))
    private fun smooth(a:List<Double>,r:Int)=a.indices.map{i->median(a.subList(max(0,i-r),min(a.size,i+r+1)))}
    private fun median(a:List<Double>):Double{if(a.isEmpty())return 0.0;val s=a.sorted();return if(s.size%2==1)s[s.size/2] else (s[s.size/2-1]+s[s.size/2])/2}
}
