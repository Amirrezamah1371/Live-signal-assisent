package com.example.livesignalassistant

import android.graphics.Bitmap
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

data class SignalResult(val direction: String, val timeframeMinutes: Int, val confidence: Int)

/**
 * Entry-oriented visual analyzer.
 * Scores UP/DOWN independently for 1m, 2m and 3m. A background trend can add
 * context, but can never create a signal on its own. If no entry has a clear
 * edge, the only valid output is WAIT.
 */
object SignalAnalyzer {
    private const val MIN_SCORE = 80
    private const val MIN_EDGE = 9
    private val votes = ArrayDeque<String>()
    private var previousRight: Double? = null

    @Synchronized fun reset() { votes.clear(); previousRight = null }

    @Synchronized fun analyze(bitmap: Bitmap): SignalResult {
        val w=bitmap.width; val h=bitmap.height
        if(w<240 || h<360) return wait(true)

        // Chart-only sampling. Price up = positive value.
        val x0=(w*.055).toInt(); val x1=(w*.79).toInt()
        val y0=(h*.12).toInt(); val y1=(h*.79).toInt()
        val step=max(2,(x1-x0)/180)
        val raw=ArrayList<Double>()
        var x=x0
        while(x<x1){
            val hits=ArrayList<Int>(); var y=y0
            while(y<y1){
                val c=bitmap.getPixel(x,y); val r=(c shr 16) and 255; val g=(c shr 8) and 255; val b=c and 255
                val hi=max(r,max(g,b)); val lo=min(r,min(g,b))
                // Colored candle/path pixels; reject near-gray grid/text.
                if(hi>=105 && hi-lo>=48) hits.add(y)
                y+=2
            }
            if(hits.size>=2){ hits.sort(); raw.add(-hits[hits.size/2].toDouble()) }
            x+=step
        }
        if(raw.size<45) return wait(true)

        val p=smooth(raw,3); val n=p.size
        val noise=median(p.zipWithNext{a,b->abs(b-a)}).coerceAtLeast(1.0)
        val floor=max(h*.0025,noise*1.10)
        fun move(a:Double,b:Double):Double{
            val i=(n*a).toInt().coerceIn(0,n-2); val j=(n*b).toInt().coerceIn(i+2,n)
            val q=max(2,(j-i)/4)
            return median(p.subList(j-q,j))-median(p.subList(i,i+q))
        }

        val long=move(.10,.62); val mid=move(.56,.84); val fast=move(.80,1.0); val micro=move(.91,1.0)
        val right=median(p.takeLast(max(4,n/16)))
        val frame=previousRight?.let{right-it} ?: 0.0; previousRight=right
        val hist=p.subList(0,max(12,(n*.82).toInt()))
        val support=percentile(hist,.10); val resistance=percentile(hist,.90)
        val range=(resistance-support).coerceAtLeast(floor*4)
        val pos=((right-support)/range).coerceIn(-.5,1.5)

        // Symmetric evidence. Every bullish term has an exact bearish mirror.
        fun directionalScore(sign:Int, tf:Int):Int {
            fun aligned(v:Double,scale:Double)=((sign*v)/(floor*scale)).coerceIn(-1.0,1.0)
            val fastA=aligned(fast,1.7); val microA=aligned(micro,1.15); val frameA=aligned(frame,.95)
            val longA=aligned(long,3.0); val midA=aligned(mid,2.0)
            val level = if(sign>0) ((.30-pos)/.30).coerceIn(0.0,1.0) else ((pos-.70)/.30).coerceIn(0.0,1.0)
            val pullback = if(sign>0) ((-mid/floor)/2.0).coerceIn(0.0,1.0) else ((mid/floor)/2.0).coerceIn(0.0,1.0)
            val resume=(max(0.0,fastA)+max(0.0,microA))/2.0
            val breakout=if(sign>0) ((right-resistance)/(floor*1.8)).coerceIn(0.0,1.0) else ((support-right)/(floor*1.8)).coerceIn(0.0,1.0)

            // Timeframe-specific weighting: 1m needs a sharp fresh trigger; 3m needs broader structure.
            val score=when(tf){
                1 -> 28 + 24*max(0.0,microA) + 18*max(0.0,frameA) + 14*resume + 9*level + 7*breakout
                2 -> 28 + 20*max(0.0,fastA) + 14*max(0.0,frameA) + 15*resume + 12*level + 7*pullback + 4*max(0.0,longA)
                else -> 28 + 17*max(0.0,fastA) + 12*max(0.0,frameA) + 14*resume + 13*level + 10*pullback + 6*max(0.0,longA)
            }
            // Entry trigger is mandatory. Trend alone must never pass.
            if(sign*fast <= floor*.45 || sign*micro <= -floor*.15) return 0
            // Penalize immediate contradiction.
            val contradiction=max(0.0,-frameA)*14 + max(0.0,-fastA)*12
            return (score-contradiction).toInt().coerceIn(0,95)
        }

        data class C(val s:Int,val tf:Int,val score:Int)
        val all=mutableListOf<C>()
        for(tf in 1..3){ all+=C(1,tf,directionalScore(1,tf)); all+=C(-1,tf,directionalScore(-1,tf)) }
        val sorted=all.sortedByDescending{it.score}; val best=sorted[0]; val second=sorted[1]
        if(best.score<MIN_SCORE || best.score-second.score<MIN_EDGE) return wait(false,best.score)

        val key="${best.s}:${best.tf}"
        votes.addLast(key); while(votes.size>4) votes.removeFirst()
        if(votes.count{it==key}<2) return wait(false,best.score)
        return SignalResult(if(best.s>0) "UP" else "DOWN",best.tf,best.score)
    }

    private fun smooth(v:List<Double>,r:Int)=v.indices.map{i->median(v.subList(max(0,i-r),min(v.size,i+r+1)))}
    private fun median(v:List<Double>):Double{if(v.isEmpty())return 0.0;val s=v.sorted();return if(s.size%2==1)s[s.size/2] else (s[s.size/2-1]+s[s.size/2])/2.0}
    private fun percentile(v:List<Double>,q:Double):Double{val s=v.sorted();return s[((s.size-1)*q).toInt().coerceIn(0,s.size-1)]}
    private fun wait(clear:Boolean=false,conf:Int=0):SignalResult{if(clear)reset();return SignalResult("WAIT",0,conf.coerceIn(0,95))}
}
