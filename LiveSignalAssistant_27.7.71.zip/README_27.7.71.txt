27.7.71
Built directly from the preserved 71.7.27 MEMORY CONTROL source.
Trading brain thresholds and the proven direction gate are preserved.
R1 hard tail/freshness veto is NOT present.
Only decision aggregation is refined:
- expiry selection uses recency-weighted evidence instead of raw majority count
- representative observation is the freshest matching observation, not an older max-entry sample
- added decision diagnostics for audit
Memory Control/export/clear behavior is preserved.
Separate applicationId: com.example.livesignalassistant.v27771
