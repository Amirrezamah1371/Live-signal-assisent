Live Signal Assistant — PRO MAX

Experimental branch based on V5.5 MATURE RESTORED benchmark.
Horizons: 1m / 4m / 5m only. 30s removed.
V5.5 benchmark is intentionally kept separate and untouched.
PRO MAX adds per-horizon anti-flip and signal de-duplication so one market wave does not generate a burst of repeated NOW signals.
This is experimental software; performance must be validated on Demo and is not guaranteed.
