package com.example.livesignalassistant

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.os.Build
import android.os.Environment
import android.os.SystemClock
import android.provider.MediaStore
import org.json.JSONObject
import java.io.*
import java.text.SimpleDateFormat
import java.util.*
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

/** Durable append-only test memory. No trading/decision logic lives here. */
class MemoryStore(private val ctx: Context) {
    private val root = File(ctx.filesDir, "sessions").apply { mkdirs() }
    val sessionId: String = SimpleDateFormat("yyyyMMdd_HHmmss_SSS", Locale.US).format(Date())
    private val dir = File(root, sessionId).apply { mkdirs() }
    private val frames = File(dir, "frames").apply { mkdirs() }
    private val log = File(dir, "timeline.jsonl")
    private val crashLog = File(dir, "crash.log")

    init {
        File(dir, "SESSION_ID.txt").writeText(sessionId)
        File(ctx.filesDir, "active_session.txt").writeText(sessionId)
    }

    @Synchronized
    fun event(type: String, data: Map<String, Any?> = emptyMap()) {
        val o = JSONObject()
        o.put("ts_ms", System.currentTimeMillis())
        o.put("mono_ms", SystemClock.elapsedRealtime())
        o.put("session_id", sessionId)
        o.put("type", type)
        data.forEach { (k, v) -> o.put(k, v) }
        durableAppend(log, o.toString() + "\n")
    }

    @Synchronized
    fun frame(b: Bitmap, tag: String = "observe"): String {
        val now = System.currentTimeMillis()
        val name = "${now}_${tag}.jpg"
        val f = File(frames, name)
        FileOutputStream(f).use { out ->
            b.compress(Bitmap.CompressFormat.JPEG, 72, out)
            out.flush()
            out.fd.sync()
        }
        event("SCREEN_EVIDENCE", mapOf("file" to "frames/$name", "tag" to tag))
        return name
    }

    @Synchronized
    fun crash(t: Throwable) {
        try {
            val sw = StringWriter(); t.printStackTrace(PrintWriter(sw))
            durableAppend(crashLog, "${System.currentTimeMillis()}\n$sw\n")
            event("APP_CRASH", mapOf("error" to (t.message ?: t.javaClass.name)))
        } catch (_: Throwable) { }
    }

    /** Streams the current session into a ZIP; originals are never deleted or modified. */
    @Synchronized
    fun exportZip(): String {
        event("EXPORT_REQUESTED")
        val tmp = File(ctx.cacheDir, "LiveSignalMemory_${sessionId}.zip")
        if (tmp.exists()) tmp.delete()
        ZipOutputStream(BufferedOutputStream(FileOutputStream(tmp), 256 * 1024)).use { z ->
            fun add(f: File, base: String) {
                if (f.isDirectory) {
                    f.listFiles()?.sortedBy { it.name }?.forEach {
                        add(it, if (base.isEmpty()) it.name else "$base/${it.name}")
                    }
                } else {
                    z.putNextEntry(ZipEntry(base))
                    BufferedInputStream(FileInputStream(f), 256 * 1024).use { input -> input.copyTo(z, 256 * 1024) }
                    z.closeEntry()
                }
            }
            dir.listFiles()?.sortedBy { it.name }?.forEach { add(it, it.name) }
            z.putNextEntry(ZipEntry("README.txt"))
            z.write(("Live Signal Assistant 7.0.2 MEMORY-SAFE\n" +
                "Session: $sessionId\n" +
                "timeline.jsonl uses wall-clock ts_ms plus monotonic mono_ms.\n" +
                "frames/ are SCREEN_EVIDENCE and map to timeline events.\n" +
                "Export is a copy: source memory remains on-device.\n").toByteArray())
            z.closeEntry()
        }
        if (!tmp.exists() || tmp.length() == 0L) throw IOException("ZIP was not created")

        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, tmp.name)
            put(MediaStore.MediaColumns.MIME_TYPE, "application/zip")
            if (Build.VERSION.SDK_INT >= 29) put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/LiveSignalMemory")
            if (Build.VERSION.SDK_INT >= 29) put(MediaStore.MediaColumns.IS_PENDING, 1)
        }
        val uri = ctx.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
            ?: throw IOException("Downloads destination unavailable")
        try {
            ctx.contentResolver.openOutputStream(uri, "w")?.use { out ->
                BufferedInputStream(FileInputStream(tmp), 256 * 1024).use { input -> input.copyTo(out, 256 * 1024) }
                out.flush()
            } ?: throw IOException("Cannot open Downloads output")
            if (Build.VERSION.SDK_INT >= 29) {
                val done = ContentValues().apply { put(MediaStore.MediaColumns.IS_PENDING, 0) }
                ctx.contentResolver.update(uri, done, null, null)
            }
        } catch (t: Throwable) {
            try { ctx.contentResolver.delete(uri, null, null) } catch (_: Throwable) { }
            throw t
        }
        event("EXPORT_COMPLETED", mapOf("bytes" to tmp.length(), "uri" to uri.toString()))
        return "Downloads/LiveSignalMemory/${tmp.name}"
    }

    private fun durableAppend(file: File, text: String) {
        FileOutputStream(file, true).use { out ->
            out.write(text.toByteArray())
            out.flush()
            out.fd.sync()
        }
    }
}
