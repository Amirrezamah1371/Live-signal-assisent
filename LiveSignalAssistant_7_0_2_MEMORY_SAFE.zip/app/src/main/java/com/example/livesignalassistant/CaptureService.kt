package com.example.livesignalassistant

import android.app.*
import android.content.*
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.hardware.display.*
import android.media.ImageReader
import android.media.projection.*
import android.os.*
import android.provider.Settings
import android.view.*
import android.widget.*
import androidx.core.app.NotificationCompat
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.*

class CaptureService:Service(){
 companion object{const val EXTRA_RESULT_CODE="result_code";const val EXTRA_RESULT_DATA="result_data";const val ACTION_EXPORT="lsa.export";private const val CHANNEL="lsa_v702";private const val NID=1702}
 private var projection:MediaProjection?=null;private var reader:ImageReader?=null;private var display:VirtualDisplay?=null
 private var wm:WindowManager?=null;private var brain:TextView?=null;private val bubbles=mutableListOf<View>();private val main=Handler(Looper.getMainLooper());private val worker=Executors.newSingleThreadExecutor();private val exportWorker=Executors.newSingleThreadExecutor();private val busy=AtomicBoolean(false);private val exporting=AtomicBoolean(false)
 private lateinit var memory:MemoryStore;private var lastFrameAt=0L;private var cycleStart=SystemClock.elapsedRealtime();private val observations=mutableListOf<SignalResult>();private var cycle=1
 override fun onCreate(){super.onCreate();memory=MemoryStore(this);val previous=Thread.getDefaultUncaughtExceptionHandler();Thread.setDefaultUncaughtExceptionHandler{thread,error->try{memory.crash(error)}catch(_:Throwable){};previous?.uncaughtException(thread,error)};channel();startForeground(NID,NotificationCompat.Builder(this,CHANNEL).setContentTitle("Live Signal 7.0.2 MEMORY SAFE").setContentText("59s observe · 1 decision · memory recording").setSmallIcon(android.R.drawable.ic_menu_view).setOngoing(true).build());memory.event("SESSION_START")}
 override fun onStartCommand(i:Intent?,f:Int,id:Int):Int{
  if(i?.action==ACTION_EXPORT){
   if(exporting.compareAndSet(false,true)){
    Toast.makeText(this,"Export started…",Toast.LENGTH_SHORT).show()
    exportWorker.execute{
     try{val p=memory.exportZip();main.post{Toast.makeText(this,"Memory exported: $p",Toast.LENGTH_LONG).show()}}
     catch(t:Throwable){memory.event("EXPORT_FAILED",mapOf("error" to (t.message?:t.javaClass.simpleName)));main.post{Toast.makeText(this,"Export failed — memory kept safely",Toast.LENGTH_LONG).show()}}
     finally{exporting.set(false)}
    }
   }else Toast.makeText(this,"Export already running…",Toast.LENGTH_SHORT).show()
   return START_NOT_STICKY
  }
  if(!Settings.canDrawOverlays(this)){stopSelf();return START_NOT_STICKY};showBrain();val code=i?.getIntExtra(EXTRA_RESULT_CODE,Activity.RESULT_CANCELED)?:Activity.RESULT_CANCELED;val data:Intent?=if(Build.VERSION.SDK_INT>=33)i?.getParcelableExtra(EXTRA_RESULT_DATA,Intent::class.java) else @Suppress("DEPRECATION") i?.getParcelableExtra(EXTRA_RESULT_DATA)
  if(code!=Activity.RESULT_OK||data==null){stopSelf();return START_NOT_STICKY};val mgr=getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager;projection=mgr.getMediaProjection(code,data);projection?.registerCallback(object:MediaProjection.Callback(){override fun onStop(){stopSelf()}},main);startCapture();return START_NOT_STICKY
 }
 private fun dp(v:Int)=(v*resources.displayMetrics.density).roundToInt()
 private fun glass(stroke:Int=0x55FFFFFF)=GradientDrawable().apply{setColor(0xB8FFFFFF.toInt());cornerRadius=42f;setStroke(2,stroke)}
 private fun showBrain(){main.post{if(brain!=null)return@post;wm=getSystemService(WINDOW_SERVICE) as WindowManager;val v=TextView(this).apply{text="7.0 · OBSERVE 59s\ncycle 1";textSize=13f;setTextColor(Color.BLACK);gravity=Gravity.CENTER;setPadding(18,12,18,12);background=glass();elevation=16f};val lp=params(Gravity.TOP or Gravity.END,18,190);wm!!.addView(v,lp);brain=v}}
 private fun params(g:Int,x:Int,y:Int)=WindowManager.LayoutParams(WindowManager.LayoutParams.WRAP_CONTENT,WindowManager.LayoutParams.WRAP_CONTENT,if(Build.VERSION.SDK_INT>=26)WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,PixelFormat.TRANSLUCENT).apply{gravity=g;this.x=x;this.y=y}
 private fun startCapture(){val m=resources.displayMetrics;reader=ImageReader.newInstance(m.widthPixels,m.heightPixels,PixelFormat.RGBA_8888,2);display=projection?.createVirtualDisplay("LSA70",m.widthPixels,m.heightPixels,m.densityDpi,DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,reader!!.surface,null,main);reader?.setOnImageAvailableListener({r->val now=SystemClock.elapsedRealtime();val im=r.acquireLatestImage()?:return@setOnImageAvailableListener;if(now-lastFrameAt<1000||busy.get()){im.close();return@setOnImageAvailableListener};lastFrameAt=now;busy.set(true);try{val p=im.planes[0];val pad=p.rowStride-p.pixelStride*im.width;val tmp=Bitmap.createBitmap(im.width+pad/p.pixelStride,im.height,Bitmap.Config.ARGB_8888);tmp.copyPixelsFromBuffer(p.buffer);val b=Bitmap.createBitmap(tmp,0,0,im.width,im.height);tmp.recycle();worker.execute{try{processFrame(b,now)}finally{b.recycle();busy.set(false)}}}catch(_:Throwable){busy.set(false)}finally{im.close()}},main)}
 private fun processFrame(b:Bitmap,now:Long){
  memory.frame(b,"observe")
  val elapsed=now-cycleStart
  // Technical observation throughout the minute; publication is forbidden until the boundary.
  if(elapsed>=4000 && elapsed%3000L<1200L){val r=SignalAnalyzer.analyze(b);synchronized(observations){observations+=r};memory.event("BOT_OBSERVATION",mapOf("cycle" to cycle,"direction" to r.direction,"expiry_s" to r.expirySeconds,"raw_confidence" to r.confidence,"entry" to r.entryQuality,"conflict" to r.conflict,"reason" to r.reason,"up" to r.upScore,"down" to r.downScore))}
  val left=max(0,60-(elapsed/1000).toInt());main.post{brain?.text="7.0 · ANALYZING ${left}s\ncycle $cycle"}
  if(elapsed>=59000){finishCycle(b);cycleStart=now;cycle++;synchronized(observations){observations.clear()}}
 }
 private fun finishCycle(b:Bitmap){
  val list=synchronized(observations){observations.toList()};val usable=list.filter{it.direction=="UP"||it.direction=="DOWN"}
  val up=usable.filter{it.direction=="UP"};val down=usable.filter{it.direction=="DOWN"};val side=if(up.size>down.size)"UP" else if(down.size>up.size)"DOWN" else "WAIT";val chosen=if(side=="UP")up else if(side=="DOWN")down else emptyList()
  val consistency=if(usable.isEmpty())0.0 else chosen.size.toDouble()/usable.size
  val result=if(side!="WAIT"&&chosen.size>=3&&consistency>=.62){val expiry=chosen.groupingBy{it.expirySeconds}.eachCount().maxByOrNull{it.value}!!.key;val same=chosen.filter{it.expirySeconds==expiry};val representative=same.maxByOrNull{it.entryQuality}!!;representative.copy(confidence=-1)} else SignalResult("WAIT",0,-1,reason=if(usable.isEmpty())"NO_VALID_SETUP" else "MINUTE_INCOHERENT")
  memory.frame(b,"decision");memory.event("MINUTE_DECISION",mapOf("cycle" to cycle,"direction" to result.direction,"expiry_s" to result.expirySeconds,"confidence_state" to "CALIBRATING","observations" to list.size,"usable" to usable.size,"consistency" to consistency,"reason" to result.reason))
  main.post{brain?.text=if(result.direction=="WAIT")"WAIT · CALIBRATING\ncycle $cycle" else "${if(result.direction=="UP")"↑" else "↓"} ${result.direction} · ${result.expirySeconds/60}m\nCONF: CALIBRATING";if(result.direction!="WAIT")spawn(result)}
 }
 private fun spawn(r:SignalResult){
  val manager=wm?:return;val arrow=if(r.direction=="UP")"↑" else "↓"
  val v=TextView(this).apply{text="$arrow ${r.direction} · ${r.expirySeconds/60}m\nTAP = OPENED";textSize=12f;setTextColor(Color.BLACK);gravity=Gravity.CENTER;setPadding(dp(12),dp(8),dp(12),dp(8));background=glass();elevation=18f}
  val lp=params(Gravity.TOP or Gravity.START,dp(6),dp(120)+bubbles.size*dp(78));manager.addView(v,lp);bubbles+=v;restack()
  memory.event("SIGNAL_PUBLISHED",mapOf("direction" to r.direction,"expiry_s" to r.expirySeconds,"confidence_state" to "CALIBRATING","auto_expire_s" to 15))
  var locked=false
  val expire=Runnable{
   if(!locked){memory.event("SIGNAL_NOT_EXECUTED_TIMEOUT",mapOf("direction" to r.direction,"expiry_s" to r.expirySeconds,"visible_for_s" to 15));try{manager.removeView(v)}catch(_:Throwable){};bubbles.remove(v);restack()}
  }
  main.postDelayed(expire,15000L)
  v.setOnClickListener{
   if(locked)return@setOnClickListener;locked=true;main.removeCallbacks(expire)
   val started=SystemClock.elapsedRealtime();memory.event("TRADE_USER_OPENED",mapOf("direction" to r.direction,"expiry_s" to r.expirySeconds))
   fun tick(){val remain=(r.expirySeconds*1000-(SystemClock.elapsedRealtime()-started)).coerceAtLeast(0);if(remain>0){v.text="$arrow ${r.direction} · LOCKED\n${remain/60000}:${((remain/1000)%60).toString().padStart(2,'0')}";main.postDelayed({tick()},250)}else showResultButtons(v,r)};tick()
  }
 }
 private fun showResultButtons(old:TextView,r:SignalResult){val manager=wm?:return;val lp=old.layoutParams as WindowManager.LayoutParams;try{manager.removeView(old)}catch(_:Throwable){};bubbles.remove(old);val row=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;background=glass();setPadding(8,6,8,6)};fun btn(t:String){row.addView(Button(this).apply{text=t;textSize=10f;setOnClickListener{memory.event("TRADE_RESULT",mapOf("result" to t,"direction" to r.direction,"expiry_s" to r.expirySeconds));try{manager.removeView(row)}catch(_:Throwable){};bubbles.remove(row);restack()}})};btn("WIN");btn("LOSS");btn("VOID");manager.addView(row,lp);bubbles+=row;memory.event("RESULT_REQUESTED",mapOf("direction" to r.direction,"expiry_s" to r.expirySeconds))}
 private fun restack(){bubbles.forEachIndexed{i,v->try{val lp=v.layoutParams as WindowManager.LayoutParams;lp.y=dp(120)+i*dp(78);wm?.updateViewLayout(v,lp)}catch(_:Throwable){}}}
 private fun channel(){if(Build.VERSION.SDK_INT>=26)getSystemService(NotificationManager::class.java).createNotificationChannel(NotificationChannel(CHANNEL,"Live Signal 7.0.2 Memory Safe",NotificationManager.IMPORTANCE_LOW))}
 override fun onDestroy(){memory.event("SESSION_STOP");reader?.setOnImageAvailableListener(null,null);display?.release();reader?.close();try{projection?.stop()}catch(_:Throwable){};worker.shutdownNow();exportWorker.shutdownNow();main.post{try{brain?.let{wm?.removeView(it)}}catch(_:Throwable){};bubbles.toList().forEach{try{wm?.removeView(it)}catch(_:Throwable){}}};super.onDestroy()}
 override fun onBind(i:Intent?):IBinder?=null
}
