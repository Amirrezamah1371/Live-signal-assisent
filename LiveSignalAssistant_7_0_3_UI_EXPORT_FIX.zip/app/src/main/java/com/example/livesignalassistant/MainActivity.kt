package com.example.livesignalassistant

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.util.concurrent.Executors
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var projectionManager: MediaProjectionManager
    private val exportWorker = Executors.newSingleThreadExecutor()

    private val captureLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == Activity.RESULT_OK && result.data != null) {
                val serviceIntent = Intent(this, CaptureService::class.java).apply {
                    putExtra(CaptureService.EXTRA_RESULT_CODE, result.resultCode)
                    putExtra(CaptureService.EXTRA_RESULT_DATA, result.data)
                }
                startForegroundService(serviceIntent)
            }
        }

    private val notificationPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        projectionManager =
            getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager

        if (Build.VERSION.SDK_INT >= 33) {
            notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(36, 60, 36, 36)
        }

        root.addView(TextView(this).apply {
            text = "Live Signal Assistant 7.0 — ONE DECISION + MEMORY\n\n59 ثانیه مشاهده، یک تصمیم در پایان چرخه، حافظه قابل استخراج."
            textSize = 20f
        })

        root.addView(Button(this).apply {
            text = "۱) اجازه نمایش روی برنامه‌های دیگر"
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    startActivity(
                        Intent(
                            Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                            Uri.parse("package:$packageName")
                        )
                    )
                }
            }
        })

        root.addView(Button(this).apply {
            text = "۲) شروع مشاهده زنده صفحه"
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    startActivity(
                        Intent(
                            Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                            Uri.parse("package:$packageName")
                        )
                    )
                    return@setOnClickListener
                }
                captureLauncher.launch(projectionManager.createScreenCaptureIntent())
            }
        })

        root.addView(Button(this).apply {
            text = "۳) EXPORT TEST MEMORY (ZIP)"
            setOnClickListener { button ->
                button.isEnabled = false
                Toast.makeText(this@MainActivity, "Export started…", Toast.LENGTH_SHORT).show()
                exportWorker.execute {
                    try {
                        val path = MemoryExporter.exportAll(applicationContext)
                        runOnUiThread { Toast.makeText(this@MainActivity, "Memory ZIP saved: $path", Toast.LENGTH_LONG).show(); button.isEnabled = true }
                    } catch (t: Throwable) {
                        runOnUiThread { Toast.makeText(this@MainActivity, "Export failed: ${t.message ?: t.javaClass.simpleName}", Toast.LENGTH_LONG).show(); button.isEnabled = true }
                    }
                }
            }
        })

        root.addView(TextView(this).apply {
            text = "\nپس از شروع، Pocket Option را باز کن. حباب روی صفحه یکی از این سه حالت را نشان می‌دهد:\n↑ UP + زمان\n↓ DOWN + زمان\nWAIT"
            textSize = 16f
        })

        setContentView(root)
    }

    override fun onDestroy() {
        exportWorker.shutdownNow()
        super.onDestroy()
    }
}
