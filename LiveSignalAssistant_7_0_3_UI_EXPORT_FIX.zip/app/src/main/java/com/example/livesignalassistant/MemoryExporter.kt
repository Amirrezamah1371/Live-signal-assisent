package com.example.livesignalassistant

import android.content.ContentValues
import android.content.Context
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

object MemoryExporter {
    fun exportAll(context: Context): String {
        val sessions = File(context.filesDir, "sessions")
        require(sessions.exists() && sessions.listFiles()?.isNotEmpty() == true) { "No test memory exists yet" }
        val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val tmp = File(context.cacheDir, "LiveSignalMemory_$stamp.zip")
        if (tmp.exists()) tmp.delete()
        ZipOutputStream(BufferedOutputStream(FileOutputStream(tmp), 256 * 1024)).use { zip ->
            fun add(file: File, path: String) {
                if (file.isDirectory) {
                    file.listFiles()?.sortedBy { it.name }?.forEach { add(it, "$path/${it.name}") }
                } else {
                    zip.putNextEntry(ZipEntry(path))
                    file.inputStream().buffered(256 * 1024).use { it.copyTo(zip, 256 * 1024) }
                    zip.closeEntry()
                }
            }
            sessions.listFiles()?.sortedBy { it.name }?.forEach { add(it, "sessions/${it.name}") }
            zip.putNextEntry(ZipEntry("README.txt"))
            zip.write("Live Signal Assistant 7.0 test memory export. Originals remain in app storage. Model SCORE is diagnostic only and is NOT a calibrated win probability.\n".toByteArray())
            zip.closeEntry()
        }
        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, tmp.name)
            put(MediaStore.MediaColumns.MIME_TYPE, "application/zip")
            if (Build.VERSION.SDK_INT >= 29) put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
        }
        val uri = context.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
            ?: throw IllegalStateException("Downloads destination unavailable")
        context.contentResolver.openOutputStream(uri)?.use { out -> tmp.inputStream().buffered().use { it.copyTo(out) } }
            ?: throw IllegalStateException("Could not open Downloads output")
        return "Downloads/${tmp.name}"
    }
}
