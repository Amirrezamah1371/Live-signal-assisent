package com.example.lsareviewextractor

import android.app.Activity
import android.content.ContentValues
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.view.Gravity
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.documentfile.provider.DocumentFile
import org.json.JSONObject
import java.io.*
import java.text.SimpleDateFormat
import java.util.*
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

class MainActivity : AppCompatActivity() {
    private lateinit var status: TextView
    private lateinit var run: Button
    private var rootUri: Uri? = null

    private val picker = registerForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        if (uri != null) {
            contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
            rootUri = uri
            status.text = "Folder selected. Ready to build ReviewPack."
            run.isEnabled = true
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(36, 48, 36, 36)
        }
        val title = TextView(this).apply { text = "LSA Review Extractor"; textSize = 24f }
        val info = TextView(this).apply {
            text = "Select the extracted memory folder (the folder containing sessions). This app reads timelines and automatically collects frames around every LOSS plus comparison WIN trades. It does not modify the Trader app or its memory."
            textSize = 16f; setPadding(0,24,0,24)
        }
        val choose = Button(this).apply { text = "SELECT MEMORY FOLDER"; setOnClickListener { picker.launch(null) } }
        run = Button(this).apply { text = "BUILD REVIEW PACK"; isEnabled = false; setOnClickListener { buildPack() } }
        status = TextView(this).apply { text = "No folder selected"; textSize = 15f; setPadding(0,24,0,0) }
        box.addView(title); box.addView(info); box.addView(choose); box.addView(run); box.addView(status)
        setContentView(box)
    }

    data class E(val obj: JSONObject, val source: DocumentFile)
    data class Trade(val id:String, val signalTs:Long, var openTs:Long=0, var resultTs:Long=0, var result:String="", var direction:String="", var expiry:Int=0)

    private fun buildPack() {
        val uri = rootUri ?: return
        run.isEnabled = false
        status.text = "Scanning timelines and frames…"
        Thread {
            try {
                val root = DocumentFile.fromTreeUri(this, uri) ?: error("Cannot open selected folder")
                val all = mutableListOf<DocumentFile>()
                walk(root, all)
                val timelines = all.filter { it.isFile && it.name?.equals("timeline.jsonl", true) == true }
                if (timelines.isEmpty()) error("No timeline.jsonl found. Select the export root or sessions folder.")

                val trades = linkedMapOf<String, Trade>()
                for (tl in timelines) {
                    contentResolver.openInputStream(tl.uri)!!.bufferedReader().useLines { lines ->
                        lines.forEach { line ->
                            val o = try { JSONObject(line) } catch (_:Exception) { null } ?: return@forEach
                            val type = o.optString("type")
                            val id = o.optString("signal_id", o.optString("signalId", ""))
                            if (id.isBlank()) return@forEach
                            val t = trades.getOrPut(id) { Trade(id, 0) }
                            when(type) {
                                "SIGNAL_PUBLISHED" -> {
                                    trades[id] = Trade(id, o.optLong("ts_ms"), direction=o.optString("direction"), expiry=o.optInt("expiry_s"))
                                }
                                "TRADE_USER_OPENED" -> t.openTs = o.optLong("ts_ms")
                                "TRADE_RESULT" -> { t.resultTs=o.optLong("ts_ms"); t.result=o.optString("result") }
                            }
                        }
                    }
                }
                val complete = trades.values.filter { it.signalTs>0 && it.result.isNotBlank() }
                val losses = complete.filter { it.result.equals("LOSS",true) }
                val wins = complete.filter { it.result.equals("WIN",true) }
                val controls = pickControls(losses, wins)
                val selected = (losses + controls).distinctBy { it.id }
                if (selected.isEmpty()) error("No completed WIN/LOSS trades found in timelines.")

                val frameFiles = all.filter { it.isFile && Regex("^(\\d{13}).*\\.(jpg|jpeg|png)$", RegexOption.IGNORE_CASE).matches(it.name ?: "") }
                val chosenFrames = linkedMapOf<String, DocumentFile>()
                val summary = StringBuilder("LSA REVIEW PACK\nLosses=${losses.size} Controls=${controls.size}\n\n")
                for (tr in selected) {
                    val end = if (tr.resultTs>0) tr.resultTs+5_000 else tr.signalTs + tr.expiry*1000L + 5_000
                    val start = tr.signalTs-15_000
                    val matched = frameFiles.filter { f ->
                        val ts = f.name!!.take(13).toLongOrNull() ?: -1
                        ts in start..end
                    }
                    matched.forEach { chosenFrames["${tr.id}/${it.name}"] = it }
                    summary.append("${tr.result} | ${tr.direction} ${tr.expiry}s | signal=${tr.signalTs} open=${tr.openTs} result=${tr.resultTs} | id=${tr.id} | frames=${matched.size}\n")
                }

                val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
                val name = "LSA_ReviewPack_$stamp.zip"
                val values = ContentValues().apply {
                    put(MediaStore.Downloads.DISPLAY_NAME, name)
                    put(MediaStore.Downloads.MIME_TYPE, "application/zip")
                    put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
                }
                val outUri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values) ?: error("Cannot create ZIP")
                contentResolver.openOutputStream(outUri)!!.use { os ->
                    ZipOutputStream(BufferedOutputStream(os)).use { zip ->
                        zip.putNextEntry(ZipEntry("REVIEW_SUMMARY.txt")); zip.write(summary.toString().toByteArray()); zip.closeEntry()
                        timelines.forEachIndexed { i, tl ->
                            zip.putNextEntry(ZipEntry("timelines/session_${i+1}_timeline.jsonl"))
                            contentResolver.openInputStream(tl.uri)!!.use { it.copyTo(zip) }; zip.closeEntry()
                        }
                        chosenFrames.forEach { (key,f) ->
                            zip.putNextEntry(ZipEntry("frames/$key"))
                            contentResolver.openInputStream(f.uri)!!.use { it.copyTo(zip) }; zip.closeEntry()
                        }
                    }
                }
                runOnUiThread {
                    status.text = "DONE ❤️\n$name saved in Downloads\n${losses.size} LOSS trades + ${controls.size} comparison WIN trades\n${chosenFrames.size} targeted frames"
                    run.isEnabled = true
                }
            } catch (e:Exception) {
                runOnUiThread { status.text = "ERROR: ${e.message}"; run.isEnabled = true }
            }
        }.start()
    }

    private fun pickControls(losses:List<Trade>, wins:List<Trade>):List<Trade> {
        if (wins.isEmpty()) return emptyList()
        val picked = mutableListOf<Trade>()
        for (l in losses) {
            val best = wins.filterNot { w -> picked.any { it.id==w.id } }
                .minByOrNull { w ->
                    (if (w.direction==l.direction) 0 else 1_000_000_000L) +
                    kotlin.math.abs(w.expiry-l.expiry)*1_000_000L + kotlin.math.abs(w.signalTs-l.signalTs)
                }
            if (best!=null) picked += best
        }
        return picked.take(12)
    }

    private fun walk(dir:DocumentFile, out:MutableList<DocumentFile>) {
        for (f in dir.listFiles()) {
            out += f
            if (f.isDirectory) walk(f,out)
        }
    }
}
