LSA Review Extractor 1.0
Independent package: com.amirreza.lsareviewextractor
Does not replace or modify Live Signal Trader.
Select the extracted memory export root or sessions folder, then BUILD REVIEW PACK.
Output: Downloads/LSA_ReviewPack_*.zip
Includes all LOSS trades, matched WIN controls, relevant timeline files, and frames from 15 seconds before signal through 5 seconds after recorded result.
