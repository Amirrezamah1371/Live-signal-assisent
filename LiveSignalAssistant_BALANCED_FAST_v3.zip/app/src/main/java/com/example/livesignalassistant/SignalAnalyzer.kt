package com.example.livesignalassistant

import android.graphics.Bitmap
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

data class SignalResult(val direction: String, val timeframeMinutes: Int, val confidence: Int)

/**
 * Balanced entry engine v2.
 *
 * Six candidates are evaluated independently on every frame:
 * UP/DOWN x 1m/2m/3m.  UP and DOWN use the same mirrored formula, so neither
 * side inherits state or score from the other.  Trend is context only; a fresh
 * trigger is mandatory.  Thresholds adapt mildly to visual noise so clean
 * setups are not unnecessarily missed, while ambiguous/noisy frames stay WAIT.
 */
object SignalAnalyzer {
    private const val BASE_MIN_SCORE = 72
    private const val BASE_MIN_EDGE = 5
    private val votes = ArrayDeque<String>()
    private var previousRight: Double? = null

    @Synchronized fun reset() { votes.clear(); previousRight = null }

    @Synchronized fun analyze(bitmap: Bitmap): SignalResult {
        val w = bitmap.width; val h = bitmap.height
        if (w < 240 || h < 360) return wait(true)

        val x0 = (w * .055).toInt(); val x1 = (w * .79).toInt()
        val y0 = (h * .12).toInt(); val y1 = (h * .79).toInt()
        val step = max(2, (x1 - x0) / 210) // denser sampling than v1
        val raw = ArrayList<Double>()
        var x = x0
        while (x < x1) {
            val hits = ArrayList<Int>(); var y = y0
            while (y < y1) {
                val c = bitmap.getPixel(x, y)
                val r = (c shr 16) and 255; val g = (c shr 8) and 255; val b = c and 255
                val hi = max(r, max(g, b)); val lo = min(r, min(g, b))
                if (hi >= 100 && hi - lo >= 42) hits.add(y)
                y += 2
            }
            if (hits.size >= 2) { hits.sort(); raw.add(-hits[hits.size / 2].toDouble()) }
            x += step
        }
        if (raw.size < 48) return wait(true)

        val p = smooth(raw, 2); val n = p.size
        val deltas = p.zipWithNext { a, b -> abs(b - a) }
        val noise = median(deltas).coerceAtLeast(1.0)
        val floor = max(h * .0022, noise * 1.05)

        fun move(a: Double, b: Double): Double {
            val i = (n * a).toInt().coerceIn(0, n - 2)
            val j = (n * b).toInt().coerceIn(i + 2, n)
            val q = max(2, (j - i) / 4)
            return median(p.subList(j - q, j)) - median(p.subList(i, i + q))
        }

        val long = move(.08, .60)
        val mid = move(.52, .82)
        val fast = move(.76, 1.0)
        val micro = move(.88, 1.0)
        val ultra = move(.95, 1.0)
        val right = median(p.takeLast(max(4, n / 18)))
        val frame = previousRight?.let { right - it } ?: 0.0
        previousRight = right

        val hist = p.subList(0, max(14, (n * .82).toInt()))
        val support = percentile(hist, .10); val resistance = percentile(hist, .90)
        val range = (resistance - support).coerceAtLeast(floor * 4)
        val pos = ((right - support) / range).coerceIn(-.5, 1.5)

        // Choppiness: frequent direction flips should demand stronger evidence.
        val recent = p.takeLast(max(14, n / 4)).zipWithNext { a, b -> b - a }
        var flips = 0; var lastSign = 0
        for (d in recent) {
            val s = when { d > floor * .10 -> 1; d < -floor * .10 -> -1; else -> 0 }
            if (s != 0) { if (lastSign != 0 && s != lastSign) flips++; lastSign = s }
        }
        val chop = (flips.toDouble() / max(1, recent.size - 1)).coerceIn(0.0, 1.0)

        data class C(val sign: Int, val tf: Int, val score: Int)

        fun directionalScore(sign: Int, tf: Int): Int {
            fun aligned(v: Double, scale: Double) = ((sign * v) / (floor * scale)).coerceIn(-1.0, 1.0)
            val longA = aligned(long, 3.0)
            val midA = aligned(mid, 2.0)
            val fastA = aligned(fast, 1.55)
            val microA = aligned(micro, 1.05)
            val ultraA = aligned(ultra, .75)
            val frameA = aligned(frame, .90)

            val nearLevel = if (sign > 0)
                ((.38 - pos) / .38).coerceIn(0.0, 1.0)
            else
                ((pos - .62) / .38).coerceIn(0.0, 1.0)

            // A pullback is opposite movement in the middle segment followed by
            // fresh movement in the candidate direction.
            val pullback = max(0.0, -midA)
            val resume = (max(0.0, fastA) + max(0.0, microA) + max(0.0, ultraA)) / 3.0
            val breakout = if (sign > 0)
                ((right - resistance) / (floor * 1.55)).coerceIn(0.0, 1.0)
            else
                ((support - right) / (floor * 1.55)).coerceIn(0.0, 1.0)

            // Reversal evidence near an extreme: broad move points into the
            // level, but fresh micro/ultra movement turns away from it.
            val reversal = (nearLevel * max(0.0, -longA) *
                ((max(0.0, microA) + max(0.0, ultraA)) / 2.0)).coerceIn(0.0, 1.0)

            // Continuation after a shallow pause/pullback.
            val continuation = (max(0.0, longA) * resume *
                (1.0 - min(1.0, abs(midA) * .45))).coerceIn(0.0, 1.0)

            // A fresh trigger is mandatory for both sides, identically.
            val trigger = max(max(0.0, ultraA), max(0.0, frameA))
            if (trigger < .18 || microA < -.22) return 0

            val score = when (tf) {
                1 -> 24 + 19 * max(0.0, ultraA) + 16 * max(0.0, microA) +
                    12 * max(0.0, frameA) + 10 * nearLevel + 9 * reversal +
                    7 * breakout + 6 * continuation
                2 -> 24 + 16 * max(0.0, microA) + 15 * max(0.0, fastA) +
                    10 * max(0.0, frameA) + 11 * nearLevel + 9 * reversal +
                    8 * continuation + 7 * pullback
                else -> 24 + 14 * max(0.0, fastA) + 12 * max(0.0, microA) +
                    10 * max(0.0, longA) + 10 * nearLevel + 9 * reversal +
                    9 * continuation + 7 * pullback
            }

            val contradiction = 13 * max(0.0, -microA) +
                10 * max(0.0, -frameA) + 6 * max(0.0, -fastA)
            val chopPenalty = chop * if (tf == 1) 8.0 else 5.0
            return (score - contradiction - chopPenalty).toInt().coerceIn(0, 95)
        }

        val all = mutableListOf<C>()
        for (tf in 1..3) {
            all += C(1, tf, directionalScore(1, tf))
            all += C(-1, tf, directionalScore(-1, tf))
        }
        val sorted = all.sortedByDescending { it.score }
        val best = sorted[0]; val second = sorted[1]

        // Mild adaptive gate: clean frames can pass a little earlier; noisy/choppy
        // frames require more evidence. This is deliberately bounded.
        val minScore = (BASE_MIN_SCORE + (chop * 6.0).toInt() - if (chop < .18) 2 else 0)
            .coerceIn(70, 79)
        val minEdge = (BASE_MIN_EDGE + (chop * 4.0).toInt()).coerceIn(5, 9)

        if (best.score < minScore || best.score - second.score < minEdge)
            return wait(false, best.score)

        // Confirm direction, not an exact timeframe. Requiring the same timeframe on
        // consecutive scans caused good setups to remain WAIT when 1m/2m scores
        // swapped by only a point or two. The timeframe is still selected fresh
        // from the strongest candidate on the confirming scan.
        val key = "${best.sign}"
        votes.addLast(key)
        while (votes.size > 3) votes.removeFirst()

        // Two confirmations, but only over the latest three scans, reducing delay
        // without allowing a one-frame spike to become a trade signal.
        if (votes.count { it == key } < 2) return wait(false, best.score)

        return SignalResult(if (best.sign > 0) "UP" else "DOWN", best.tf, best.score)
    }

    private fun smooth(v: List<Double>, r: Int) = v.indices.map { i ->
        median(v.subList(max(0, i - r), min(v.size, i + r + 1)))
    }
    private fun median(v: List<Double>): Double {
        if (v.isEmpty()) return 0.0
        val s = v.sorted()
        return if (s.size % 2 == 1) s[s.size / 2] else (s[s.size / 2 - 1] + s[s.size / 2]) / 2.0
    }
    private fun percentile(v: List<Double>, q: Double): Double {
        val s = v.sorted(); return s[((s.size - 1) * q).toInt().coerceIn(0, s.size - 1)]
    }
    private fun wait(clear: Boolean = false, conf: Int = 0): SignalResult {
        if (clear) reset()
        return SignalResult("WAIT", 0, conf.coerceIn(0, 95))
    }
}
