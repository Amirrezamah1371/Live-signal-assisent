package com.example.livesignalassistant

import android.graphics.Bitmap
import kotlin.math.abs

/** Detects Pocket Option's open-trade UI visually. */
object TradeOpenDetector {
    private var baselineBlue=0
    private var baselineFp:IntArray?=null
    private var armedAt=0L
    private var confirmed=0

    @Synchronized fun arm(b:Bitmap){ baselineBlue=blueBadgePixels(b); baselineFp=fingerprint(b); armedAt=System.currentTimeMillis(); confirmed=0 }
    @Synchronized fun cancel(){ baselineFp=null; armedAt=0; confirmed=0; baselineBlue=0 }

    @Synchronized fun isTradeOpen(b:Bitmap):Boolean{
        val base=baselineFp?:return false
        if(System.currentTimeMillis()-armedAt<700L) return false

        // Strong cue from supplied Pocket Option screenshots: blue numeric badge above
        // the bottom "Trades" tab appears while an order is open.
        val blue=blueBadgePixels(b)
        val badgeAppeared = blue >= maxOf(10, baselineBlue + 7)

        // Secondary cue: persistent non-chart UI change, used only together with
        // a lower threshold so candle movement cannot trigger a lock by itself.
        val cur=fingerprint(b); var changed=0
        if(cur.size==base.size) for(i in cur.indices){
            val a=base[i]; val c=cur[i]
            val d=abs(((a shr 16)and 255)-((c shr 16)and 255))+abs(((a shr 8)and 255)-((c shr 8)and 255))+abs((a and 255)-(c and 255))
            if(d>115) changed++
        }
        val uiChanged=cur.isNotEmpty() && changed.toDouble()/cur.size>=.07
        if(badgeAppeared || (blue>baselineBlue+3 && uiChanged)) confirmed++ else confirmed=0
        return confirmed>=2
    }

    private fun blueBadgePixels(b:Bitmap):Int{
        val w=b.width; val h=b.height; var count=0
        // Bottom-center-left ROI where the Trades badge is shown in portrait PO UI.
        val x0=(w*.25).toInt(); val x1=(w*.46).toInt(); val y0=(h*.84).toInt(); val y1=(h*.965).toInt()
        var y=y0
        while(y<y1){ var x=x0; while(x<x1){
            val c=b.getPixel(x,y); val r=(c shr 16)and 255; val g=(c shr 8)and 255; val bl=c and 255
            if(bl>135 && bl>r+28 && bl>g+8) count++
            x+=3
        }; y+=3 }
        return count
    }

    private fun fingerprint(b:Bitmap):IntArray{
        val w=b.width; val h=b.height; val out=ArrayList<Int>()
        fun sample(x0:Double,y0:Double,x1:Double,y1:Double,c:Int,r:Int){for(yy in 0 until r)for(xx in 0 until c){
            val x=((x0+(x1-x0)*(xx+.5)/c)*w).toInt().coerceIn(0,w-1); val y=((y0+(y1-y0)*(yy+.5)/r)*h).toInt().coerceIn(0,h-1); out+=b.getPixel(x,y)
        }}
        sample(.82,.10,.985,.80,5,12); sample(.18,.84,.52,.97,8,5)
        return out.toIntArray()
    }
}
