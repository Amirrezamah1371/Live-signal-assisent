package com.example.livesignalassistant

import android.app.*
import android.content.*
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.hardware.display.*
import android.media.ImageReader
import android.media.projection.*
import android.os.*
import android.provider.Settings
import android.view.*
import android.widget.*
import androidx.core.app.NotificationCompat
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean
import java.util.UUID
import kotlin.math.*

class CaptureService:Service(){
 companion object{const val EXTRA_RESULT_CODE="result_code";const val EXTRA_RESULT_DATA="result_data";const val ACTION_EXPORT="lsa.export";private const val CHANNEL="lsa_v70";private const val NID=1700}
 private var projection:MediaProjection?=null;private var reader:ImageReader?=null;private var display:VirtualDisplay?=null
 private var wm:WindowManager?=null;private var brain:TextView?=null;private val bubbles=mutableListOf<View>();private val main=Handler(Looper.getMainLooper());private val worker=Executors.newSingleThreadExecutor();private val evidenceWorker=Executors.newSingleThreadExecutor();private val busy=AtomicBoolean(false)
 private lateinit var memory:MemoryStore;private lateinit var experience:ExperienceStore;private var lastFrameAt=0L;private var lastEvidenceAt=0L;private var cycleStart=SystemClock.elapsedRealtime();private var nextDecisionAt=cycleStart+90000L;private var nextObservationAt=cycleStart+1000L;private val observations=mutableListOf<SignalResult>();private var cycle=1
 override fun onCreate(){super.onCreate();memory=MemoryStore(this);experience=ExperienceStore(this);channel();startForeground(NID,NotificationCompat.Builder(this,CHANNEL).setContentTitle("71/7/27 · 90S Final Brain").setContentText("80s deep observation · 10s final decision · 1m expiry").setSmallIcon(android.R.drawable.ic_menu_view).setOngoing(true).build());memory.event("SESSION_START")}
 override fun onStartCommand(i:Intent?,f:Int,id:Int):Int{
  if(i?.action==ACTION_EXPORT){val p=memory.exportZip();Toast.makeText(this,"Memory exported: $p",Toast.LENGTH_LONG).show();return START_NOT_STICKY}
  if(!Settings.canDrawOverlays(this)){stopSelf();return START_NOT_STICKY};showBrain();val code=i?.getIntExtra(EXTRA_RESULT_CODE,Activity.RESULT_CANCELED)?:Activity.RESULT_CANCELED;val data:Intent?=if(Build.VERSION.SDK_INT>=33)i?.getParcelableExtra(EXTRA_RESULT_DATA,Intent::class.java) else @Suppress("DEPRECATION") i?.getParcelableExtra(EXTRA_RESULT_DATA)
  if(code!=Activity.RESULT_OK||data==null){stopSelf();return START_NOT_STICKY};if(projection!=null)return START_NOT_STICKY;val mgr=getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager;projection=mgr.getMediaProjection(code,data);projection?.registerCallback(object:MediaProjection.Callback(){override fun onStop(){stopSelf()}},main);startCapture();return START_NOT_STICKY
 }
 private fun glass(stroke:Int=0x55FFFFFF)=GradientDrawable().apply{setColor(0xB8FFFFFF.toInt());cornerRadius=42f;setStroke(2,stroke)}
 private fun showBrain(){main.post{if(brain!=null)return@post;wm=getSystemService(WINDOW_SERVICE) as WindowManager;val v=TextView(this).apply{text="71/7/27 · 90S FINAL BRAIN\ncycle 1";textSize=13f;setTextColor(Color.BLACK);gravity=Gravity.CENTER;setPadding(18,12,18,12);background=glass();elevation=16f};val lp=params(Gravity.TOP or Gravity.END,18,190);wm!!.addView(v,lp);brain=v}}
 private fun params(g:Int,x:Int,y:Int)=WindowManager.LayoutParams(WindowManager.LayoutParams.WRAP_CONTENT,WindowManager.LayoutParams.WRAP_CONTENT,if(Build.VERSION.SDK_INT>=26)WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,PixelFormat.TRANSLUCENT).apply{gravity=g;this.x=x;this.y=y}
 private fun startCapture(){val m=resources.displayMetrics;reader=ImageReader.newInstance(m.widthPixels,m.heightPixels,PixelFormat.RGBA_8888,2);display=projection?.createVirtualDisplay("LSA70",m.widthPixels,m.heightPixels,m.densityDpi,DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,reader!!.surface,null,main);reader?.setOnImageAvailableListener({r->val now=SystemClock.elapsedRealtime();val im=r.acquireLatestImage()?:return@setOnImageAvailableListener;if(now-lastFrameAt<250||busy.get()){im.close();return@setOnImageAvailableListener};lastFrameAt=now;busy.set(true);try{val p=im.planes[0];val pad=p.rowStride-p.pixelStride*im.width;val tmp=Bitmap.createBitmap(im.width+pad/p.pixelStride,im.height,Bitmap.Config.ARGB_8888);tmp.copyPixelsFromBuffer(p.buffer);val b=Bitmap.createBitmap(tmp,0,0,im.width,im.height);tmp.recycle();worker.execute{try{processFrame(b,now)}finally{b.recycle();busy.set(false)}}}catch(_:Throwable){busy.set(false)}finally{im.close()}},main)}
 private fun recordFrameAsync(b:Bitmap,tag:String){
  val copy=b.copy(Bitmap.Config.ARGB_8888,false)
  evidenceWorker.execute{try{memory.frame(copy,tag)}catch(t:Throwable){memory.event("RECORDER_ERROR",mapOf("message" to (t.message?:t.javaClass.simpleName)))}finally{copy.recycle()}}
 }
 private fun processFrame(b:Bitmap,now:Long){
  // Black-box screenshots are sampled every 3s; analysis still runs at its normal cadence.
  // This cuts session storage sharply without weakening the live analyzer.
  if(now-lastEvidenceAt>=3000L){recordFrameAsync(b,"observe");lastEvidenceAt=now}
  val elapsed=now-cycleStart
  // 1M path clock: one analyzed observation each second. Capture itself may run faster;
  // decision timing is monotonic and independent from frame-arrival jitter.
  if(now>=nextObservationAt && now<nextDecisionAt){
   val r=SignalAnalyzer.analyze(b);synchronized(observations){observations+=r}
   memory.event("BOT_OBSERVATION",mapOf("cycle" to cycle,"cycle_elapsed_ms" to elapsed,"phase" to if(elapsed<80000L)"DEEP_OBSERVATION" else "FINAL_WINDOW","direction" to r.direction,"expiry_s" to r.expirySeconds,"raw_confidence" to r.confidence,"entry" to r.entryQuality,"conflict" to r.conflict,"reason" to r.reason,"up" to r.upScore,"down" to r.downScore,"diagnostics" to r.diagnostics))
   do{nextObservationAt+=1000L}while(nextObservationAt<=now)
  }
  val left=max(0,((nextDecisionAt-now+999)/1000).toInt())
   val phase=if(elapsed<80000L)"DEEP OBSERVATION" else "FINAL DECISION"
   main.post{brain?.text="71.7.27 · 90S · $phase ${left}s\ncycle $cycle"}
  if(now>=nextDecisionAt){
   finishCycle(b,nextDecisionAt)
   // Anchor cycles to the monotonic schedule, never to a late frame; this prevents cumulative drift.
   val late=now-nextDecisionAt
    // If Android was paused long enough to miss a boundary, skip stale cycles instead of emitting catch-up signals.
    cycleStart=nextDecisionAt
    nextDecisionAt+=90000L
    if(late>=90000L){
     val skipped=late/90000L
     cycleStart+=skipped*90000L
     nextDecisionAt=cycleStart+90000L
     memory.event("STALE_CYCLES_SKIPPED",mapOf("count" to skipped,"late_ms" to late))
    }
    nextObservationAt=cycleStart+1000L;cycle++
   synchronized(observations){observations.clear()}
  }
 }
 private fun finishCycle(b:Bitmap,boundaryMono:Long){
   val list=synchronized(observations){observations.toList()};val usable=list.filter{it.direction=="UP"||it.direction=="DOWN"}
   fun weight(i:Int,n:Int):Double{val x=(i+1).toDouble()/n.coerceAtLeast(1);return .45+.55*x*x}
   val upWeight=usable.mapIndexed{i,r->if(r.direction=="UP")weight(i,usable.size)*(0.55+r.entryQuality.coerceIn(0,100)/220.0) else 0.0}.sum()
   val downWeight=usable.mapIndexed{i,r->if(r.direction=="DOWN")weight(i,usable.size)*(0.55+r.entryQuality.coerceIn(0,100)/220.0) else 0.0}.sum()
   val total=upWeight+downWeight;val consistency=if(total<=0.0)0.0 else max(upWeight,downWeight)/total
   val baseSide=when{upWeight>downWeight*1.08->"UP";downWeight>upWeight*1.08->"DOWN";else->"WAIT"}

   // 90S FINAL BRAIN:
   // 0..80s builds the stable market opinion. 80..90s is NOT a cooldown:
   // it continues analysis, but gives fresh trajectory evidence more influence.
   fun d(r:SignalResult,key:String)=((r.diagnostics[key] as? Number)?.toDouble())
   data class Pt(val t:Long,val p:Double,val floor:Double)
   val pts=list.mapNotNull{r->
    val tm=(r.diagnostics["cycle_elapsed_ms"] as? Number)?.toLong()
    val pr=d(r,"trace_right");val fl=d(r,"trace_floor")
    if(tm!=null&&pr!=null&&fl!=null)Pt(tm,pr,fl.coerceAtLeast(.01))else null
   }
   // cycle_elapsed_ms is logged outside diagnostics in older observations; rebuild timestamps by 1s cadence if needed.
   val path=if(pts.size>=8)pts else list.mapIndexedNotNull{i,r->
    val pr=d(r,"trace_right");val fl=d(r,"trace_floor")
    if(pr!=null&&fl!=null)Pt((i+1)*1000L,pr,fl.coerceAtLeast(.01))else null
   }
   fun slope(q:List<Pt>):Double{
    if(q.size<2)return 0.0
    val dt=((q.last().t-q.first().t).coerceAtLeast(1))/1000.0
    val floor=q.map{it.floor}.average().coerceAtLeast(.01)
    return (q.last().p-q.first().p)/(floor*dt)
   }
   fun tail(seconds:Int):List<Pt>{
    if(path.isEmpty())return emptyList()
    val cut=path.last().t-seconds*1000L
    return path.filter{it.t>=cut}
   }
   val s3=slope(tail(3));val s6=slope(tail(6));val s10=slope(tail(10));val s20=slope(tail(20))
   val aNow=s6-s10;val aPrev=s10-s20;val jerk=aNow-aPrev
   val baseSign=if(baseSide=="UP")1 else if(baseSide=="DOWN")-1 else 0
   val shortSign=when{(s3*.45+s6*.35+s10*.20)>.035->1;(s3*.45+s6*.35+s10*.20)<-.035->-1;else->0}
   val recentDir=if(shortSign>0)"UP" else if(shortSign<0)"DOWN" else "WAIT"
   val recentAligned=listOf(s3,s6,s10,s20).count{if(shortSign>0)it>.025 else if(shortSign<0)it<-.025 else false}
   val counterMagnitude=if(baseSign==0)0.0 else max(0.0,-baseSign*(s3*.45+s6*.35+s10*.20))
   val longMomentum=if(baseSign==0)0.0 else baseSign*s20
   val persistenceDecay=if(baseSign==0)0.0 else (longMomentum-baseSign*s6).coerceAtLeast(0.0)
   val tailDir=usable.takeLast(min(8,usable.size)); val oppositeTail=if(baseSign==0)0 else tailDir.count{(baseSign>0&&it.direction=="DOWN")||(baseSign<0&&it.direction=="UP")}
   val finalChangeConfirmed=baseSign!=0 && shortSign==-baseSign && recentAligned>=3 && oppositeTail>=5 &&
       counterMagnitude>=.080 && persistenceDecay>=.060 && abs(jerk)>=.070

   // Keep the old direction engine as the default. Fresh data may correct it only after
   // a sustained multi-window counter move; one-frame spikes cannot flip the signal.
   val corrected=baseSide!="WAIT" && finalChangeConfirmed
   val deterministicSide=if(corrected)recentDir else baseSide
   val recent=usable.takeLast(min(14,usable.size));val recentFlips=recent.zipWithNext().count{(a,c)->a.direction!=c.direction}

   // EXPERIENCE BRAIN: consult compact permanent outcomes only after deterministic analysis.
   // It cannot invent or reverse a trade. Similar historical setups may only annotate or veto a repeatedly bad entry to WAIT.
   val experienceFeatures=mapOf<String,Any?>(
    "counter_magnitude" to counterMagnitude,"persistence_decay" to persistenceDecay,
    "trajectory_jerk" to jerk,"slope_6s" to s6,"slope_20s" to s20,
    "recent_direction_flips" to recentFlips,
    "trend_regime" to (usable.lastOrNull()?.diagnostics?.get("trend_regime")?:0.0),
    "range_regime" to (usable.lastOrNull()?.diagnostics?.get("range_regime")?:0.0),
    "entry_quality" to (usable.lastOrNull()?.entryQuality?:0),"conflict" to (usable.lastOrNull()?.conflict?:0),
    "late_entry_detected" to ((usable.lastOrNull()?.reason?:"")=="LATE_ENTRY_RISK"),
    "exhaustion" to (usable.lastOrNull()?.diagnostics?.get("exhaustion")?:0.0))
   val advice=experience.advise(baseSide,recentDir,deterministicSide,experienceFeatures)
   val side=advice.side
   val chosen=usable.filter{it.direction==side}

   val result=if(side!="WAIT" && chosen.size>=2 && consistency>=.55 && recentFlips<=6){
    val reps=chosen.takeLast(min(12,chosen.size))
    val representative=reps.maxByOrNull{it.entryQuality*.45-it.conflict*.20+it.signalQuality*.10}?:chosen.last()
    representative.copy(expirySeconds=60,confidence=-1,diagnostics=representative.diagnostics+mapOf(
     "cycle_mode" to "90S_80_PLUS_10","deep_observation_ms" to 80000,"final_window_ms" to 10000,
     "path_consistency" to consistency,"path_usable" to usable.size,"path_chosen" to chosen.size,
     "recent_direction_flips" to recentFlips,"fixed_horizon_ms" to 60000,"timeframe" to "1m",
     "base_side" to baseSide,"final_corrected" to corrected,"final_recent_side" to recentDir,"experience_applied" to advice.applied,"experience_samples" to advice.samples,"experience_delta" to advice.learnedDelta,
     "slope_3s" to s3,"slope_6s" to s6,"slope_10s" to s10,"slope_20s" to s20,
     "trajectory_accel_now" to aNow,"trajectory_accel_prev" to aPrev,"trajectory_jerk" to jerk,
     "counter_magnitude" to counterMagnitude,"persistence_decay" to persistenceDecay,
     "final_change_confirmed" to finalChangeConfirmed,
     "deterministic_side" to deterministicSide,"experience_applied" to advice.applied,
     "experience_delta" to advice.learnedDelta,"experience_samples" to advice.samples,
     "experience_chosen_rate" to advice.chosenRate,"experience_alternate_rate" to advice.alternateRate,
     "experience_key" to advice.key,"experience_similarity" to advice.similarity,"experience_veto" to advice.veto,
     "direction_change_reason" to if(corrected)"CONFIRMED_MULTI_WINDOW_REGIME_CHANGE" else "NONE"))
   }else SignalResult("WAIT",60,-1,reason=when{usable.isEmpty()->"NO_VALID_SETUP";recentFlips>6->"PATH_UNSTABLE";else->"CYCLE_INCOHERENT"})
   recordFrameAsync(b,"decision")
   val actual=SystemClock.elapsedRealtime();memory.event("NINETY_SECOND_DECISION",mapOf(
    "cycle" to cycle,"cycle_mode" to "90S_80_PLUS_10","timeframe" to "1m","fixed_expiry_ms" to 60000,
    "scheduled_boundary_mono_ms" to boundaryMono,"actual_decision_mono_ms" to actual,
    "decision_latency_ms" to (actual-boundaryMono).coerceAtLeast(0),"direction" to result.direction,
    "expiry_s" to 60,"observations" to list.size,"usable" to usable.size,"up_weight" to upWeight,
    "down_weight" to downWeight,"consistency" to consistency,"recent_flips" to recentFlips,
    "base_side" to baseSide,"final_corrected" to corrected,"final_recent_side" to recentDir,
    "slope_3s" to s3,"slope_6s" to s6,"slope_10s" to s10,"slope_20s" to s20,
    "trajectory_jerk" to jerk,"counter_magnitude" to counterMagnitude,
    "persistence_decay" to persistenceDecay,"reason" to result.reason,"diagnostics" to result.diagnostics))
   main.post{brain?.text=if(result.direction=="WAIT")"WAIT · 90S FINAL\\ncycle $cycle" else "${if(result.direction=="UP")"↑" else "↓"} ${result.direction} · 1m\\nFINAL";if(result.direction!="WAIT")spawn(result.copy(expirySeconds=60))}
  }
 private fun dp(v:Int)=(v*resources.displayMetrics.density).roundToInt()
 private fun spawn(r:SignalResult){
  val manager=wm?:return;val arrow=if(r.direction=="UP")"↑" else "↓";val signalId=UUID.randomUUID().toString()
  val percentText=if(r.signalQuality>0)"SCORE ${r.signalQuality}" else "SCORE --"
  val v=TextView(this).apply{text="$arrow ${r.direction} · ${r.expirySeconds/60}m · $percentText\nOPEN";textSize=11f;setTextColor(Color.BLACK);gravity=Gravity.CENTER;setPadding(dp(8),dp(5),dp(8),dp(5));background=glass();elevation=18f}
  val lp=params(Gravity.TOP or Gravity.START,dp(4),dp(120)+bubbles.size*dp(52));manager.addView(v,lp);bubbles+=v;restack()
  memory.event("SIGNAL_PUBLISHED",mapOf("signal_id" to signalId,"direction" to r.direction,"expiry_s" to r.expirySeconds,"confidence_state" to "CALIBRATING","model_score" to r.signalQuality,"auto_expire_s" to 15,"diagnostics" to r.diagnostics));var locked=false
  val expire=Runnable{if(!locked){memory.event("SIGNAL_NOT_EXECUTED_TIMEOUT",mapOf("signal_id" to signalId,"direction" to r.direction,"expiry_s" to r.expirySeconds,"model_score" to r.signalQuality,"visible_for_s" to 15));try{manager.removeView(v)}catch(_:Throwable){};bubbles.remove(v);restack()}}
  main.postDelayed(expire,15000L)
  v.setOnClickListener{if(locked)return@setOnClickListener;locked=true;main.removeCallbacks(expire);val startedNs=SystemClock.elapsedRealtimeNanos();val targetNs=startedNs+60_000_000_000L;memory.event("TRADE_USER_OPENED",mapOf("signal_id" to signalId,"direction" to r.direction,"expiry_s" to 60,"entry_mono_ns" to startedNs,"target_mono_ns" to targetNs,"model_score" to r.signalQuality));fun tick(){val nowNs=SystemClock.elapsedRealtimeNanos();val remainNs=(targetNs-nowNs).coerceAtLeast(0L);if(remainNs>0){val cs=(remainNs/10_000_000L);val sec=cs/100;val hundredths=cs%100;v.text="$arrow ${r.direction} · $percentText\nLOCKED · ${sec}.${hundredths.toString().padStart(2,'0')}s";main.postDelayed({tick()},10)}else{memory.event("EXPIRY_CLOCK",mapOf("signal_id" to signalId,"target_mono_ns" to targetNs,"actual_mono_ns" to nowNs,"timer_error_ns" to (nowNs-targetNs).coerceAtLeast(0L)));showResultButtons(v,r.copy(expirySeconds=60),signalId)}};tick()}
 }
 private fun showResultButtons(old:TextView,r:SignalResult,signalId:String){val manager=wm?:return;val lp=old.layoutParams as WindowManager.LayoutParams;try{manager.removeView(old)}catch(_:Throwable){};bubbles.remove(old);val row=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;background=glass();setPadding(8,6,8,6)};fun btn(t:String){row.addView(Button(this).apply{text=t;textSize=10f;setOnClickListener{
   memory.event("TRADE_RESULT",mapOf("signal_id" to signalId,"result" to t,"direction" to r.direction,"expiry_s" to r.expirySeconds,"model_score" to r.signalQuality,"diagnostics" to r.diagnostics))
   if(t=="WIN"||t=="LOSS"){
    val base=(r.diagnostics["base_side"] as? String)?:"WAIT"
    val recent=(r.diagnostics["final_recent_side"] as? String)?:"WAIT"
    experience.learn(base,recent,r.direction,t,r.diagnostics)
    val st=experience.stats();memory.event("EXPERIENCE_LEARNED",mapOf("signal_id" to signalId,"result" to t,"lifetime_results" to st.first,"profiles" to st.second))
   }
   try{manager.removeView(row)}catch(_:Throwable){};bubbles.remove(row);restack()
  }})};btn("WIN");btn("LOSS");btn("VOID");manager.addView(row,lp);bubbles+=row;restack();memory.event("RESULT_REQUESTED",mapOf("signal_id" to signalId,"direction" to r.direction,"expiry_s" to r.expirySeconds,"model_score" to r.signalQuality))}
 private fun restack(){bubbles.forEachIndexed{i,v->try{val lp=v.layoutParams as WindowManager.LayoutParams;lp.y=dp(120)+i*dp(52);wm?.updateViewLayout(v,lp)}catch(_:Throwable){}}}
 private fun channel(){if(Build.VERSION.SDK_INT>=26)getSystemService(NotificationManager::class.java).createNotificationChannel(NotificationChannel(CHANNEL,"Live Signal 7.1 Memory",NotificationManager.IMPORTANCE_LOW))}
 override fun onDestroy(){memory.event("SESSION_STOP");reader?.setOnImageAvailableListener(null,null);display?.release();reader?.close();try{projection?.stop()}catch(_:Throwable){};worker.shutdownNow();evidenceWorker.shutdown();main.post{try{brain?.let{wm?.removeView(it)}}catch(_:Throwable){};bubbles.toList().forEach{try{wm?.removeView(it)}catch(_:Throwable){}}};super.onDestroy()}
 override fun onBind(i:Intent?):IBinder?=null
}
