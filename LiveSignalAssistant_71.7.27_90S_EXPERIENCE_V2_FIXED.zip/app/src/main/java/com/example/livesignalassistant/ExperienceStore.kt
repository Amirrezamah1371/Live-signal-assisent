package com.example.livesignalassistant

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.max
import kotlin.math.min

/** Compact permanent experience. Raw session cleanup never touches this file. */
class ExperienceStore(private val ctx: Context) {
    data class Advice(
        val side:String, val applied:Boolean, val learnedDelta:Double, val samples:Int,
        val chosenRate:Double?, val alternateRate:Double?, val key:String,
        val similarity:Double=0.0, val veto:Boolean=false
    )
    private val file=File(ctx.filesDir,"permanent_experience/experience_v2.json")
    private val legacy=File(ctx.filesDir,"permanent_experience/experience_v1.json")
    private val lock=Any(); private val maxProfiles=256
    private val names=listOf("counter_magnitude","persistence_decay","trajectory_jerk","slope_6s","slope_20s","recent_direction_flips","trend_regime","range_regime","entry_quality","conflict","late_entry","exhaustion")
    private val scales=doubleArrayOf(.12,.12,.18,.15,.12,3.0,.35,.35,30.0,30.0,1.0,1.0)
    private fun n(m:Map<String,Any?>,k:String)=((m[k] as? Number)?.toDouble())?:0.0
    private fun vec(m:Map<String,Any?>)=doubleArrayOf(
        n(m,"counter_magnitude"),n(m,"persistence_decay"),n(m,"trajectory_jerk"),n(m,"slope_6s"),n(m,"slope_20s"),n(m,"recent_direction_flips"),
        n(m,"trend_regime"),n(m,"range_regime"),n(m,"entry_quality"),n(m,"conflict"),
        if((m["late_entry_detected"] as? Boolean)==true || (m["late_entry"] as? Boolean)==true)1.0 else 0.0,
        if((m["exhaustion_detected"] as? Boolean)==true || n(m,"exhaustion")>.55)1.0 else 0.0)
    private fun arr(v:DoubleArray)=JSONArray().also{a->v.forEach{a.put(it)}}
    private fun readVec(a:JSONArray?):DoubleArray?{if(a==null||a.length()!=names.size)return null;return DoubleArray(names.size){a.optDouble(it,0.0)}}
    private fun similarity(a:DoubleArray,b:DoubleArray):Double{var d=0.0;for(i in a.indices){val z=(a[i]-b[i])/scales[i];d+=z*z};return exp(-d/(2.0*a.size))}
    private fun fresh():JSONObject=JSONObject().put("version",2).put("profiles",JSONArray()).put("total_results",0)
    private fun load():JSONObject{file.parentFile?.mkdirs();if(!file.exists())return fresh();return try{JSONObject(file.readText())}catch(_:Throwable){fresh()}}
    private fun save(o:JSONObject){file.parentFile?.mkdirs();val t=File(file.parentFile,"experience_v2.tmp");t.writeText(o.toString());if(file.exists())file.delete();t.renameTo(file)}
    private fun betaRate(w:Double,l:Double)=(w+3.0)/(w+l+6.0)

    /** Similar setups contribute continuously. Experience can veto to WAIT, never reverse direction. */
    fun advise(base:String,recent:String,proposed:String,features:Map<String,Any?>):Advice=synchronized(lock){
        if(proposed!="UP"&&proposed!="DOWN")return@synchronized Advice(proposed,false,0.0,0,null,null,"",0.0,false)
        val q=vec(features);val ps=load().optJSONArray("profiles")?:JSONArray()
        var ww=0.0;var lw=0.0;var mass=0.0;var matched=0;var best=0.0
        for(i in 0 until ps.length()){
            val p=ps.optJSONObject(i)?:continue;if(p.optString("action")!=proposed)continue
            val pv=readVec(p.optJSONArray("centroid"))?:continue;val s=similarity(q,pv);if(s<.58)continue
            val samples=p.optInt("samples",0);val reliability=min(1.0,samples/12.0);val w=s*s*(.35+.65*reliability)
            ww+=p.optDouble("win_weight",0.0)*w;lw+=p.optDouble("loss_weight",0.0)*w;mass+=w;matched+=samples;best=max(best,s)
        }
        if(mass<.45 || matched<2)return@synchronized Advice(proposed,false,0.0,matched,null,null,"similarity",best,false)
        val rate=betaRate(ww,lw);val delta=rate-.5
        // Tiny samples only annotate. A veto needs repeated similar losses; it never flips direction.
        val veto=matched>=5 && best>=.68 && rate<=.36
        Advice(if(veto)"WAIT" else proposed,true,delta.coerceIn(-.12,.12),matched,rate,null,"similarity",best,veto)
    }

    fun learn(base:String,recent:String,executed:String,result:String,features:Map<String,Any?>){
        if(executed!="UP"&&executed!="DOWN")return;if(result!="WIN"&&result!="LOSS")return
        synchronized(lock){
            val o=load();val ps=o.optJSONArray("profiles")?:JSONArray().also{o.put("profiles",it)};val q=vec(features)
            var bestI=-1;var bestS=0.0
            for(i in 0 until ps.length()){
                val p=ps.optJSONObject(i)?:continue;if(p.optString("action")!=executed)continue
                val pv=readVec(p.optJSONArray("centroid"))?:continue;val s=similarity(q,pv);if(s>bestS){bestS=s;bestI=i}
            }
            val p=if(bestI>=0 && bestS>=.76)ps.getJSONObject(bestI) else JSONObject().also{
                it.put("action",executed);it.put("samples",0);it.put("wins",0);it.put("losses",0);it.put("win_weight",0.0);it.put("loss_weight",0.0);it.put("centroid",arr(q));it.put("last_ts",0L);ps.put(it)
            }
            val oldN=p.optInt("samples",0);val c=readVec(p.optJSONArray("centroid"))?:q;val alpha=1.0/(min(oldN,24)+1.0)
            for(i in c.indices)c[i]=c[i]*(1-alpha)+q[i]*alpha;p.put("centroid",arr(c))
            val ww=p.optDouble("win_weight",0.0)*.999;val lw=p.optDouble("loss_weight",0.0)*.999
            p.put("samples",oldN+1);if(result=="WIN"){p.put("wins",p.optInt("wins",0)+1);p.put("win_weight",ww+1);p.put("loss_weight",lw)}else{p.put("losses",p.optInt("losses",0)+1);p.put("win_weight",ww);p.put("loss_weight",lw+1)};p.put("last_ts",System.currentTimeMillis())
            o.put("total_results",o.optInt("total_results",0)+1)
            while(ps.length()>maxProfiles){var vi=0;var vn=Int.MAX_VALUE;for(i in 0 until ps.length()){val sn=ps.optJSONObject(i)?.optInt("samples",0)?:0;if(sn<vn){vn=sn;vi=i}};ps.remove(vi)}
            save(o)
        }
    }
    fun snapshotFile():File?=synchronized(lock){if(file.exists())file else null}
    fun stats():Pair<Int,Int>=synchronized(lock){val o=load();o.optInt("total_results",0) to (o.optJSONArray("profiles")?.length()?:0)}
}
