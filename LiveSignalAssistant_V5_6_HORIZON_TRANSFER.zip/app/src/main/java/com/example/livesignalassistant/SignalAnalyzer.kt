package com.example.livesignalassistant

import android.graphics.Bitmap
import android.os.SystemClock
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

data class SignalResult(
    val direction:String, val expirySeconds:Int, val confidence:Int,
    val entryQuality:Int=0, val conflict:Int=100, val reason:String="",
    val upScore:Int=0, val downScore:Int=0, val signalQuality:Int=0
)

/** V5.6 HORIZON TRANSFER — 5m path frozen; 30s/1m borrow its structure discipline without copying its timing. */
object SignalAnalyzer {
    private data class View(val p:List<Double>, val floor:Double)
    private data class C(val sign:Int,val expiry:Int,val score:Double,val entry:Double,val conflict:Double,val reason:String)
    private var prevRight:Double?=null; private var prevVelocity=0.0; private var prevAt=0L
    private val votes=mutableMapOf<Int,ArrayDeque<Int>>()
    private var lastSignalAt=0L; private var lastSignalSign=0; private var lastSignalExpiry=0
    private var lastSignalScore=0.0; private var lastSignalEntry=0.0

    @Synchronized fun reset(){prevRight=null;prevVelocity=0.0;prevAt=0;votes.clear();lastSignalAt=0;lastSignalSign=0;lastSignalExpiry=0;lastSignalScore=0.0;lastSignalEntry=0.0}

    @Synchronized fun analyze(b:Bitmap):SignalResult{
        val w=b.width; val h=b.height
        if(w<240||h<360) return wait("LOW VISIBILITY")
        // Keep controls/labels out; read the chart itself. Four time-scales are derived from progressively newer price history.
        val x0=(w*.055).toInt(); val x1=(w*.79).toInt(); val y0=(h*.12).toInt(); val y1=(h*.79).toInt()
        val step=max(2,(x1-x0)/320); val raw=ArrayList<Double>(); var x=x0
        while(x<x1){val hits=ArrayList<Int>();var y=y0
            while(y<y1){val c=b.getPixel(x,y);val r=(c shr 16)and 255;val g=(c shr 8)and 255;val bl=c and 255;val hi=max(r,max(g,bl));val lo=min(r,min(g,bl));if(hi>=95&&hi-lo>=38)hits+=y;y+=2}
            if(hits.size>=2){hits.sort();raw+=-hits[hits.size/2].toDouble()};x+=step
        }
        if(raw.size<72) return wait("LOW VISIBILITY")
        val all=smooth(raw,2);val n=all.size
        val wide=mk(all,h);val structure=mk(all.subList((n*.28).toInt(),n),h);val entry=mk(all.subList((n*.62).toInt(),n),h);val micro=mk(all.subList((n*.82).toInt(),n),h)
        val right=median(micro.p.takeLast(max(3,micro.p.size/7)));val now=SystemClock.elapsedRealtime();val dt=((now-prevAt).coerceAtLeast(1))/1000.0
        val velocity=prevRight?.let{(right-it)/dt}?:0.0;val accel=(velocity-prevVelocity)/dt;prevRight=right;prevVelocity=velocity;prevAt=now

        val expiries=intArrayOf(30,60,300);val cs=ArrayList<C>()
        for(e in expiries){cs+=candidate(1,e,wide,structure,entry,micro,velocity,accel);cs+=candidate(-1,e,wide,structure,entry,micro,velocity,accel)}
        val best=cs.maxByOrNull{it.score}!!;val opp=cs.first{it.expiry==best.expiry&&it.sign==-best.sign};val margin=best.score-opp.score
        val up=cs.filter{it.sign>0}.maxOf{it.score}.toInt();val down=cs.filter{it.sign<0}.maxOf{it.score}.toInt()

        // Horizon-specific maturity gates. 5m keeps the successful V5.4 character; 1m requires cleaner agreement.
        val minScore=when(best.expiry){30->64.0;60->66.0;else->62.0}
        val minEntry=when(best.expiry){30->49.0;60->50.0;else->46.0}
        val maxConflict=when(best.expiry){30->54.0;60->52.0;else->58.0}
        val minMargin=when(best.expiry){30->7.0;60->7.5;else->6.0}
        if(best.score<minScore || best.entry<minEntry || best.conflict>maxConflict || margin<minMargin)
            return SignalResult("WAIT",0,best.score.toInt(),best.entry.toInt(),best.conflict.toInt(),"FILTER",up,down,0)

        val q=votes.getOrPut(best.expiry){ArrayDeque()};q.addLast(best.sign);while(q.size>4)q.removeFirst()
        val persistence=q.count{it==best.sign}
        val fastPass=when(best.expiry){30->79.0;60->78.0;else->76.0}
        if(best.score<fastPass && (q.size<3 || persistence<2))
            return SignalResult("WAIT",0,best.score.toInt(),best.entry.toInt(),best.conflict.toInt(),"CONFIRM",up,down,0)

        // Evidence-based anti-flip: do not reverse a fresh signal on tiny noise, but allow a genuine strong reversal.
        if(best.expiry==lastSignalExpiry && best.sign==-lastSignalSign && now-lastSignalAt<12_000){
            val reversalStrength=(best.score-lastSignalScore) + (best.entry-lastSignalEntry)*.45 + margin*.55
            val structural=best.reason=="REV" || best.reason=="BRK"
            if(!structural && reversalStrength<13.0)
                return SignalResult("WAIT",0,best.score.toInt(),best.entry.toInt(),best.conflict.toInt(),"ANTI_FLIP",up,down,0)
        }

        // Suppress repeats of the same setup, without freezing other horizons or genuine reversals.
        val repeatWindow=when(best.expiry){30->18_000L;60->24_000L;else->32_000L}
        if(best.sign==lastSignalSign && best.expiry==lastSignalExpiry && now-lastSignalAt<repeatWindow)
            return SignalResult("WAIT",0,best.score.toInt(),best.entry.toInt(),best.conflict.toInt(),"COOLDOWN",up,down,0)

        lastSignalAt=now;lastSignalSign=best.sign;lastSignalExpiry=best.expiry;lastSignalScore=best.score;lastSignalEntry=best.entry
        return SignalResult(if(best.sign>0)"UP" else "DOWN",best.expiry,best.score.toInt(),best.entry.toInt(),best.conflict.toInt(),best.reason,up,down,0)
    }

    private fun mk(p:List<Double>,h:Int):View{val d=p.zipWithNext{a,c->abs(c-a)};return View(p,max(h*.0017,median(d).coerceAtLeast(1.0)*.90))}
    private fun candidate(sign:Int,e:Int,w:View,s:View,en:View,m:View,velocity:Double,accel:Double):C{
        fun mv(v:View,a:Double,b:Double):Double{val n=v.p.size;val i=(n*a).toInt().coerceIn(0,n-2);val j=(n*b).toInt().coerceIn(i+2,n);val q=max(2,(j-i)/4);return median(v.p.subList(j-q,j))-median(v.p.subList(i,i+q))}
        fun align(v:Double,f:Double,k:Double)=((sign*v)/(f*k)).coerceIn(-1.0,1.0)
        val wa=align(mv(w,.05,.95),w.floor,3.4);val sa=align(mv(s,.20,.98),s.floor,2.6);val ea=align(mv(en,.35,1.0),en.floor,1.7);val ma=align(mv(m,.42,1.0),m.floor,1.0)
        val va=align(velocity,m.floor,1.15);val aa=align(accel,m.floor,2.2)
        val hist=s.p.dropLast(max(2,s.p.size/12));val sup=percentile(hist,.10);val res=percentile(hist,.90);val r=median(m.p.takeLast(max(3,m.p.size/6)));val span=(res-sup).coerceAtLeast(s.floor*4);val pos=((r-sup)/span).coerceIn(-.5,1.5)
        // Symmetric location evidence: UP gets support-side reversal evidence; DOWN gets resistance-side reversal evidence.
        val level=if(sign>0)((.50-pos)/.50).coerceIn(0.0,1.0) else ((pos-.50)/.50).coerceIn(0.0,1.0)
        val breakout=if(sign>0)((r-res)/(s.floor*1.4)).coerceIn(0.0,1.0) else ((sup-r)/(s.floor*1.4)).coerceIn(0.0,1.0)
        val ds=m.p.zipWithNext{a,c->c-a};var flips=0;var last=0;for(d in ds){val z=if(d>m.floor*.1)1 else if(d< -m.floor*.1)-1 else 0;if(z!=0){if(last!=0&&z!=last)flips++;last=z}}
        val chop=flips.toDouble()/max(1,ds.size-1)
        val weights=when(e){
            // 30s: still fast, but structure gets a real vote so micro-noise cannot dominate.
            30->doubleArrayOf(.09,.17,.29,.31,.10,.04)
            // 1m: transfer the successful 5m discipline toward structure/entry while retaining enough micro timing.
            60->doubleArrayOf(.16,.28,.30,.18,.06,.02)
            // FROZEN 5m weights from V5.5 — do not alter.
            else->doubleArrayOf(.25,.36,.25,.08,.04,.02)
        }
        val aligned=listOf(wa,sa,ea,ma,va,aa);var directional=0.0;for(i in aligned.indices)directional+=max(0.0,aligned[i])*weights[i]
        val opposite=max(0.0,-ma)*.31+max(0.0,-ea)*.29+max(0.0,-sa)*.25+max(0.0,-wa)*.10+max(0.0,-va)*.05
        val reversal=(level*max(0.0,-sa)*(max(0.0,ma)+max(0.0,ea))/2).coerceIn(0.0,1.0)
        val continuation=(max(0.0,wa)*max(0.0,sa)*max(0.0,ea)).coerceIn(0.0,1.0)
        val timing=when(e){
            30->(.46*max(0.0,ma)+.31*max(0.0,ea)+.16*max(0.0,va)+.07*max(0.0,aa)).coerceIn(0.0,1.0)
            60->(.34*max(0.0,ma)+.38*max(0.0,ea)+.20*max(0.0,sa)+.06*max(0.0,va)+.02*max(0.0,aa)).coerceIn(0.0,1.0)
            else->(.50*max(0.0,ma)+.28*max(0.0,ea)+.15*max(0.0,va)+.07*max(0.0,aa)).coerceIn(0.0,1.0)
        }
        // A mature continuation should not chase an already stretched move whose micro momentum is fading.
        val edgeDistance=if(sign>0) ((r-res)/(s.floor*2.2)).coerceIn(0.0,1.4) else ((sup-r)/(s.floor*2.2)).coerceIn(0.0,1.4)
        val fading=(max(0.0,sa)*max(0.0,-ma) + max(0.0,ea)*max(0.0,-va)).coerceIn(0.0,1.0)
        val exhaustion=(edgeDistance*.55 + fading*.70 + max(0.0,-aa)*.18).coerceIn(0.0,1.0)
        val entryQ=when(e){
            30->(39+35*timing+19*max(0.0,ea)+11*level+7*breakout-23*chop-11*max(0.0,-va)-16*exhaustion).coerceIn(0.0,100.0)
            60->(39+28*timing+22*max(0.0,ea)+14*max(0.0,sa)+10*level+7*breakout-22*chop-9*max(0.0,-va)-15*exhaustion).coerceIn(0.0,100.0)
            else->(40+34*timing+18*max(0.0,ea)+10*level+8*breakout-21*chop-10*max(0.0,-va)-14*exhaustion).coerceIn(0.0,100.0)
        }
        val conflict=when(e){
            30->(100*(opposite*.66+chop*.27+exhaustion*.07)).coerceIn(0.0,100.0)
            60->(100*(opposite*.64+chop*.22+exhaustion*.09+max(0.0,-sa)*.05)).coerceIn(0.0,100.0)
            else->(100*(opposite*.68+chop*.25+exhaustion*.07)).coerceIn(0.0,100.0)
        }
        val score=when(e){
            30->(37+directional*49+reversal*8+continuation*8+breakout*5+timing*7+entryQ*.09-conflict*.18-exhaustion*8).coerceIn(0.0,96.0)
            60->(37+directional*50+reversal*8+continuation*9+breakout*5+timing*6+entryQ*.10-conflict*.18-exhaustion*8).coerceIn(0.0,96.0)
            else->(38+directional*49+reversal*8+continuation*7+breakout*5+timing*6+entryQ*.09-conflict*.17-exhaustion*7).coerceIn(0.0,96.0)
        }
        val reason=when{reversal>.45->"REV";breakout>.45->"BRK";exhaustion>.58->"EXH";continuation>.38->"CONT";else->"MOM"}
        return C(sign,e,score,entryQ,conflict,reason)
    }
    private fun smooth(v:List<Double>,r:Int)=v.indices.map{i->median(v.subList(max(0,i-r),min(v.size,i+r+1)))}
    private fun median(v:List<Double>):Double{if(v.isEmpty())return 0.0;val s=v.sorted();return if(s.size%2==1)s[s.size/2] else (s[s.size/2-1]+s[s.size/2])/2}
    private fun percentile(v:List<Double>,q:Double):Double{val s=v.sorted();return s[((s.size-1)*q).toInt().coerceIn(0,s.size-1)]}
    private fun wait(r:String)=SignalResult("WAIT",0,0,0,100,r,0,0,0)
}
