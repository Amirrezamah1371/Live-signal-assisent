V5.6 HORIZON TRANSFER

- مسیر 5 دقیقه در SignalAnalyzer از نظر weights/timing/entry/conflict/score و gates همان V5.5 نگه داشته شده است.
- 30s و 1m از انضباط ساختاری 5m الهام گرفته‌اند، اما timing مخصوص افق کوتاه خودشان را دارند.
- هدف: کاهش نویز و خطای جهت بدون تبدیل موتور به WAIT-only.
- فقط Demo برای ارزیابی اولیه.
