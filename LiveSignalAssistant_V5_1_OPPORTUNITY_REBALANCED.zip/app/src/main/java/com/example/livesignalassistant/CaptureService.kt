package com.example.livesignalassistant

import android.app.*
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.SystemClock
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.WindowManager
import android.widget.TextView
import android.widget.Toast
import androidx.core.app.NotificationCompat
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

class CaptureService : Service() {
    companion object {
        const val EXTRA_RESULT_CODE = "result_code"
        const val EXTRA_RESULT_DATA = "result_data"
        private const val CHANNEL_ID = "lsa_v5pro_capture"
        private const val NOTIFICATION_ID = 1505
    }

    private var projection: MediaProjection? = null
    private var imageReader: ImageReader? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var projectionCallback: MediaProjection.Callback? = null
    private var overlay: TextView? = null
    private var wm: WindowManager? = null
    private val mainHandler = Handler(Looper.getMainLooper())
    private val executor = Executors.newSingleThreadExecutor()
    private val busy = AtomicBoolean(false)
    private var lastAnalysisAt = 0L
    private var lockedSignal: SignalResult? = null
    private var signalLockedUntil = 0L
    private var pendingSignal: SignalResult? = null
    private var pendingLastSeenAt = 0L

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        startForeground(NOTIFICATION_ID, NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Live Signal V5 PRO")
            .setContentText("در حال مشاهده و تحلیل صفحه")
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setOngoing(true).build())
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "اجازه نمایش روی برنامه‌های دیگر فعال نیست", Toast.LENGTH_LONG).show()
            stopSelf(); return START_NOT_STICKY
        }
        showOverlay()

        val code = intent?.getIntExtra(EXTRA_RESULT_CODE, Activity.RESULT_CANCELED) ?: Activity.RESULT_CANCELED
        val data: Intent? = if (Build.VERSION.SDK_INT >= 33)
            intent?.getParcelableExtra(EXTRA_RESULT_DATA, Intent::class.java)
        else @Suppress("DEPRECATION") intent?.getParcelableExtra(EXTRA_RESULT_DATA)

        if (code != Activity.RESULT_OK || data == null) { stopSelf(); return START_NOT_STICKY }
        val mgr = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projection = mgr.getMediaProjection(code, data)
        projectionCallback = object : MediaProjection.Callback() {
            override fun onStop() {
                mainHandler.post { stopSelf() }
            }
        }
        projection?.registerCallback(projectionCallback!!, mainHandler)
        startCapture()
        return START_NOT_STICKY
    }

    private fun showOverlay() {
        mainHandler.post {
            if (overlay != null) return@post
            try {
                wm = getSystemService(WINDOW_SERVICE) as WindowManager
                val view = TextView(this).apply {
                    text = "● WAIT"
                    textSize = 18f
                    setPadding(28, 16, 28, 16)
                    background = GradientDrawable().apply {
                        setColor(0xEE171A20.toInt())
                        cornerRadius = 38f
                        setStroke(2, 0x557C8CFF)
                    }
                    setTextColor(0xFFFFFFFF.toInt())
                    elevation = 20f
                }
                val type = if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                           else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE
                val lp = WindowManager.LayoutParams(
                    WindowManager.LayoutParams.WRAP_CONTENT,
                    WindowManager.LayoutParams.WRAP_CONTENT,
                    type,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                        WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                        WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                    PixelFormat.TRANSLUCENT
                ).apply {
                    gravity = Gravity.TOP or Gravity.START
                    x = 30
                    y = 220
                }
                wm!!.addView(view, lp)
                overlay = view
                Toast.makeText(this, "حباب V5 PRO فعال شد", Toast.LENGTH_SHORT).show()
            } catch (t: Throwable) {
                overlay = null
                Toast.makeText(this, "خطای حباب: ${t.javaClass.simpleName}: ${t.message ?: "نامشخص"}", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun startCapture() {
        val metrics = resources.displayMetrics
        val width = metrics.widthPixels; val height = metrics.heightPixels; val density = metrics.densityDpi
        imageReader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2)
        virtualDisplay = projection?.createVirtualDisplay("LiveSignalV5PRO", width, height, density,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, imageReader?.surface, null, mainHandler)
        imageReader?.setOnImageAvailableListener({ reader ->
            val now = System.currentTimeMillis()
            if (now - lastAnalysisAt < 350 || busy.get()) { reader.acquireLatestImage()?.close(); return@setOnImageAvailableListener }
            val image = reader.acquireLatestImage() ?: return@setOnImageAvailableListener
            busy.set(true); lastAnalysisAt = now
            try {
                val plane = image.planes[0]; val buffer = plane.buffer
                val pixelStride = plane.pixelStride; val rowStride = plane.rowStride
                val rowPadding = rowStride - pixelStride * image.width
                val padded = Bitmap.createBitmap(image.width + rowPadding / pixelStride, image.height, Bitmap.Config.ARGB_8888)
                padded.copyPixelsFromBuffer(buffer)
                val bitmap = Bitmap.createBitmap(padded, 0, 0, image.width, image.height); padded.recycle()
                executor.execute {
                    try {
                        val result = SignalAnalyzer.analyze(bitmap)
                        val tradeConfirmed = handlePendingTradeDetection(result, bitmap)
                        bitmap.recycle()
                        updateOverlay(result, tradeConfirmed)
                    }
                    catch (_: Throwable) { if (!bitmap.isRecycled) bitmap.recycle() }
                    finally { busy.set(false) }
                }
            } catch (_: Throwable) { busy.set(false) } finally { image.close() }
        }, mainHandler)
    }

    private fun handlePendingTradeDetection(result: SignalResult, bitmap: Bitmap): Boolean {
        val now = System.currentTimeMillis()
        if (lockedSignal != null) return false
        val strong = (result.direction == "UP" || result.direction == "DOWN") &&
            result.confidence >= 64 && result.entryQuality >= 44 && result.conflict <= 60 && result.expirySeconds > 0

        if (strong) {
            val p = pendingSignal
            if (p == null || p.direction != result.direction || p.expirySeconds != result.expirySeconds) {
                pendingSignal = result
                pendingLastSeenAt = now
                TradeOpenDetector.arm(bitmap)
                return false
            }
            pendingSignal = result
            pendingLastSeenAt = now
            return TradeOpenDetector.isTradeOpen(bitmap)
        }

        // A missed opportunity is NOT locked. Give the visual detector a short grace
        // period for the broker's open-trade UI to appear, then return to analysis.
        val p = pendingSignal
        if (p != null && now - pendingLastSeenAt <= 2800L) {
            if (TradeOpenDetector.isTradeOpen(bitmap)) return true
        } else if (p != null) {
            pendingSignal = null
            TradeOpenDetector.cancel()
        }
        return false
    }

    private fun expiryLabel(seconds: Int): String = when {
        seconds < 60 -> "${seconds}s"
        seconds % 60 == 0 -> "${seconds / 60}m"
        else -> "${seconds / 60}m${seconds % 60}s"
    }

    private fun updateOverlay(result: SignalResult, tradeConfirmed: Boolean) {
        mainHandler.post {
            // Monotonic clock fixes wall-clock jumps and premature countdown drift.
            val now = SystemClock.elapsedRealtime()
            val active = lockedSignal
            if (active != null && now < signalLockedUntil) {
                val secondsLeft = ((signalLockedUntil - now) / 1000L).coerceAtLeast(0L)
                val arrow = if (active.direction == "UP") "↑" else "↓"
                overlay?.text = "$arrow ${active.direction} · ${expiryLabel(active.expirySeconds)} · 🔒 ${secondsLeft}s"
                return@post
            }
            if (active != null) {
                lockedSignal = null; signalLockedUntil = 0L
                pendingSignal = null; TradeOpenDetector.cancel(); SignalAnalyzer.reset()
                overlay?.text = "V5 PRO · WAIT"; return@post
            }

            if (tradeConfirmed) {
                val p = pendingSignal ?: return@post
                lockedSignal = p
                signalLockedUntil = now + p.expirySeconds * 1000L
                pendingSignal = null; TradeOpenDetector.cancel()
                val arrow = if (p.direction == "UP") "↑" else "↓"
                overlay?.text = "$arrow ${p.direction} · ${expiryLabel(p.expirySeconds)} · 🔒"
                return@post
            }

            val p = pendingSignal
            val strong = (result.direction == "UP" || result.direction == "DOWN") &&
                result.confidence >= 64 && result.entryQuality >= 44 && result.conflict <= 60 && result.expirySeconds > 0
            overlay?.text = if (strong && p != null) {
                val arrow = if (result.direction == "UP") "↑" else "↓"
                "$arrow ${result.direction} · ${expiryLabel(result.expirySeconds)} · NOW · ${result.confidence}%"
            } else if (result.confidence > 0) "V5.1 · WAIT · E${result.entryQuality} C${result.conflict}" else "V5.1 · WAIT"
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel(CHANNEL_ID, "Screen analysis", NotificationManager.IMPORTANCE_LOW))
    }

    override fun onDestroy() {
        imageReader?.setOnImageAvailableListener(null, null)
        virtualDisplay?.release(); virtualDisplay = null
        imageReader?.close(); imageReader = null
        projectionCallback?.let { cb -> try { projection?.unregisterCallback(cb) } catch (_: Throwable) {} }
        projectionCallback = null
        try { projection?.stop() } catch (_: Throwable) {}
        projection = null
        TradeOpenDetector.cancel()
        executor.shutdownNow()
        mainHandler.post { try { overlay?.let { wm?.removeView(it) } } catch (_: Throwable) {}; overlay = null }
        super.onDestroy()
    }
    override fun onBind(intent: Intent?): IBinder? = null
}
