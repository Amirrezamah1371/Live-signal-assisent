LSA Photo Review Extractor 2.0
Select the folder containing the ~7090 extracted timestamp-named images.
No timeline.jsonl is required on the phone.
The 9 LOSS and 6 comparison WIN timestamps are embedded from the previously analyzed timelines.
The app samples only targeted frames and creates LSA_ReviewPack_Photos_*.zip in Downloads.
It does not modify Live Signal Assistant or its memory.
