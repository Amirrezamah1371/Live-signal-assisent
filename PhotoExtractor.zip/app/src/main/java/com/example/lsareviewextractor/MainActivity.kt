package com.example.lsareviewextractor

import android.content.ContentValues
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.view.Gravity
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.documentfile.provider.DocumentFile
import java.io.BufferedOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream
import kotlin.math.abs

class MainActivity : AppCompatActivity() {
    private lateinit var status: TextView
    private lateinit var run: Button
    private var rootUri: Uri? = null

    data class Target(
        val result: String,
        val direction: String,
        val expiry: Int,
        val signalTs: Long,
        val openTs: Long,
        val resultTs: Long,
        val id: String
    )

    // Exact trades reconstructed from the nine timeline.jsonl files already reviewed.
    // The app therefore needs ONLY the folder containing the extracted timestamp-named images.
    private val targets = listOf(
        Target("LOSS","DOWN",60,1790939947308,1790939952499,1790940014154,"cf176060"),
        Target("WIN","UP",60,1790940007413,1790940011970,1790940072898,"e02d13e9"),
        Target("WIN","UP",60,1790940548184,1790940555239,1790940618715,"fab8014f"),
        Target("WIN","DOWN",300,1790940963063,1790940974212,1790941378194,"6b89dd44"),
        Target("WIN","DOWN",240,1790941501900,1790941511247,1790941759600,"8c2262bc"),
        Target("LOSS","UP",60,1790941682295,1790941691991,1790941752645,"0eed152e"),
        Target("LOSS","DOWN",300,1790942282225,1790942288549,1790942591434,"82a6ded8"),
        Target("LOSS","DOWN",240,1790942462659,1790942471728,1790942714228,"67e71a5f"),
        Target("LOSS","UP",60,1790944845434,1790944848180,1790944909535,"c99d7db9"),
        Target("LOSS","UP",60,1790952416200,1790952419346,1790952480817,"546e296d"),
        Target("LOSS","DOWN",300,1790952535931,1790952541582,1790952843095,"13dfc136"),
        Target("LOSS","DOWN",240,1790952596324,1790952605427,1790952846410,"f2fe8938"),
        Target("WIN","UP",60,1790952896398,1790952903137,1790952964453,"dc8ef11c"),
        Target("LOSS","UP",180,1790953196259,1790953201091,1790953382570,"bc62ac97"),
        Target("WIN","DOWN",60,1790953556659,1790953560967,1790953622919,"088f365e")
    )

    private val picker = registerForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        if (uri != null) {
            try {
                contentResolver.takePersistableUriPermission(
                    uri,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                )
            } catch (_: Exception) {}
            rootUri = uri
            status.text = "Photo folder selected. Ready."
            run.isEnabled = true
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(36, 48, 36, 36)
        }
        val title = TextView(this).apply {
            text = "LSA Photo Review Extractor"
            textSize = 24f
        }
        val info = TextView(this).apply {
            text = "Select the folder containing the extracted chart images. No timeline.jsonl is needed. The app finds only the images around the 9 LOSS trades and 6 comparison WIN trades already identified, then creates a small ReviewPack ZIP in Downloads."
            textSize = 16f
            setPadding(0, 24, 0, 24)
        }
        val choose = Button(this).apply {
            text = "SELECT PHOTO FOLDER"
            setOnClickListener { picker.launch(null) }
        }
        run = Button(this).apply {
            text = "BUILD REVIEW PACK"
            isEnabled = false
            setOnClickListener { buildPack() }
        }
        status = TextView(this).apply {
            text = "No photo folder selected"
            textSize = 15f
            setPadding(0, 24, 0, 0)
        }

        box.addView(title)
        box.addView(info)
        box.addView(choose)
        box.addView(run)
        box.addView(status)
        setContentView(box)
    }

    private fun buildPack() {
        val uri = rootUri ?: return
        run.isEnabled = false
        status.text = "Scanning photo names… This can take a few minutes for 7,000+ images."

        Thread {
            try {
                val root = DocumentFile.fromTreeUri(this, uri) ?: error("Cannot open selected folder")
                val photos = mutableListOf<Pair<Long, DocumentFile>>()
                collectPhotos(root, photos)
                photos.sortBy { it.first }

                if (photos.isEmpty()) {
                    error("No timestamp-named JPG/JPEG/PNG images found in this folder.")
                }

                runOnUiThread {
                    status.text = "Found ${photos.size} images. Selecting review frames…"
                }

                val selected = linkedMapOf<String, DocumentFile>()
                val summary = StringBuilder()
                summary.append("LSA PHOTO REVIEW PACK\n")
                summary.append("Source photos found: ${photos.size}\n")
                summary.append("Targets: 9 LOSS + 6 comparison WIN\n")
                summary.append("Selection: nearest frame to key checkpoints; no timeline file required.\n\n")

                for ((index, tr) in targets.withIndex()) {
                    val checkpoints = checkpointsFor(tr)
                    var count = 0
                    for (wantedTs in checkpoints) {
                        val nearest = nearestPhoto(photos, wantedTs) ?: continue
                        // Reject a match if the nearest image is too far from the requested checkpoint.
                        if (abs(nearest.first - wantedTs) > 6_000L) continue
                        val original = nearest.second.name ?: "frame_${nearest.first}.jpg"
                        val folder = "%02d_%s_%s_%ds_%s".format(
                            index + 1, tr.result, tr.direction, tr.expiry, tr.id
                        )
                        val key = "$folder/${nearest.first}_$original"
                        selected[key] = nearest.second
                        count++
                    }
                    summary.append(
                        "${index + 1}. ${tr.result} | ${tr.direction} ${tr.expiry}s | " +
                        "signal=${tr.signalTs} | open=${tr.openTs} | result=${tr.resultTs} | " +
                        "id=${tr.id} | selected=$count\n"
                    )
                }

                if (selected.isEmpty()) {
                    error("Images were found, but none match the timestamps from the reviewed sessions. Make sure this is the folder from the same 71.7.27 memory export.")
                }

                val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
                val name = "LSA_ReviewPack_Photos_$stamp.zip"
                val values = ContentValues().apply {
                    put(MediaStore.Downloads.DISPLAY_NAME, name)
                    put(MediaStore.Downloads.MIME_TYPE, "application/zip")
                    put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
                }
                val outUri = contentResolver.insert(
                    MediaStore.Downloads.EXTERNAL_CONTENT_URI, values
                ) ?: error("Cannot create output ZIP")

                contentResolver.openOutputStream(outUri)!!.use { os ->
                    ZipOutputStream(BufferedOutputStream(os)).use { zip ->
                        zip.putNextEntry(ZipEntry("REVIEW_SUMMARY.txt"))
                        zip.write(summary.toString().toByteArray())
                        zip.closeEntry()

                        for ((key, file) in selected) {
                            zip.putNextEntry(ZipEntry("frames/$key"))
                            contentResolver.openInputStream(file.uri)!!.use { input ->
                                input.copyTo(zip)
                            }
                            zip.closeEntry()
                        }
                    }
                }

                runOnUiThread {
                    status.text =
                        "DONE ❤️\n$name saved in Downloads\n" +
                        "${selected.size} targeted images selected from ${photos.size} photos.\n" +
                        "Send this ZIP to ChatGPT."
                    run.isEnabled = true
                }
            } catch (e: Exception) {
                runOnUiThread {
                    status.text = "ERROR: ${e.message}"
                    run.isEnabled = true
                }
            }
        }.start()
    }

    private fun checkpointsFor(t: Target): List<Long> {
        val points = linkedSetOf<Long>()
        // Context before the signal.
        points += t.signalTs - 15_000
        points += t.signalTs - 10_000
        points += t.signalTs - 5_000
        points += t.signalTs

        // Manual execution and a few seconds after it.
        if (t.openTs > 0) {
            points += t.openTs
            points += t.openTs + 3_000
        }

        // Sample the life of the trade without copying hundreds of frames.
        val interval = when {
            t.expiry <= 60 -> 10_000L
            t.expiry <= 120 -> 20_000L
            t.expiry <= 180 -> 30_000L
            t.expiry <= 240 -> 40_000L
            else -> 50_000L
        }
        var p = t.signalTs + interval
        val expectedEnd = if (t.resultTs > 0) t.resultTs else t.signalTs + t.expiry * 1000L
        while (p < expectedEnd) {
            points += p
            p += interval
        }

        if (t.resultTs > 0) {
            points += t.resultTs - 5_000
            points += t.resultTs
            points += t.resultTs + 3_000
        }
        return points.toList().sorted()
    }

    private fun nearestPhoto(
        photos: List<Pair<Long, DocumentFile>>,
        target: Long
    ): Pair<Long, DocumentFile>? {
        if (photos.isEmpty()) return null
        var lo = 0
        var hi = photos.lastIndex
        while (lo <= hi) {
            val mid = (lo + hi) ushr 1
            if (photos[mid].first < target) lo = mid + 1 else hi = mid - 1
        }
        val candidates = mutableListOf<Pair<Long, DocumentFile>>()
        if (lo in photos.indices) candidates += photos[lo]
        if (lo - 1 in photos.indices) candidates += photos[lo - 1]
        return candidates.minByOrNull { abs(it.first - target) }
    }

    private fun collectPhotos(dir: DocumentFile, out: MutableList<Pair<Long, DocumentFile>>) {
        for (f in dir.listFiles()) {
            if (f.isDirectory) {
                collectPhotos(f, out)
            } else if (f.isFile) {
                val name = f.name ?: continue
                val match = Regex("""^(\d{13}).*\.(jpg|jpeg|png)$""", RegexOption.IGNORE_CASE)
                    .find(name) ?: continue
                val ts = match.groupValues[1].toLongOrNull() ?: continue
                out += ts to f
            }
        }
    }
}
