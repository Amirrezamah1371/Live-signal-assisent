package com.example.livesignalassistant

import android.graphics.Bitmap
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

data class SignalResult(
    val direction: String,
    val timeframeMinutes: Int,
    val confidence: Int
)

object SignalAnalyzer {
    // State is deliberately kept between captured frames. A single screenshot is not enough
    // to turn a visual pattern into a signal, so UP/DOWN needs repeated confirmation.
    private var candidate = "WAIT"
    private var candidateHits = 0

    @Synchronized
    fun analyze(bitmap: Bitmap): SignalResult {
        val w = bitmap.width
        val h = bitmap.height
        if (w < 200 || h < 300) return waitResult()

        // Work only on the chart's recent/right-hand region. We do NOT count total red vs green
        // pixels: that caused the old DOWN bias. Instead we estimate the vertical path of the
        // most recent coloured candle/price pixels from left -> right.
        val x0 = (w * 0.58f).toInt()
        val x1 = (w * 0.94f).toInt()
        val y0 = (h * 0.20f).toInt()
        val y1 = (h * 0.76f).toInt()
        val xStep = max(2, (x1 - x0) / 120)
        val yStep = 2

        val xs = ArrayList<Double>()
        val ys = ArrayList<Double>()

        var x = x0
        while (x < x1) {
            val hits = ArrayList<Int>()
            var y = y0
            while (y < y1) {
                val c = bitmap.getPixel(x, y)
                val r = (c shr 16) and 0xff
                val g = (c shr 8) and 0xff
                val b = c and 0xff

                // Saturated candle/price colours on a dark chart. Both bullish and bearish
                // colours are treated equally; colour itself never decides direction.
                val mx = max(r, max(g, b))
                val mn = min(r, min(g, b))
                val saturated = mx > 95 && (mx - mn) > 42
                val candleLike = saturated && (r > g + 22 || g > r + 22)
                if (candleLike) hits.add(y)
                y += yStep
            }

            // Median is robust to candle bodies/wicks and occasional coloured UI pixels.
            if (hits.size >= 2) {
                hits.sort()
                val medianY = hits[hits.size / 2].toDouble()
                xs.add(x.toDouble())
                ys.add(medianY)
            }
            x += xStep
        }

        // If the visual trace is sparse, refuse to guess.
        if (xs.size < 22) return waitResult()

        val n = xs.size.toDouble()
        val meanX = xs.sum() / n
        val meanY = ys.sum() / n
        var sxx = 0.0
        var syy = 0.0
        var sxy = 0.0
        for (i in xs.indices) {
            val dx = xs[i] - meanX
            val dy = ys[i] - meanY
            sxx += dx * dx
            syy += dy * dy
            sxy += dx * dy
        }
        if (sxx <= 0.0 || syy <= 0.0) return waitResult()

        // Screen Y grows downward: negative slope means price path rises to the right => UP.
        val slope = sxy / sxx
        val corr = sxy / sqrt(sxx * syy)
        val strength = abs(corr)
        val verticalMove = abs(slope) * (x1 - x0)

        // Require both coherent direction and meaningful movement. Sideways/noisy charts => WAIT.
        if (strength < 0.34 || verticalMove < h * 0.018) return waitResult()

        val rawDirection = if (slope < 0.0) "UP" else "DOWN"
        if (rawDirection == candidate) candidateHits++ else {
            candidate = rawDirection
            candidateHits = 1
        }

        // Three consecutive frames must agree. This also prevents one-frame flips.
        if (candidateHits < 3) return SignalResult("WAIT", 0, (strength * 100).toInt().coerceIn(0, 99))

        val confidence = (strength * 100).toInt().coerceIn(0, 99)
        val normalizedMove = (verticalMove / h).coerceAtMost(0.20)
        val timeframe = when {
            strength >= 0.78 && normalizedMove >= 0.070 -> 1
            strength >= 0.68 && normalizedMove >= 0.050 -> 2
            strength >= 0.58 -> 5
            strength >= 0.48 -> 10
            strength >= 0.40 -> 15
            else -> 20
        }
        return SignalResult(rawDirection, timeframe, confidence)
    }

    private fun waitResult(): SignalResult {
        candidate = "WAIT"
        candidateHits = 0
        return SignalResult("WAIT", 0, 0)
    }
}
