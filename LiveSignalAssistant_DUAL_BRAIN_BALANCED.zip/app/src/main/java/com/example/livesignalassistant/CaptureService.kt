package com.example.livesignalassistant

import android.app.*
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.*
import android.provider.Settings
import android.view.Gravity
import android.view.WindowManager
import android.widget.TextView
import android.widget.Toast
import androidx.core.app.NotificationCompat
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

class CaptureService:Service(){
 companion object{const val EXTRA_RESULT_CODE="result_code";const val EXTRA_RESULT_DATA="result_data";private const val CHANNEL_ID="lsa_promax";private const val NOTIFICATION_ID=1550}
 private var projection:MediaProjection?=null;private var imageReader:ImageReader?=null;private var virtualDisplay:VirtualDisplay?=null;private var cb:MediaProjection.Callback?=null
 private var overlay:TextView?=null;private var wm:WindowManager?=null;private val signalBubbles=mutableListOf<TextView>();private val main=Handler(Looper.getMainLooper());private val executor=Executors.newSingleThreadExecutor();private val busy=AtomicBoolean(false);private var last=0L
 override fun onCreate(){super.onCreate();channel();startForeground(NOTIFICATION_ID,NotificationCompat.Builder(this,CHANNEL_ID).setContentTitle("Live Signal DUAL BRAIN").setContentText("1m / 5m dual-brain analysis").setSmallIcon(android.R.drawable.ic_menu_view).setOngoing(true).build())}
 override fun onStartCommand(i:Intent?,f:Int,id:Int):Int{if(!Settings.canDrawOverlays(this)){Toast.makeText(this,"اجازه نمایش روی برنامه‌های دیگر فعال نیست",Toast.LENGTH_LONG).show();stopSelf();return START_NOT_STICKY};showOverlay();val code=i?.getIntExtra(EXTRA_RESULT_CODE,Activity.RESULT_CANCELED)?:Activity.RESULT_CANCELED;val data:Intent?=if(Build.VERSION.SDK_INT>=33)i?.getParcelableExtra(EXTRA_RESULT_DATA,Intent::class.java) else @Suppress("DEPRECATION") i?.getParcelableExtra(EXTRA_RESULT_DATA);if(code!=Activity.RESULT_OK||data==null){stopSelf();return START_NOT_STICKY};val mgr=getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager;projection=mgr.getMediaProjection(code,data);cb=object:MediaProjection.Callback(){override fun onStop(){main.post{stopSelf()}}};projection?.registerCallback(cb!!,main);capture();return START_NOT_STICKY}
 private fun bubbleBg(stroke:Int)=GradientDrawable().apply{setColor(0xEE151821.toInt());cornerRadius=34f;setStroke(2,stroke)}
 private fun showOverlay(){main.post{if(overlay!=null)return@post;wm=getSystemService(WINDOW_SERVICE) as WindowManager;val v=TextView(this).apply{text="DUAL BRAIN BAL · WAIT\nE0 · C100";textSize=15f;setPadding(24,12,24,12);setTextColor(0xFFFFFFFF.toInt());background=bubbleBg(0x887C8CFF.toInt());elevation=20f};val type=if(Build.VERSION.SDK_INT>=26)WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE;val lp=WindowManager.LayoutParams(WindowManager.LayoutParams.WRAP_CONTENT,WindowManager.LayoutParams.WRAP_CONTENT,type,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,PixelFormat.TRANSLUCENT).apply{gravity=Gravity.TOP or Gravity.START;x=30;y=220};wm!!.addView(v,lp);overlay=v;Toast.makeText(this,"DUAL BRAIN BALANCED فعال شد",Toast.LENGTH_SHORT).show()}}
 private fun capture(){val m=resources.displayMetrics;val w=m.widthPixels;val h=m.heightPixels;imageReader=ImageReader.newInstance(w,h,PixelFormat.RGBA_8888,2);virtualDisplay=projection?.createVirtualDisplay("V54Smart",w,h,m.densityDpi,DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,imageReader?.surface,null,main);imageReader?.setOnImageAvailableListener({r->val now=SystemClock.elapsedRealtime();if(now-last<550||busy.get()){r.acquireLatestImage()?.close();return@setOnImageAvailableListener};val im=r.acquireLatestImage()?:return@setOnImageAvailableListener;busy.set(true);last=now;try{val p=im.planes[0];val pad=p.rowStride-p.pixelStride*im.width;val tmp=Bitmap.createBitmap(im.width+pad/p.pixelStride,im.height,Bitmap.Config.ARGB_8888);tmp.copyPixelsFromBuffer(p.buffer);val b=Bitmap.createBitmap(tmp,0,0,im.width,im.height);tmp.recycle();executor.execute{try{val out=SignalAnalyzer.analyze(b);b.recycle();show(out)}catch(_:Throwable){if(!b.isRecycled)b.recycle()}finally{busy.set(false)}}}catch(_:Throwable){busy.set(false)}finally{im.close()}},main)}
 private fun label(s:Int)=if(s<60)"${s}s" else "${s/60}m"
 private fun show(r:SignalResult){main.post{overlay?.text=if(r.direction=="UP"||r.direction=="DOWN"){val a=if(r.direction=="UP")"↑" else "↓";"$a ${r.direction} · ${label(r.expirySeconds)} · NOW\nE${r.entryQuality} · C${r.conflict}"}else{"DUAL BRAIN BAL · WAIT\nE${r.entryQuality} · C${r.conflict}"};if(r.direction=="UP"||r.direction=="DOWN")spawnSignalBubble(r)}}
 private fun spawnSignalBubble(r:SignalResult){val manager=wm?:return;val type=if(Build.VERSION.SDK_INT>=26)WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE;val arrow=if(r.direction=="UP")"↑" else "↓";val v=TextView(this).apply{text="$arrow ${r.direction} · ${label(r.expirySeconds)} · NOW";textSize=13.5f;setSingleLine(true);setPadding(18,8,18,8);setTextColor(0xFFFFFFFF.toInt());background=bubbleBg(if(r.direction=="UP")0xAA55DD88.toInt() else 0xAAFF6B6B.toInt());elevation=22f};val lp=WindowManager.LayoutParams(WindowManager.LayoutParams.WRAP_CONTENT,WindowManager.LayoutParams.WRAP_CONTENT,type,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,PixelFormat.TRANSLUCENT).apply{gravity=Gravity.TOP or Gravity.END;x=18;y=220+(signalBubbles.size*58)};try{manager.addView(v,lp);signalBubbles+=v}catch(_:Throwable){return};main.postDelayed({try{manager.removeView(v)}catch(_:Throwable){};signalBubbles.remove(v);restackSignalBubbles()},8000)}
 private fun restackSignalBubbles(){val manager=wm?:return;signalBubbles.forEachIndexed{i,v->try{val lp=v.layoutParams as WindowManager.LayoutParams;lp.y=220+(i*58);manager.updateViewLayout(v,lp)}catch(_:Throwable){}}}
 private fun channel(){if(Build.VERSION.SDK_INT>=26)getSystemService(NotificationManager::class.java).createNotificationChannel(NotificationChannel(CHANNEL_ID,"Screen analysis",NotificationManager.IMPORTANCE_LOW))}
 override fun onDestroy(){imageReader?.setOnImageAvailableListener(null,null);virtualDisplay?.release();imageReader?.close();cb?.let{try{projection?.unregisterCallback(it)}catch(_:Throwable){}};try{projection?.stop()}catch(_:Throwable){};executor.shutdownNow();main.post{try{overlay?.let{wm?.removeView(it)}}catch(_:Throwable){};for(v in signalBubbles.toList())try{wm?.removeView(v)}catch(_:Throwable){};signalBubbles.clear();overlay=null};super.onDestroy()}
 override fun onBind(i:Intent?):IBinder?=null
}
