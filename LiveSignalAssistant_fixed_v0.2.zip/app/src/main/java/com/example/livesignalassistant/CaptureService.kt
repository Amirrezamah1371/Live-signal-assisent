package com.example.livesignalassistant

import android.app.*
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.Gravity
import android.view.WindowManager
import android.widget.TextView
import androidx.core.app.NotificationCompat
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.max

class CaptureService : Service() {

    companion object {
        const val EXTRA_RESULT_CODE = "result_code"
        const val EXTRA_RESULT_DATA = "result_data"
        private const val CHANNEL_ID = "lsa_capture"
        private const val NOTIFICATION_ID = 1001
    }

    private var projection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null
    private var overlay: TextView? = null
    private var wm: WindowManager? = null

    private val executor = Executors.newSingleThreadExecutor()
    private val busy = AtomicBoolean(false)
    private var lastAnalysisAt = 0L

    private val projectionCallback = object : MediaProjection.Callback() {
        override fun onStop() {
            cleanupCapture()
            stopSelf()
        }
    }

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()

        startForeground(
            NOTIFICATION_ID,
            NotificationCompat.Builder(this, CHANNEL_ID)
                .setContentTitle("Live Signal Assistant")
                .setContentText("در حال مشاهده و تحلیل صفحه")
                .setSmallIcon(android.R.drawable.ic_menu_view)
                .setOngoing(true)
                .build()
        )

        createOverlay()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val code = intent?.getIntExtra(EXTRA_RESULT_CODE, Activity.RESULT_CANCELED)
            ?: Activity.RESULT_CANCELED

        val data: Intent? = if (Build.VERSION.SDK_INT >= 33) {
            intent?.getParcelableExtra(EXTRA_RESULT_DATA, Intent::class.java)
        } else {
            @Suppress("DEPRECATION")
            intent?.getParcelableExtra(EXTRA_RESULT_DATA)
        }

        if (code != Activity.RESULT_OK || data == null) {
            stopSelf()
            return START_NOT_STICKY
        }

        try {
            val mgr =
                getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager

            projection = mgr.getMediaProjection(code, data)

            // Android 14+ requires a callback to be registered before capture starts.
            projection?.registerCallback(
                projectionCallback,
                Handler(Looper.getMainLooper())
            )

            startCapture()
        } catch (t: Throwable) {
            updateOverlayText("ERROR")
            stopSelf()
        }

        return START_NOT_STICKY
    }

    private fun startCapture() {
        val metrics = resources.displayMetrics
        val width = max(1, metrics.widthPixels)
        val height = max(1, metrics.heightPixels)
        val density = metrics.densityDpi

        imageReader = ImageReader.newInstance(
            width,
            height,
            PixelFormat.RGBA_8888,
            2
        )

        virtualDisplay = projection?.createVirtualDisplay(
            "LiveSignalAssistant",
            width,
            height,
            density,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            imageReader?.surface,
            null,
            null
        )

        imageReader?.setOnImageAvailableListener({ reader ->
            val now = System.currentTimeMillis()

            if (now - lastAnalysisAt < 650 || busy.get()) {
                reader.acquireLatestImage()?.close()
                return@setOnImageAvailableListener
            }

            val image = reader.acquireLatestImage()
                ?: return@setOnImageAvailableListener

            busy.set(true)
            lastAnalysisAt = now

            try {
                val plane = image.planes[0]
                val buffer = plane.buffer
                val pixelStride = plane.pixelStride
                val rowStride = plane.rowStride
                val rowPadding = rowStride - pixelStride * image.width

                val paddedWidth =
                    image.width + rowPadding / pixelStride

                val padded = Bitmap.createBitmap(
                    paddedWidth,
                    image.height,
                    Bitmap.Config.ARGB_8888
                )

                padded.copyPixelsFromBuffer(buffer)

                val bitmap = Bitmap.createBitmap(
                    padded,
                    0,
                    0,
                    image.width,
                    image.height
                )

                padded.recycle()

                executor.execute {
                    try {
                        val result = SignalAnalyzer.analyze(bitmap)
                        bitmap.recycle()
                        updateOverlay(result)
                    } catch (_: Throwable) {
                        if (!bitmap.isRecycled) bitmap.recycle()
                        updateOverlayText("WAIT")
                    } finally {
                        busy.set(false)
                    }
                }
            } catch (_: Throwable) {
                busy.set(false)
            } finally {
                image.close()
            }
        }, Handler(Looper.getMainLooper()))
    }

    private fun createOverlay() {
        wm = getSystemService(WINDOW_SERVICE) as WindowManager

        overlay = TextView(this).apply {
            text = "WAIT"
            textSize = 18f
            setPadding(24, 14, 24, 14)
            setBackgroundColor(0xCC202020.toInt())
            setTextColor(0xFFFFFFFF.toInt())
        }

        val type =
            if (Build.VERSION.SDK_INT >= 26)
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            else {
                @Suppress("DEPRECATION")
                WindowManager.LayoutParams.TYPE_PHONE
            }

        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.END
            x = 24
            y = 180
        }

        try {
            wm?.addView(overlay, lp)
        } catch (_: Throwable) {
            overlay = null
        }
    }

    private fun updateOverlay(result: SignalResult) {
        val text = when (result.direction) {
            "UP" -> "↑ UP  ${result.timeframeMinutes}m"
            "DOWN" -> "↓ DOWN  ${result.timeframeMinutes}m"
            else -> "WAIT"
        }
        updateOverlayText(text)
    }

    private fun updateOverlayText(text: String) {
        overlay?.post {
            overlay?.text = text
        }
    }

    private fun cleanupCapture() {
        try {
            imageReader?.setOnImageAvailableListener(null, null)
        } catch (_: Throwable) {}

        try {
            imageReader?.close()
        } catch (_: Throwable) {}

        try {
            virtualDisplay?.release()
        } catch (_: Throwable) {}

        imageReader = null
        virtualDisplay = null
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(
                NotificationChannel(
                    CHANNEL_ID,
                    "Screen analysis",
                    NotificationManager.IMPORTANCE_LOW
                )
            )
        }
    }

    override fun onDestroy() {
        cleanupCapture()

        try {
            projection?.unregisterCallback(projectionCallback)
        } catch (_: Throwable) {}

        try {
            projection?.stop()
        } catch (_: Throwable) {}

        try {
            overlay?.let { wm?.removeView(it) }
        } catch (_: Throwable) {}

        executor.shutdownNow()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
