Live Signal Assistant 0.2.0

اصلاح اصلی این نسخه:
- سازگاری بهتر MediaProjection با Android 14/15/16
- ثبت MediaProjection.Callback پیش از شروع capture
- آزادسازی صحیح VirtualDisplay و ImageReader
- Java/Kotlin هر دو روی JVM 17

این برنامه معامله را خودکار اجرا نمی‌کند.
