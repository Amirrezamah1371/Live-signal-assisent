package com.example.livesignalassistant

import android.graphics.Bitmap
import android.os.SystemClock
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

data class SignalResult(
    val direction:String, val expirySeconds:Int, val confidence:Int,
    val entryQuality:Int=0, val conflict:Int=100, val reason:String="",
    val upScore:Int=0, val downScore:Int=0, val signalQuality:Int=0
)

/**
 * PRO MAX DUAL BRAIN — 1m / 5m only.
 * Screen-only decision engine. No trade execution and no fabricated win probability.
 *
 * Design goals:
 *  - robust chart extraction before prediction
 *  - horizon-specific scoring rather than one shared threshold
 *  - regime / trend-efficiency awareness
 *  - continuation vs pullback/reversal vs exhaustion separation
 *  - temporal smoothing to avoid one-frame velocity/acceleration noise
 *  - evidence-based anti-flip and same-wave de-duplication
 *  - bounded signal bursts without a blind global cooldown
 */
object SignalAnalyzer {
    private data class View(val p:List<Double>, val floor:Double, val efficiency:Double, val volatility:Double)
    private data class C(
        val sign:Int,val expiry:Int,val score:Double,val entry:Double,val conflict:Double,
        val reason:String,val marginHint:Double,val regime:Double,val freshness:Double
    )
    private data class Last(val at:Long,val sign:Int,val score:Double,val entry:Double,val reason:String,val anchor:Double)
    private data class Extracted(val p:List<Double>, val quality:Double)

    private val votes=mutableMapOf<Int,ArrayDeque<Int>>()
    private val lastByHorizon=mutableMapOf<Int,Last>()
    private val temporal=ArrayDeque<Pair<Long,Double>>()
    private var emaVelocity=0.0
    private var prevEmaVelocity=0.0
    private var lastFrameAt=0L

    @Synchronized fun reset(){
        votes.clear();lastByHorizon.clear();temporal.clear()
        emaVelocity=0.0;prevEmaVelocity=0.0;lastFrameAt=0L
    }

    @Synchronized fun analyze(b:Bitmap):SignalResult{
        if(b.width<240||b.height<360) return wait("LOW_VIS")
        val ex=extractPath(b)
        if(ex.p.size<78 || ex.quality<.48) return wait("LOW_VIS")

        val all=hampel(smooth(ex.p,2),3,3.2)
        val n=all.size
        if(n<72) return wait("LOW_VIS")
        val wide=mk(all,b.height)
        val structure=mk(all.subList((n*.25).toInt(),n),b.height)
        val entry=mk(all.subList((n*.60).toInt(),n),b.height)
        val micro=mk(all.subList((n*.80).toInt(),n),b.height)
        val right=median(micro.p.takeLast(max(4,micro.p.size/6)))
        val now=SystemClock.elapsedRealtime()
        updateTemporal(now,right,micro.floor)
        val accel=(emaVelocity-prevEmaVelocity)/max(.45,(now-lastFrameAt).coerceAtLeast(1)/1000.0)
        prevEmaVelocity=emaVelocity;lastFrameAt=now

        val horizons=intArrayOf(60,300)
        val winners=ArrayList<Pair<C,C>>()
        var globalUp=0.0;var globalDown=0.0
        for(e in horizons){
            val up=candidate(1,e,wide,structure,entry,micro,emaVelocity,accel,ex.quality)
            val dn=candidate(-1,e,wide,structure,entry,micro,emaVelocity,accel,ex.quality)
            globalUp=max(globalUp,up.score);globalDown=max(globalDown,dn.score)
            winners += if(up.score>=dn.score) up to dn else dn to up
        }

        // Evaluate each horizon independently first; only then choose the most actionable one.
        val eligible=ArrayList<Pair<C,Double>>()
        for((best,opp) in winners){
            val margin=best.score-opp.score
            val gates=gates(best.expiry)
            if(best.score<gates[0]||best.entry<gates[1]||best.conflict>gates[2]||margin<gates[3]) continue
            if(best.regime<gates[4] && best.reason=="CONT") continue
            if(best.reason=="EXH") continue

            val q=votes.getOrPut(best.expiry){ArrayDeque()};q.addLast(best.sign);while(q.size>6)q.removeFirst()
            val persistence=q.count{it==best.sign}
            val fastPass=if(best.expiry==60)86.0 else 81.0
            val need=when(best.expiry){60->3;else->2}
            if(best.score<fastPass && (q.size<3||persistence<need)) continue

            // Fairness is tiny and only prevents 5m from starving other valid horizons.
            val age=lastByHorizon[best.expiry]?.let{((now-it.at)/1000.0).coerceAtMost(90.0)}?:90.0
            val readiness=margin*.85+best.entry*.16+(100-best.conflict)*.10+best.freshness*7+min(4.0,age/25.0)
            eligible+=best to readiness
        }
        if(eligible.isEmpty()) return SignalResult("WAIT",0,max(globalUp,globalDown).toInt(),0,100,"FILTER",globalUp.toInt(),globalDown.toInt(),(ex.quality*100).toInt())

        val best=eligible.maxByOrNull{it.second}!!.first
        val sameH=winners.first{it.first.expiry==best.expiry}
        val opp=if(sameH.first.sign==best.sign)sameH.second else sameH.first
        val margin=best.score-opp.score

        val last=lastByHorizon[best.expiry]
        if(last!=null){
            val age=now-last.at
            if(best.sign==-last.sign && age<if(best.expiry==60)20_000L else 34_000L){
                val moved=abs(right-last.anchor)/micro.floor
                val reversalStrength=(best.score-last.score)+(best.entry-last.entry)*.40+margin*.60
                val structural=best.reason=="REV"||best.reason=="BRK"
                val requiredMove=if(best.expiry==60)1.20 else .95
                if(moved<requiredMove || (!structural && reversalStrength<when(best.expiry){60->17.0;else->15.0}))
                    return SignalResult("WAIT",0,best.score.toInt(),best.entry.toInt(),best.conflict.toInt(),"ANTI_FLIP",globalUp.toInt(),globalDown.toInt(),(ex.quality*100).toInt())
            }
            val repeatWindow=if(best.expiry==60)38_000L else 64_000L
            if(best.sign==last.sign && age<repeatWindow){
                val moved=abs(right-last.anchor)/micro.floor
                val newStructure=(best.reason!=last.reason && (best.reason=="BRK"||best.reason=="REV"))
                val materiallyBetter=best.score>=last.score+6.0 && best.entry>=last.entry+3.0
                if(!(moved>=1.35 && (newStructure||materiallyBetter)))
                    return SignalResult("WAIT",0,best.score.toInt(),best.entry.toInt(),best.conflict.toInt(),"SAME_WAVE",globalUp.toInt(),globalDown.toInt(),(ex.quality*100).toInt())
            }
        }

        lastByHorizon[best.expiry]=Last(now,best.sign,best.score,best.entry,best.reason,right)
        return SignalResult(if(best.sign>0)"UP" else "DOWN",best.expiry,best.score.toInt(),best.entry.toInt(),best.conflict.toInt(),best.reason,globalUp.toInt(),globalDown.toInt(),(ex.quality*100).toInt())
    }

    private fun gates(e:Int)=if(e==60)
        doubleArrayOf(72.0,58.0,43.0,10.0,.34)
    else doubleArrayOf(66.0,51.0,51.0,7.5,.29)

    private fun extractPath(b:Bitmap):Extracted{
        val w=b.width;val h=b.height
        // Keep clear of Pocket Option header, bottom controls and right-side action panel.
        val x0=(w*.055).toInt();val x1=(w*.785).toInt();val y0=(h*.135).toInt();val y1=(h*.775).toInt()
        val step=max(2,(x1-x0)/330);val raw=ArrayList<Double>();var valid=0;var sampled=0;var x=x0
        while(x<x1){sampled++;val hits=ArrayList<Int>();var y=y0
            while(y<y1){
                val c=b.getPixel(x,y);val r=(c shr 16)and 255;val g=(c shr 8)and 255;val bl=c and 255
                val hi=max(r,max(g,bl));val lo=min(r,min(g,bl));val chroma=hi-lo
                // Candle/line colours are saturated; grey grid/text is deliberately excluded.
                if(hi>=92 && chroma>=42 && !(bl>r+35 && bl>g+18)) hits+=y
                y+=2
            }
            if(hits.size in 2..110){
                hits.sort()
                // Densest local vertical cluster is more robust than the median of every coloured UI pixel.
                var bestA=0;var bestB=0;var a=0
                for(j in hits.indices){while(hits[j]-hits[a]>max(16,(h*.020).toInt()))a++;if(j-a>bestB-bestA){bestA=a;bestB=j}}
                if(bestB-bestA+1>=2){raw+=-median(hits.subList(bestA,bestB+1).map{it.toDouble()});valid++}
            }
            x+=step
        }
        val coverage=valid.toDouble()/max(1,sampled)
        val quality=((coverage-.18)/.62).coerceIn(0.0,1.0)
        return Extracted(raw,quality)
    }

    private fun updateTemporal(now:Long,right:Double,floor:Double){
        temporal.addLast(now to right)
        while(temporal.isNotEmpty()&&now-temporal.first().first>12_000L)temporal.removeFirst()
        if(temporal.size<2){emaVelocity=0.0;return}
        val recent=temporal.toList()
        val slopes=ArrayList<Double>()
        for(i in max(0,recent.size-7) until recent.size-1){
            val dt=(recent.last().first-recent[i].first)/1000.0
            if(dt>.20) slopes+=(recent.last().second-recent[i].second)/dt
        }
        val robust=if(slopes.isEmpty())0.0 else median(slopes)
        val clipped=robust.coerceIn(-floor*4.0,floor*4.0)
        emaVelocity=.68*emaVelocity+.32*clipped
    }

    private fun mk(p:List<Double>,h:Int):View{
        val d=p.zipWithNext{a,c->c-a};val absD=d.map{abs(it)}
        val floor=max(h*.0015,median(absD).coerceAtLeast(1.0)*.92)
        val net=abs(p.last()-p.first());val path=d.sumOf{abs(it)}.coerceAtLeast(floor)
        val efficiency=(net/path).coerceIn(0.0,1.0)
        val vol=sqrt(d.map{it*it}.average().coerceAtLeast(.0))/floor
        return View(p,floor,efficiency,vol)
    }

    private fun candidate(sign:Int,e:Int,w:View,s:View,en:View,m:View,velocity:Double,accel:Double,vis:Double):C{
        fun mv(v:View,a:Double,b:Double):Double{val n=v.p.size;val i=(n*a).toInt().coerceIn(0,n-2);val j=(n*b).toInt().coerceIn(i+2,n);val q=max(2,(j-i)/4);return median(v.p.subList(j-q,j))-median(v.p.subList(i,i+q))}
        fun align(v:Double,f:Double,k:Double)=((sign*v)/(f*k)).coerceIn(-1.0,1.0)
        val wa=align(mv(w,.05,.96),w.floor,3.5);val sa=align(mv(s,.18,.98),s.floor,2.6)
        val ea=align(mv(en,.34,1.0),en.floor,1.65);val ma=align(mv(m,.38,1.0),m.floor,.95)
        val va=align(velocity,m.floor,1.20);val aa=align(accel,m.floor,2.5)

        val hist=s.p.dropLast(max(3,s.p.size/10));val sup=percentile(hist,.10);val res=percentile(hist,.90)
        val r=median(m.p.takeLast(max(4,m.p.size/6)));val span=(res-sup).coerceAtLeast(s.floor*4)
        val pos=((r-sup)/span).coerceIn(-.6,1.6)
        val level=if(sign>0)((.52-pos)/.52).coerceIn(0.0,1.0) else ((pos-.48)/.52).coerceIn(0.0,1.0)
        val breakout=if(sign>0)((r-res)/(s.floor*1.5)).coerceIn(0.0,1.0) else ((sup-r)/(s.floor*1.5)).coerceIn(0.0,1.0)

        val ds=m.p.zipWithNext{a,c->c-a};var flips=0;var last=0
        for(d in ds){val z=if(d>m.floor*.12)1 else if(d< -m.floor*.12)-1 else 0;if(z!=0){if(last!=0&&z!=last)flips++;last=z}}
        val chop=flips.toDouble()/max(1,ds.size-1)
        val regime=(.48*s.efficiency+.30*en.efficiency+.22*m.efficiency).coerceIn(0.0,1.0)

        val weights=if(e==60)
            doubleArrayOf(.13,.24,.31,.21,.08,.03)
        else doubleArrayOf(.27,.38,.24,.06,.04,.01)
        val aligned=listOf(wa,sa,ea,ma,va,aa);var directional=0.0
        for(i in aligned.indices)directional+=max(0.0,aligned[i])*weights[i]
        val opposite=max(0.0,-ma)*.27+max(0.0,-ea)*.30+max(0.0,-sa)*.29+max(0.0,-wa)*.10+max(0.0,-va)*.04

        val turn=max(0.0,ma)*.45+max(0.0,ea)*.35+max(0.0,va)*.20
        val reversal=(level*max(0.0,-sa)*turn).coerceIn(0.0,1.0)
        val continuation=(max(0.0,wa)*max(0.0,sa)*(.55+.45*max(0.0,ea))*regime).coerceIn(0.0,1.0)
        val timing=(.43*max(0.0,ma)+.31*max(0.0,ea)+.18*max(0.0,va)+.08*max(0.0,aa)).coerceIn(0.0,1.0)

        // Historical Similarity Engine: shape match is evidence only when earlier analogues
        // also agree on the subsequent direction. It never overrides a violent live reversal.
        val histEvidence=historicalSimilarity(sign,w.p,w.floor,e)

        val extension=if(sign>0)((r-res)/(s.floor*2.0)).coerceIn(0.0,1.5) else ((sup-r)/(s.floor*2.0)).coerceIn(0.0,1.5)
        val fading=(max(0.0,sa)*max(0.0,-ma)+max(0.0,ea)*max(0.0,-va)).coerceIn(0.0,1.0)
        val volShock=((m.volatility-1.45)/1.8).coerceIn(0.0,1.0)
        val exhaustion=(extension*.46+fading*.72+max(0.0,-aa)*.18+volShock*.18).coerceIn(0.0,1.0)

        // A breakout is actionable only with follow-through, not merely because price crossed a level.
        val followThrough=(.48*max(0.0,ma)+.32*max(0.0,ea)+.20*max(0.0,va)).coerceIn(0.0,1.0)
        val breakoutQuality=(breakout*followThrough*(.55+.45*regime)).coerceIn(0.0,1.0)
        val freshness=(max(reversal,max(breakoutQuality,timing*.70+regime*.30))-exhaustion*.45).coerceIn(0.0,1.0)

        // Independent engines meet here: live direction, structure, timing, regime and historical analogue.
        // History has deliberately bounded weight; fresh price action remains dominant.
        val entryQ=(38+35*timing+17*max(0.0,ea)+9*level+10*breakoutQuality+7*regime+4*vis+5*histEvidence-24*chop-14*max(0.0,-va)-19*exhaustion).coerceIn(0.0,100.0)
        val conflict=(100*(opposite*.66+chop*.20+exhaustion*.10+(1-regime)*.04) - histEvidence*4).coerceIn(0.0,100.0)
        val score=(36+directional*49+reversal*10+continuation*9+breakoutQuality*7+timing*6+regime*5+vis*3+histEvidence*7+entryQ*.08-conflict*.19-exhaustion*10).coerceIn(0.0,97.0)
        val reason=when{
            exhaustion>.60->"EXH"
            reversal>.43&&turn>.38->"REV"
            breakoutQuality>.42->"BRK"
            continuation>.34&&regime>.30->"CONT"
            else->"MOM"
        }
        return C(sign,e,score,entryQ,conflict,reason,0.0,regime,freshness)
    }

    private fun historicalSimilarity(sign:Int,p:List<Double>,floor:Double,e:Int):Double{
        // Uses only already-visible candles/price path: no look-ahead beyond each historical analogue.
        val win=if(e==60) 24 else 42
        val future=if(e==60) 8 else 18
        if(p.size < win*2+future+8) return 0.0
        val cur=p.takeLast(win)
        fun norm(a:List<Double>):List<Double>{
            val base=a.first(); val scale=max(floor,a.zipWithNext{u,v->abs(v-u)}.average()*2.2)
            return a.map{(it-base)/scale}
        }
        val cn=norm(cur); var weighted=0.0; var mass=0.0
        val end=p.size-win-future-3
        var i=4
        while(i<=end){
            val old=p.subList(i,i+win); val on=norm(old)
            var mse=0.0
            for(k in cn.indices){val d=cn[k]-on[k];mse+=d*d}
            mse/=cn.size
            val sim=(1.0/(1.0+mse)).coerceIn(0.0,1.0)
            if(sim>.68){
                val after=median(p.subList(i+win,i+win+future))-median(p.subList(i+win-3,i+win))
                val outcome=(sign*after/(floor*2.2)).coerceIn(-1.0,1.0)
                val w=(sim-.68)/.32
                weighted+=w*outcome; mass+=w
            }
            i+=max(3,win/6)
        }
        if(mass<.55)return 0.0
        return (weighted/mass).coerceIn(-1.0,1.0).coerceAtLeast(0.0)
    }

    private fun smooth(v:List<Double>,r:Int)=v.indices.map{i->median(v.subList(max(0,i-r),min(v.size,i+r+1)))}
    private fun hampel(v:List<Double>,r:Int,k:Double):List<Double>{
        if(v.size<2*r+1)return v
        return v.indices.map{i->
            val a=max(0,i-r);val z=min(v.size,i+r+1);val win=v.subList(a,z);val med=median(win)
            val mad=median(win.map{abs(it-med)}).coerceAtLeast(.5)
            if(abs(v[i]-med)>k*1.4826*mad)med else v[i]
        }
    }
    private fun median(v:List<Double>):Double{if(v.isEmpty())return 0.0;val s=v.sorted();return if(s.size%2==1)s[s.size/2] else (s[s.size/2-1]+s[s.size/2])/2}
    private fun percentile(v:List<Double>,q:Double):Double{if(v.isEmpty())return 0.0;val s=v.sorted();return s[((s.size-1)*q).toInt().coerceIn(0,s.size-1)]}
    private fun wait(r:String)=SignalResult("WAIT",0,0,0,100,r,0,0,0)
}
