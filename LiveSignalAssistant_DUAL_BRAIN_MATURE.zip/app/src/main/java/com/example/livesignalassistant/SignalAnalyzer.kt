package com.example.livesignalassistant

import android.graphics.Bitmap
import android.os.SystemClock
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

data class SignalResult(
    val direction:String, val expirySeconds:Int, val confidence:Int,
    val entryQuality:Int=0, val conflict:Int=100, val reason:String="",
    val upScore:Int=0, val downScore:Int=0, val signalQuality:Int=0
)

/**
 * PRO MAX DUAL BRAIN ACCURACY — 1m / 5m only.
 * Screen-only decision engine. No trade execution and no fabricated win probability.
 *
 * Design goals:
 *  - robust chart extraction before prediction
 *  - horizon-specific scoring rather than one shared threshold
 *  - regime / trend-efficiency awareness
 *  - continuation vs pullback/reversal vs exhaustion separation
 *  - temporal smoothing to avoid one-frame velocity/acceleration noise
 *  - evidence-based anti-flip and same-wave de-duplication
 *  - setup-state de-duplication without fixed signal quotas or blind cooldowns
 */
object SignalAnalyzer {
    private data class View(val p:List<Double>, val floor:Double, val efficiency:Double, val volatility:Double)
    private data class C(
        val sign:Int,val expiry:Int,val score:Double,val entry:Double,val conflict:Double,
        val reason:String,val marginHint:Double,val regime:Double,val freshness:Double,
        val timingScore:Double,val timingReady:Boolean
    )
    private data class Extracted(val p:List<Double>, val quality:Double)

    private val temporal=ArrayDeque<Pair<Long,Double>>()
    private var emaVelocity=0.0
    private var prevEmaVelocity=0.0
    private var lastFrameAt=0L

    @Synchronized fun reset(){
        temporal.clear()
        emaVelocity=0.0;prevEmaVelocity=0.0;lastFrameAt=0L
    }

    @Synchronized fun analyze(b:Bitmap):SignalResult{
        if(b.width<240||b.height<360) return wait("LOW_VIS")
        val ex=extractPath(b)
        if(ex.p.size<78 || ex.quality<.48) return wait("LOW_VIS")

        val all=hampel(smooth(ex.p,2),3,3.2)
        val n=all.size
        if(n<72) return wait("LOW_VIS")
        val wide=mk(all,b.height)
        val structure=mk(all.subList((n*.25).toInt(),n),b.height)
        val entry=mk(all.subList((n*.60).toInt(),n),b.height)
        val micro=mk(all.subList((n*.80).toInt(),n),b.height)
        val right=median(micro.p.takeLast(max(4,micro.p.size/6)))
        val now=SystemClock.elapsedRealtime()
        updateTemporal(now,right,micro.floor)
        val accel=(emaVelocity-prevEmaVelocity)/max(.45,(now-lastFrameAt).coerceAtLeast(1)/1000.0)
        prevEmaVelocity=emaVelocity;lastFrameAt=now

        val horizons=intArrayOf(60,300)
        val winners=ArrayList<Pair<C,C>>()
        var globalUp=0.0;var globalDown=0.0
        for(e in horizons){
            val up=candidate(1,e,wide,structure,entry,micro,emaVelocity,accel,ex.quality)
            val dn=candidate(-1,e,wide,structure,entry,micro,emaVelocity,accel,ex.quality)
            globalUp=max(globalUp,up.score);globalDown=max(globalDown,dn.score)
            winners += if(up.score>=dn.score) up to dn else dn to up
        }

        // Evaluate each horizon independently first; only then choose the most actionable one.
        val eligible=ArrayList<Pair<C,Double>>()
        for((best,opp) in winners){
            val margin=best.score-opp.score
            val gates=gates(best.expiry)
            if(best.reason=="EXH") continue

            // Evidence fusion: no single weak engine gets a veto. Strong fresh setups can
            // pass immediately; ordinary setups need broader agreement and temporal support.
            val structural=best.reason=="REV" || best.reason=="BRK"
            // Stage 1: Direction Brain. Direction is judged without forcing an entry.
            val strongDirection=best.score>=gates[0]+4 && margin>=gates[3]+2 && best.conflict<=gates[2]+5
            val normalDirection=best.score>=gates[0] && margin>=gates[3] && best.conflict<=gates[2]
            if(!(strongDirection || normalDirection)) continue
            if(best.regime<gates[4] && best.reason=="CONT" && !strongDirection) continue

            // Stage 2: Entry-Timing Brain. A correct direction is NOT automatically NOW.
            // No signal quota/cooldown is used: this gate only asks whether the present
            // microstructure is a suitable entry window for the selected expiry.
            if(!best.timingReady) continue

            val readiness=margin*.88+best.entry*.16+(100-best.conflict)*.10+
                best.timingScore*14+best.freshness*7+best.regime*3+(if(structural)2.0 else 0.0)
            eligible+=best to readiness
        }
        if(eligible.isEmpty()){
            val observed=winners.map{it.first}.maxByOrNull{it.score}!!
            return SignalResult("WAIT",0,observed.score.toInt(),observed.entry.toInt(),observed.conflict.toInt(),"FILTER",globalUp.toInt(),globalDown.toInt(),(ex.quality*100).toInt())
        }

        val best=eligible.maxByOrNull{it.second}!!.first
        val sameH=winners.first{it.first.expiry==best.expiry}
        val opp=if(sameH.first.sign==best.sign)sameH.second else sameH.first
        val margin=best.score-opp.score

        // Frequency is not gated here. Reversal and continuation are decided from live evidence,
        // structure, timing and historical analogue; no blind anti-flip or same-wave quota.
        return SignalResult(if(best.sign>0)"UP" else "DOWN",best.expiry,best.score.toInt(),best.entry.toInt(),best.conflict.toInt(),best.reason,globalUp.toInt(),globalDown.toInt(),(ex.quality*100).toInt())
    }

    private fun gates(e:Int)=if(e==60)
        doubleArrayOf(69.0,54.0,49.0,8.5,.30)
    else doubleArrayOf(65.0,50.0,53.0,7.0,.27)

    private fun extractPath(b:Bitmap):Extracted{
        val w=b.width;val h=b.height
        // Two-pass chart-trace extraction. Pocket Option's price trace is blue, but the screen
        // also contains blue horizontal price/UI lines. First collect blue edge candidates,
        // then penalize y-levels that repeat across many columns (horizontal UI/price lines).
        val x0=(w*.045).toInt();val x1=(w*.790).toInt();val y0=(h*.195).toInt();val y1=(h*.630).toInt()
        val step=max(2,(x1-x0)/360)
        val columns=ArrayList<ArrayList<Pair<Int,Double>>>()
        val yFreq=mutableMapOf<Int,Int>();var sampled=0;var x=x0
        fun lum(z:Int):Int{val rr=(z shr 16)and 255;val gg=(z shr 8)and 255;val bb=z and 255;return (rr*3+gg*6+bb)/10}
        while(x<x1){
            sampled++;val cands=ArrayList<Pair<Int,Double>>();var y=y0+2
            while(y<y1-2){
                val c=b.getPixel(x,y);val r=(c shr 16)and 255;val g=(c shr 8)and 255;val bl=c and 255
                val blueDom=bl-r;val cyanDom=g-r;val bg=bl-g
                if(bl>=105 && blueDom>=38 && cyanDom>=14 && bg in 8..88){
                    val edge=abs(lum(b.getPixel(x,y-2))-lum(b.getPixel(x,y+2))).toDouble()
                    val darkness=(220-(r+g+bl)/3).coerceAtLeast(0).toDouble()
                    val base=blueDom*.85+cyanDom*.35+edge*.75+darkness*.20
                    if(base>43){cands+=y to base;val bin=y/4;yFreq[bin]=(yFreq[bin]?:0)+1}
                }
                y+=2
            }
            columns+=cands;x+=step
        }
        val raw=ArrayList<Double>();var prevY:Double?=null
        for(cands in columns){
            var bestY=-1;var bestScore=-1e9
            for((y,base) in cands){
                val freq=(yFreq[y/4]?:0).toDouble()/max(1,sampled)
                // Horizontal overlays repeat at almost the same y across the chart; the real trace does not.
                var score=base-max(0.0,freq-.08)*220.0
                prevY?.let{py->score-=max(0.0,abs(y-py)-h*.055)*.22}
                if(score>bestScore){bestScore=score;bestY=y}
            }
            if(bestY>=0 && bestScore>40){raw+=-bestY.toDouble();prevY=bestY.toDouble()}
        }
        val coverage=raw.size.toDouble()/max(1,sampled)
        if(raw.size<50)return Extracted(raw,0.0)
        val jumps=raw.zipWithNext{u,v->abs(v-u)};val medJump=median(jumps).coerceAtLeast(1.0)
        val wild=jumps.count{it>max(h*.075,medJump*8)}.toDouble()/max(1,jumps.size)
        val quality=(coverage*.92+(1-wild)*.18-.10).coerceIn(0.0,1.0)
        return Extracted(raw,quality)
    }

    private fun updateTemporal(now:Long,right:Double,floor:Double){
        temporal.addLast(now to right)
        while(temporal.isNotEmpty()&&now-temporal.first().first>12_000L)temporal.removeFirst()
        if(temporal.size<2){emaVelocity=0.0;return}
        val recent=temporal.toList()
        val slopes=ArrayList<Double>()
        for(i in max(0,recent.size-7) until recent.size-1){
            val dt=(recent.last().first-recent[i].first)/1000.0
            if(dt>.20) slopes+=(recent.last().second-recent[i].second)/dt
        }
        val robust=if(slopes.isEmpty())0.0 else median(slopes)
        val clipped=robust.coerceIn(-floor*4.0,floor*4.0)
        emaVelocity=.68*emaVelocity+.32*clipped
    }

    private fun mk(p:List<Double>,h:Int):View{
        val d=p.zipWithNext{a,c->c-a};val absD=d.map{abs(it)}
        val floor=max(h*.0015,median(absD).coerceAtLeast(1.0)*.92)
        val net=abs(p.last()-p.first());val path=d.sumOf{abs(it)}.coerceAtLeast(floor)
        val efficiency=(net/path).coerceIn(0.0,1.0)
        val vol=sqrt(d.map{it*it}.average().coerceAtLeast(.0))/floor
        return View(p,floor,efficiency,vol)
    }

    private fun candidate(sign:Int,e:Int,w:View,s:View,en:View,m:View,velocity:Double,accel:Double,vis:Double):C{
        fun mv(v:View,a:Double,b:Double):Double{val n=v.p.size;val i=(n*a).toInt().coerceIn(0,n-2);val j=(n*b).toInt().coerceIn(i+2,n);val q=max(2,(j-i)/4);return median(v.p.subList(j-q,j))-median(v.p.subList(i,i+q))}
        fun align(v:Double,f:Double,k:Double)=((sign*v)/(f*k)).coerceIn(-1.0,1.0)
        val wa=align(mv(w,.05,.96),w.floor,3.5);val sa=align(mv(s,.18,.98),s.floor,2.6)
        val ea=align(mv(en,.34,1.0),en.floor,1.65);val ma=align(mv(m,.38,1.0),m.floor,.95)
        val va=align(velocity,m.floor,1.20);val aa=align(accel,m.floor,2.5)

        val hist=s.p.dropLast(max(3,s.p.size/10));val sup=percentile(hist,.10);val res=percentile(hist,.90)
        val r=median(m.p.takeLast(max(4,m.p.size/6)));val span=(res-sup).coerceAtLeast(s.floor*4)
        val pos=((r-sup)/span).coerceIn(-.6,1.6)
        val level=if(sign>0)((.52-pos)/.52).coerceIn(0.0,1.0) else ((pos-.48)/.52).coerceIn(0.0,1.0)
        val breakout=if(sign>0)((r-res)/(s.floor*1.5)).coerceIn(0.0,1.0) else ((sup-r)/(s.floor*1.5)).coerceIn(0.0,1.0)

        val ds=m.p.zipWithNext{a,c->c-a};var flips=0;var last=0
        for(d in ds){val z=if(d>m.floor*.12)1 else if(d< -m.floor*.12)-1 else 0;if(z!=0){if(last!=0&&z!=last)flips++;last=z}}
        val chop=flips.toDouble()/max(1,ds.size-1)
        val regime=(.48*s.efficiency+.30*en.efficiency+.22*m.efficiency).coerceIn(0.0,1.0)

        val weights=if(e==60)
            doubleArrayOf(.13,.24,.31,.21,.08,.03)
        else doubleArrayOf(.27,.38,.24,.06,.04,.01)
        val aligned=listOf(wa,sa,ea,ma,va,aa);var directional=0.0
        for(i in aligned.indices)directional+=max(0.0,aligned[i])*weights[i]
        val opposite=max(0.0,-ma)*.27+max(0.0,-ea)*.30+max(0.0,-sa)*.29+max(0.0,-wa)*.10+max(0.0,-va)*.04

        val turn=max(0.0,ma)*.45+max(0.0,ea)*.35+max(0.0,va)*.20
        val reversal=(level*max(0.0,-sa)*turn).coerceIn(0.0,1.0)
        val continuation=(max(0.0,wa)*max(0.0,sa)*(.55+.45*max(0.0,ea))*regime).coerceIn(0.0,1.0)
        val timing=(.43*max(0.0,ma)+.31*max(0.0,ea)+.18*max(0.0,va)+.08*max(0.0,aa)).coerceIn(0.0,1.0)

        // Historical Similarity Engine: shape match is evidence only when earlier analogues
        // also agree on the subsequent direction. It never overrides a violent live reversal.
        val histEvidence=historicalSimilarity(sign,w.p,w.floor,e)

        val extension=if(sign>0)((r-res)/(s.floor*2.0)).coerceIn(0.0,1.5) else ((sup-r)/(s.floor*2.0)).coerceIn(0.0,1.5)
        val fading=(max(0.0,sa)*max(0.0,-ma)+max(0.0,ea)*max(0.0,-va)).coerceIn(0.0,1.0)
        val volShock=((m.volatility-1.45)/1.8).coerceIn(0.0,1.0)
        val exhaustion=(extension*.46+fading*.72+max(0.0,-aa)*.18+volShock*.18).coerceIn(0.0,1.0)

        // A breakout is actionable only with follow-through, not merely because price crossed a level.
        val followThrough=(.48*max(0.0,ma)+.32*max(0.0,ea)+.20*max(0.0,va)).coerceIn(0.0,1.0)
        val breakoutQuality=(breakout*followThrough*(.55+.45*regime)).coerceIn(0.0,1.0)
        val freshness=(max(reversal,max(breakoutQuality,timing*.70+regime*.30))-exhaustion*.45).coerceIn(0.0,1.0)

        // Dedicated Entry-Timing Brain. It rewards fresh aligned impulse / confirmed reversal
        // and penalizes late extension, fading momentum, chop and volatility shock. 1m needs
        // tighter micro confirmation; 5m gives more weight to structure and regime persistence.
        val timingScore=if(e==60)
            (.34*max(0.0,ma)+.24*max(0.0,ea)+.16*max(0.0,va)+.10*max(0.0,aa)+
             .10*breakoutQuality+.10*reversal+.06*histEvidence-.18*exhaustion-.10*chop).coerceIn(0.0,1.0)
        else
            (.22*max(0.0,ma)+.24*max(0.0,ea)+.16*max(0.0,sa)+.08*max(0.0,va)+
             .10*breakoutQuality+.08*reversal+.08*regime+.08*histEvidence-.16*exhaustion-.08*chop).coerceIn(0.0,1.0)
        val reversalWindow=reversal>.46 && turn>.40 && exhaustion<.58
        val breakoutWindow=breakoutQuality>.44 && followThrough>.40 && exhaustion<.55
        val impulseWindow=if(e==60) timingScore>=.36 && ma>.16 && (ea>.10 || va>.10)
                          else timingScore>=.31 && (sa>.12 || ea>.13) && regime>.24
        val timingReady=(reversalWindow || breakoutWindow || impulseWindow) && exhaustion<.64

        // Independent engines meet here: live direction, structure, timing, regime and historical analogue.
        // History has deliberately bounded weight; fresh price action remains dominant.
        val entryQ=(38+35*timing+17*max(0.0,ea)+9*level+10*breakoutQuality+7*regime+4*vis+5*histEvidence-24*chop-14*max(0.0,-va)-19*exhaustion).coerceIn(0.0,100.0)
        val conflict=(100*(opposite*.66+chop*.20+exhaustion*.10+(1-regime)*.04) - histEvidence*4).coerceIn(0.0,100.0)
        val score=(36+directional*49+reversal*10+continuation*9+breakoutQuality*7+timing*6+regime*5+vis*3+histEvidence*7+entryQ*.08-conflict*.19-exhaustion*10).coerceIn(0.0,97.0)
        val reason=when{
            exhaustion>.60->"EXH"
            reversal>.43&&turn>.38->"REV"
            breakoutQuality>.42->"BRK"
            continuation>.34&&regime>.30->"CONT"
            else->"MOM"
        }
        return C(sign,e,score,entryQ,conflict,reason,0.0,regime,freshness,timingScore,timingReady)
    }

    private fun historicalSimilarity(sign:Int,p:List<Double>,floor:Double,e:Int):Double{
        // Uses only already-visible candles/price path: no look-ahead beyond each historical analogue.
        val win=if(e==60) 24 else 42
        val future=if(e==60) 8 else 18
        if(p.size < win*2+future+8) return 0.0
        val cur=p.takeLast(win)
        fun norm(a:List<Double>):List<Double>{
            val base=a.first(); val scale=max(floor,a.zipWithNext{u,v->abs(v-u)}.average()*2.2)
            return a.map{(it-base)/scale}
        }
        val cn=norm(cur); var weighted=0.0; var mass=0.0
        val end=p.size-win-future-3
        var i=4
        while(i<=end){
            val old=p.subList(i,i+win); val on=norm(old)
            var mse=0.0
            for(k in cn.indices){val d=cn[k]-on[k];mse+=d*d}
            mse/=cn.size
            val sim=(1.0/(1.0+mse)).coerceIn(0.0,1.0)
            if(sim>.68){
                val after=median(p.subList(i+win,i+win+future))-median(p.subList(i+win-3,i+win))
                val outcome=(sign*after/(floor*2.2)).coerceIn(-1.0,1.0)
                val w=(sim-.68)/.32
                weighted+=w*outcome; mass+=w
            }
            i+=max(3,win/6)
        }
        if(mass<.55)return 0.0
        return (weighted/mass).coerceIn(-1.0,1.0).coerceAtLeast(0.0)
    }

    private fun smooth(v:List<Double>,r:Int)=v.indices.map{i->median(v.subList(max(0,i-r),min(v.size,i+r+1)))}
    private fun hampel(v:List<Double>,r:Int,k:Double):List<Double>{
        if(v.size<2*r+1)return v
        return v.indices.map{i->
            val a=max(0,i-r);val z=min(v.size,i+r+1);val win=v.subList(a,z);val med=median(win)
            val mad=median(win.map{abs(it-med)}).coerceAtLeast(.5)
            if(abs(v[i]-med)>k*1.4826*mad)med else v[i]
        }
    }
    private fun median(v:List<Double>):Double{if(v.isEmpty())return 0.0;val s=v.sorted();return if(s.size%2==1)s[s.size/2] else (s[s.size/2-1]+s[s.size/2])/2}
    private fun percentile(v:List<Double>,q:Double):Double{if(v.isEmpty())return 0.0;val s=v.sorted();return s[((s.size-1)*q).toInt().coerceIn(0,s.size-1)]}
    private fun wait(r:String)=SignalResult("WAIT",0,0,0,100,r,0,0,0)
}
