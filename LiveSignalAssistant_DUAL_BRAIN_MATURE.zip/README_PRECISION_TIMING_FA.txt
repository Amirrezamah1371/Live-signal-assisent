Live Signal Assistant — DUAL BRAIN PRECISION TIMING 3.4

- فقط افق‌های 1m و 5m
- Direction Brain و Entry-Timing Brain مستقل هستند.
- جهت درست به‌تنهایی NOW تولید نمی‌کند؛ Timing Engine باید پنجره ورود را تأیید کند.
- Timing برای 1m و 5m پارامترهای مستقل دارد.
- Reversal/Breakout معتبر می‌تواند سریع پنجره ورود تازه ایجاد کند.
- هیچ quota یا cooldown عددی برای تعداد سیگنال وجود ندارد.
- Signal Event deduplication نسخه 3.3 حفظ شده است.
- Historical similarity فقط evidence کمکی است و بر داده زنده غلبه نمی‌کند.
- هیچ اجرای خودکار معامله وجود ندارد.
- افزایش نرخ برد ادعا نمی‌شود و باید با Demo خارج از نمونه سنجیده شود.
