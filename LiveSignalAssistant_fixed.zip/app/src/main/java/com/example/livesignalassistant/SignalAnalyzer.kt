package com.example.livesignalassistant

import android.graphics.Bitmap
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

data class SignalResult(
    val direction: String,
    val timeframeMinutes: Int,
    val confidence: Int
)

object SignalAnalyzer {
    private data class Candle(val x: Int, val top: Int, val bottom: Int, val bull: Boolean) {
        val mid get() = (top + bottom) / 2.0
        val range get() = max(1, bottom - top)
    }

    fun analyze(bitmap: Bitmap): SignalResult {
        val w = bitmap.width
        val h = bitmap.height
        if (w < 300 || h < 300) return SignalResult("WAIT", 0, 0)

        // Focus on the chart body; exclude most controls/labels.
        val x0 = (w * 0.18).toInt()
        val x1 = (w * 0.94).toInt()
        val y0 = (h * 0.16).toInt()
        val y1 = (h * 0.78).toInt()

        val candles = ArrayList<Candle>()
        var x = x0
        while (x < x1) {
            var bullHits = 0
            var bearHits = 0
            var top = y1
            var bottom = y0
            var y = y0
            while (y < y1) {
                val c = bitmap.getPixel(x, y)
                val r = (c shr 16) and 0xff
                val g = (c shr 8) and 0xff
                val b = c and 0xff
                val bull = g > 75 && g > r * 1.16 && g > b * 1.05
                val bear = r > 80 && r > g * 1.16 && r > b * 1.03
                if (bull || bear) {
                    if (bull) bullHits++ else bearHits++
                    top = min(top, y)
                    bottom = max(bottom, y)
                }
                y += 2
            }
            val hits = bullHits + bearHits
            if (hits >= max(4, (y1 - y0) / 180)) {
                candles.add(Candle(x, top, bottom, bullHits >= bearHits))
            }
            x += 2
        }

        if (candles.size < 10) return SignalResult("WAIT", 0, 0)

        // Merge adjacent vertical slices belonging to the same candle.
        val merged = ArrayList<Candle>()
        var i = 0
        while (i < candles.size) {
            var j = i
            var top = candles[i].top
            var bottom = candles[i].bottom
            var bullVotes = 0
            var bearVotes = 0
            while (j + 1 < candles.size && candles[j + 1].x - candles[j].x <= 4) {
                if (candles[j].bull) bullVotes++ else bearVotes++
                top = min(top, candles[j].top)
                bottom = max(bottom, candles[j].bottom)
                j++
            }
            if (candles[j].bull) bullVotes++ else bearVotes++
            merged.add(Candle((candles[i].x + candles[j].x) / 2, top, bottom, bullVotes >= bearVotes))
            i = j + 1
        }

        val recent = merged.takeLast(min(18, merged.size))
        if (recent.size < 6) return SignalResult("WAIT", 0, 0)

        // Screen Y grows downward: falling Y means rising market price.
        val n = recent.size
        val xsMean = (n - 1) / 2.0
        val yMean = recent.map { it.mid }.average()
        var cov = 0.0
        var varX = 0.0
        for (k in recent.indices) {
            val dx = k - xsMean
            cov += dx * (recent[k].mid - yMean)
            varX += dx * dx
        }
        val slope = if (varX == 0.0) 0.0 else cov / varX
        val avgRange = recent.map { it.range.toDouble() }.average().coerceAtLeast(1.0)
        val trend = (-slope / avgRange).coerceIn(-1.5, 1.5)

        val half = max(2, n / 2)
        val oldMid = recent.take(half).map { it.mid }.average()
        val newMid = recent.takeLast(half).map { it.mid }.average()
        val momentum = ((oldMid - newMid) / avgRange).coerceIn(-2.0, 2.0) / 2.0

        val bullRatio = recent.count { it.bull }.toDouble() / n
        val colorBias = (bullRatio - 0.5) * 2.0

        // Agreement between trend, momentum and candle direction.
        val score = 0.46 * trend + 0.36 * momentum + 0.18 * colorBias
        val sameDirection = (trend > 0 && momentum > 0) || (trend < 0 && momentum < 0)
        val strength = abs(score)

        // Conservative gate: ambiguity => WAIT.
        if (!sameDirection || strength < 0.24 || abs(momentum) < 0.10) {
            return SignalResult("WAIT", 0, (strength * 100).toInt().coerceIn(0, 70))
        }

        val direction = if (score > 0) "UP" else "DOWN"
        val confidence = (55 + strength * 38).toInt().coerceIn(55, 95)

        // Stronger, cleaner moves get shorter horizons; weaker confirmed trends get longer ones.
        val tf = when {
            strength >= 0.78 -> 1
            strength >= 0.64 -> 2
            strength >= 0.52 -> 3
            strength >= 0.43 -> 5
            strength >= 0.36 -> 8
            strength >= 0.30 -> 12
            strength >= 0.27 -> 15
            else -> 20
        }
        return SignalResult(direction, tf, confidence)
    }
}
