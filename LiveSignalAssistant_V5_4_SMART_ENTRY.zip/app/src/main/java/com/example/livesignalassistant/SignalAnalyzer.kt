package com.example.livesignalassistant

import android.graphics.Bitmap
import android.os.SystemClock
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

data class SignalResult(
    val direction:String, val expirySeconds:Int, val confidence:Int,
    val entryQuality:Int=0, val conflict:Int=100, val reason:String="",
    val upScore:Int=0, val downScore:Int=0, val signalQuality:Int=0
)

/** V5.4 SMART ENTRY — symmetric UP/DOWN evidence, 30s/1m/5m only. */
object SignalAnalyzer {
    private data class View(val p:List<Double>, val floor:Double)
    private data class C(val sign:Int,val expiry:Int,val score:Double,val entry:Double,val conflict:Double,val reason:String)
    private var prevRight:Double?=null; private var prevVelocity=0.0; private var prevAt=0L
    private val votes=mutableMapOf<Int,ArrayDeque<Int>>()
    private var lastSignalAt=0L; private var lastSignalSign=0; private var lastSignalExpiry=0

    @Synchronized fun reset(){prevRight=null;prevVelocity=0.0;prevAt=0;votes.clear();lastSignalAt=0;lastSignalSign=0;lastSignalExpiry=0}

    @Synchronized fun analyze(b:Bitmap):SignalResult{
        val w=b.width; val h=b.height
        if(w<240||h<360) return wait("LOW VISIBILITY")
        // Keep controls/labels out; read the chart itself. Four time-scales are derived from progressively newer price history.
        val x0=(w*.055).toInt(); val x1=(w*.79).toInt(); val y0=(h*.12).toInt(); val y1=(h*.79).toInt()
        val step=max(2,(x1-x0)/320); val raw=ArrayList<Double>(); var x=x0
        while(x<x1){val hits=ArrayList<Int>();var y=y0
            while(y<y1){val c=b.getPixel(x,y);val r=(c shr 16)and 255;val g=(c shr 8)and 255;val bl=c and 255;val hi=max(r,max(g,bl));val lo=min(r,min(g,bl));if(hi>=95&&hi-lo>=38)hits+=y;y+=2}
            if(hits.size>=2){hits.sort();raw+=-hits[hits.size/2].toDouble()};x+=step
        }
        if(raw.size<72) return wait("LOW VISIBILITY")
        val all=smooth(raw,2);val n=all.size
        val wide=mk(all,h);val structure=mk(all.subList((n*.28).toInt(),n),h);val entry=mk(all.subList((n*.62).toInt(),n),h);val micro=mk(all.subList((n*.82).toInt(),n),h)
        val right=median(micro.p.takeLast(max(3,micro.p.size/7)));val now=SystemClock.elapsedRealtime();val dt=((now-prevAt).coerceAtLeast(1))/1000.0
        val velocity=prevRight?.let{(right-it)/dt}?:0.0;val accel=(velocity-prevVelocity)/dt;prevRight=right;prevVelocity=velocity;prevAt=now

        val expiries=intArrayOf(30,60,300);val cs=ArrayList<C>()
        for(e in expiries){cs+=candidate(1,e,wide,structure,entry,micro,velocity,accel);cs+=candidate(-1,e,wide,structure,entry,micro,velocity,accel)}
        val best=cs.maxByOrNull{it.score}!!;val opp=cs.first{it.expiry==best.expiry&&it.sign==-best.sign};val margin=best.score-opp.score
        val up=cs.filter{it.sign>0}.maxOf{it.score}.toInt();val down=cs.filter{it.sign<0}.maxOf{it.score}.toInt()

        // Balanced gate: WAIT must have a reason, but weak/ambiguous/poorly-timed entries do not become trades.
        if(best.score<62 || best.entry<46 || best.conflict>58 || margin<6.0)
            return SignalResult("WAIT",0,best.score.toInt(),best.entry.toInt(),best.conflict.toInt(),"FILTER",up,down,0)

        val q=votes.getOrPut(best.expiry){ArrayDeque()};q.addLast(best.sign);while(q.size>4)q.removeFirst()
        val persistence=q.count{it==best.sign}
        if(best.score<76 && (q.size<3 || persistence<2))
            return SignalResult("WAIT",0,best.score.toInt(),best.entry.toInt(),best.conflict.toInt(),"CONFIRM",up,down,0)

        // Duplicate suppression only. Opposite direction / different horizon can still fire immediately.
        if(best.sign==lastSignalSign && best.expiry==lastSignalExpiry && now-lastSignalAt<24_000)
            return SignalResult("WAIT",0,best.score.toInt(),best.entry.toInt(),best.conflict.toInt(),"COOLDOWN",up,down,0)

        // This is an evidence-quality score, NOT a claimed probability of winning.
        val quality=(best.score*.42 + best.entry*.30 + (100-best.conflict)*.18 + (margin.coerceIn(0.0,25.0)/25.0)*10.0).toInt().coerceIn(0,96)
        lastSignalAt=now;lastSignalSign=best.sign;lastSignalExpiry=best.expiry
        return SignalResult(if(best.sign>0)"UP" else "DOWN",best.expiry,best.score.toInt(),best.entry.toInt(),best.conflict.toInt(),best.reason,up,down,quality)
    }

    private fun mk(p:List<Double>,h:Int):View{val d=p.zipWithNext{a,c->abs(c-a)};return View(p,max(h*.0017,median(d).coerceAtLeast(1.0)*.90))}
    private fun candidate(sign:Int,e:Int,w:View,s:View,en:View,m:View,velocity:Double,accel:Double):C{
        fun mv(v:View,a:Double,b:Double):Double{val n=v.p.size;val i=(n*a).toInt().coerceIn(0,n-2);val j=(n*b).toInt().coerceIn(i+2,n);val q=max(2,(j-i)/4);return median(v.p.subList(j-q,j))-median(v.p.subList(i,i+q))}
        fun align(v:Double,f:Double,k:Double)=((sign*v)/(f*k)).coerceIn(-1.0,1.0)
        val wa=align(mv(w,.05,.95),w.floor,3.4);val sa=align(mv(s,.20,.98),s.floor,2.6);val ea=align(mv(en,.35,1.0),en.floor,1.7);val ma=align(mv(m,.42,1.0),m.floor,1.0)
        val va=align(velocity,m.floor,1.15);val aa=align(accel,m.floor,2.2)
        val hist=s.p.dropLast(max(2,s.p.size/12));val sup=percentile(hist,.10);val res=percentile(hist,.90);val r=median(m.p.takeLast(max(3,m.p.size/6)));val span=(res-sup).coerceAtLeast(s.floor*4);val pos=((r-sup)/span).coerceIn(-.5,1.5)
        // Symmetric location evidence: UP gets support-side reversal evidence; DOWN gets resistance-side reversal evidence.
        val level=if(sign>0)((.50-pos)/.50).coerceIn(0.0,1.0) else ((pos-.50)/.50).coerceIn(0.0,1.0)
        val breakout=if(sign>0)((r-res)/(s.floor*1.4)).coerceIn(0.0,1.0) else ((sup-r)/(s.floor*1.4)).coerceIn(0.0,1.0)
        val ds=m.p.zipWithNext{a,c->c-a};var flips=0;var last=0;for(d in ds){val z=if(d>m.floor*.1)1 else if(d< -m.floor*.1)-1 else 0;if(z!=0){if(last!=0&&z!=last)flips++;last=z}}
        val chop=flips.toDouble()/max(1,ds.size-1)
        val weights=when(e){30->doubleArrayOf(.06,.11,.29,.36,.13,.05);60->doubleArrayOf(.10,.18,.31,.28,.09,.04);else->doubleArrayOf(.25,.36,.25,.08,.04,.02)}
        val aligned=listOf(wa,sa,ea,ma,va,aa);var directional=0.0;for(i in aligned.indices)directional+=max(0.0,aligned[i])*weights[i]
        val opposite=max(0.0,-ma)*.31+max(0.0,-ea)*.29+max(0.0,-sa)*.25+max(0.0,-wa)*.10+max(0.0,-va)*.05
        val reversal=(level*max(0.0,-sa)*(max(0.0,ma)+max(0.0,ea))/2).coerceIn(0.0,1.0)
        val continuation=(max(0.0,wa)*max(0.0,sa)*max(0.0,ea)).coerceIn(0.0,1.0)
        val timing=(.50*max(0.0,ma)+.28*max(0.0,ea)+.15*max(0.0,va)+.07*max(0.0,aa)).coerceIn(0.0,1.0)
        val entryQ=(40+34*timing+18*max(0.0,ea)+10*level+8*breakout-21*chop-10*max(0.0,-va)).coerceIn(0.0,100.0)
        val conflict=(100*(opposite*.72+chop*.28)).coerceIn(0.0,100.0)
        val score=(38+directional*49+reversal*8+continuation*7+breakout*5+timing*6+entryQ*.09-conflict*.17).coerceIn(0.0,96.0)
        val reason=when{reversal>.45->"REV";breakout>.45->"BRK";continuation>.38->"CONT";else->"MOM"}
        return C(sign,e,score,entryQ,conflict,reason)
    }
    private fun smooth(v:List<Double>,r:Int)=v.indices.map{i->median(v.subList(max(0,i-r),min(v.size,i+r+1)))}
    private fun median(v:List<Double>):Double{if(v.isEmpty())return 0.0;val s=v.sorted();return if(s.size%2==1)s[s.size/2] else (s[s.size/2-1]+s[s.size/2])/2}
    private fun percentile(v:List<Double>,q:Double):Double{val s=v.sorted();return s[((s.size-1)*q).toInt().coerceIn(0,s.size-1)]}
    private fun wait(r:String)=SignalResult("WAIT",0,0,0,100,r,0,0,0)
}
