package com.example.livesignalassistant

import android.graphics.Bitmap
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

data class SignalResult(val direction: String, val timeframeMinutes: Int, val confidence: Int)

object SignalAnalyzer {
    private val votes = ArrayDeque<Int>()
    private val rawScores = ArrayDeque<Double>()
    private var previousRightY: Double? = null
    private var previousDirection = 0
    private var directionStreak = 0

    @Synchronized
    fun analyze(bitmap: Bitmap): SignalResult {
        val w = bitmap.width; val h = bitmap.height
        if (w < 240 || h < 360) return waitResult(true)

        // Work only on the live/right side of the chart. Red and green are treated identically.
        val x0=(w*.57).toInt(); val x1=(w*.958).toInt()
        val y0=(h*.16).toInt(); val y1=(h*.78).toInt()
        val stepX=max(2,(x1-x0)/145)
        val pts=ArrayList<Pair<Double,Double>>()

        var x=x0
        while(x<x1){
            val hits=ArrayList<Int>(); var y=y0
            while(y<y1){
                val c=bitmap.getPixel(x,y)
                val r=(c shr 16) and 255; val g=(c shr 8) and 255; val b=c and 255
                val hi=max(r,max(g,b)); val lo=min(r,min(g,b)); val chroma=hi-lo
                // Symmetric stroke detector; avoids direction-by-colour bias.
                if(hi>=112 && chroma>=42) hits.add(y)
                y+=2
            }
            if(hits.size>=2){ hits.sort(); pts.add(x.toDouble() to hits[hits.size/2].toDouble()) }
            x+=stepX
        }
        if(pts.size<30) return waitResult(true)

        val ys=pts.map{it.second}; val n=ys.size
        val diffs=ys.zipWithNext{a,b->abs(b-a)}
        val noise=median(diffs).coerceAtLeast(1.0)
        val threshold=max(h*.0038,noise*1.18)

        val q=max(6,n/5)
        val left=median(ys.take(q))
        val center=median(ys.subList(max(0,n/2-q/2),min(n,n/2+q/2)))
        val right=median(ys.takeLast(q))
        val veryRecent=median(ys.takeLast(max(5,n/10)))
        val prevRecent=median(ys.dropLast(max(5,n/10)).takeLast(max(5,n/10)))

        // Screen Y decreases when price moves up.
        val longMove=right-left
        val mediumMove=right-center
        val microMove=veryRecent-prevRecent

        val recentStart=max(0,n*2/3)
        val regAll=regression(pts,0,n)
        val regRecent=regression(pts,recentStart,n)
        if(regAll==null || regRecent==null) return waitResult(true)

        val longDir=direction(longMove,threshold)
        val mediumDir=direction(mediumMove,threshold*.72)
        val microDir=direction(microMove,threshold*.52)
        val slopeDir=direction(regAll.first,0.013)
        val recentSlopeDir=direction(regRecent.first,0.011)
        val coherenceAll=abs(regAll.second)
        val coherenceRecent=abs(regRecent.second)

        // Frame-to-frame movement of the live edge: useful for reversals and prevents stale direction lock.
        val frameMove=previousRightY?.let{right-it} ?: 0.0
        previousRightY=right
        val frameDir=direction(frameMove,threshold*.38)

        // Fully symmetric score: + = UP, - = DOWN.
        var score=0.0
        score += microDir*1.55
        score += recentSlopeDir*(1.15+coherenceRecent*.65)
        score += mediumDir*1.05
        score += longDir*.72
        score += slopeDir*(.55+coherenceAll*.45)
        score += frameDir*.75

        // Strong disagreement around the live edge means no trade.
        val recentSigns=listOf(microDir,recentSlopeDir,mediumDir,frameDir).filter{it!=0}
        val ups=recentSigns.count{it>0}; val downs=recentSigns.count{it<0}
        if(ups>=2 && downs>=2) return waitResult(false,((coherenceRecent+.0)*100).toInt())

        rawScores.addLast(score); while(rawScores.size>5) rawScores.removeFirst()
        val smoothed=rawScores.average()
        if(abs(smoothed)<1.70 || coherenceRecent<.12) return waitResult(false,(coherenceRecent*100).toInt())

        val dir=if(smoothed>0) 1 else -1
        votes.addLast(dir); while(votes.size>5) votes.removeFirst()
        val confirmations=votes.count{it==dir}
        if(confirmations<3) return waitResult(false,(coherenceRecent*100).toInt())

        if(dir==previousDirection) directionStreak++ else { previousDirection=dir; directionStreak=1 }
        if(directionStreak<2) return waitResult(false,(coherenceRecent*100).toInt())

        val moveStrength=(abs(microMove)/(h*.008)).coerceIn(0.0,3.0)
        val agreement=max(ups,downs).toDouble()/max(1,recentSigns.size)
        val confidence=(28 + coherenceRecent*34 + coherenceAll*14 + agreement*14 + min(10.0,moveStrength*4.0)).toInt().coerceIn(0,96)
        if(confidence<55) return waitResult(false,confidence)

        // Horizon is a stability estimate, not a guarantee. Strong/fresh movement => shorter horizon.
        val tf=when{
            confidence>=84 && moveStrength>=1.65 -> 1
            confidence>=78 && moveStrength>=1.25 -> 2
            confidence>=72 -> 3
            confidence>=67 -> 5
            confidence>=63 -> 8
            confidence>=60 -> 12
            confidence>=57 -> 15
            else -> 20
        }
        return SignalResult(if(dir>0) "UP" else "DOWN",tf,confidence)
    }

    // Returns slope and correlation. Both directions use exactly the same thresholds.
    private fun regression(p:List<Pair<Double,Double>>,from:Int,to:Int):Pair<Double,Double>?{
        if(to-from<5)return null
        var sw=0.0;var sx=0.0;var sy=0.0
        for(i in from until to){val wt=1.0+2.2*(i-from)/max(1.0,(to-from-1).toDouble());sw+=wt;sx+=wt*p[i].first;sy+=wt*p[i].second}
        val mx=sx/sw;val my=sy/sw;var sxx=0.0;var syy=0.0;var sxy=0.0
        for(i in from until to){val wt=1.0+2.2*(i-from)/max(1.0,(to-from-1).toDouble());val dx=p[i].first-mx;val dy=p[i].second-my;sxx+=wt*dx*dx;syy+=wt*dy*dy;sxy+=wt*dx*dy}
        if(sxx<=0.0||syy<=0.0)return null
        return (sxy/sxx) to (sxy/sqrt(sxx*syy)).coerceIn(-1.0,1.0)
    }
    private fun direction(v:Double,t:Double)=when{v < -t -> 1; v > t -> -1; else -> 0}
    private fun median(v:List<Double>):Double{if(v.isEmpty())return 0.0;val s=v.sorted();return if(s.size%2==1)s[s.size/2] else (s[s.size/2-1]+s[s.size/2])/2.0}
    private fun waitResult(clear:Boolean=false,conf:Int=0):SignalResult{
        if(clear){votes.clear();rawScores.clear();previousRightY=null;previousDirection=0;directionStreak=0}
        return SignalResult("WAIT",0,conf.coerceIn(0,96))
    }
}
