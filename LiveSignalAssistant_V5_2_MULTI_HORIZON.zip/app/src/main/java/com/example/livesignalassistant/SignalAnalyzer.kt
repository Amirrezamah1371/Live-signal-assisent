package com.example.livesignalassistant

import android.graphics.Bitmap
import android.os.SystemClock
import java.util.Calendar
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

data class SignalResult(
    val direction: String,
    val expirySeconds: Int,
    val confidence: Int,
    val entryQuality: Int = 0,
    val conflict: Int = 100,
    val reason: String = ""
)

/** V5.2: independent multi-horizon evidence engine. Each expiry votes for itself. */
object SignalAnalyzer {
    private data class Features(
        val floor:Double,val broad:Double,val swing:Double,val fast:Double,val micro:Double,val ultra:Double,
        val frame:Double,val accel:Double,val chop:Double,val volatility:Double,val pos:Double,
        val right:Double,val support:Double,val resistance:Double
    )
    private data class Profile(val expiry:Int,val microW:Double,val fastW:Double,val structureW:Double,val entryMin:Double,val scoreMin:Double,val conflictMax:Double)
    private data class Candidate(val sign:Int,val expiry:Int,val score:Double,val entry:Double,val conflict:Double,val reason:String)

    private val profiles = listOf(
        Profile(30,.52,.28,.20,43.0,62.0,62.0),
        Profile(60,.46,.30,.24,44.0,62.5,61.0),
        Profile(120,.36,.34,.30,45.0,63.0,60.0),
        Profile(180,.30,.34,.36,45.0,63.0,59.0),
        Profile(300,.24,.32,.44,46.0,63.5,58.0),
        Profile(600,.18,.28,.54,47.0,64.0,57.0),
        Profile(900,.14,.24,.62,48.0,64.5,56.0)
    )
    private val votes = HashMap<Int,ArrayDeque<Int>>()
    private var previousRight:Double? = null
    private var previousAt = 0L

    @Synchronized fun reset(){ votes.clear(); previousRight=null; previousAt=0L }

    @Synchronized fun analyze(bitmap:Bitmap):SignalResult{
        val f=extract(bitmap) ?: return SignalResult("WAIT",0,0,0,100,"LOW VISIBILITY")
        val viable=ArrayList<Candidate>()
        var bestRejected:Candidate?=null

        for(p in profiles){
            val up=candidate(+1,p,f); val down=candidate(-1,p,f)
            val winner=if(up.score>=down.score) up else down
            val loser=if(winner.sign>0) down else up
            val edge=winner.score-loser.score
            val adjustedConflict=(winner.conflict + (6.0-edge).coerceAtLeast(0.0)*3.2).coerceAtMost(100.0)
            val w=winner.copy(conflict=adjustedConflict)
            if(bestRejected==null || w.score>bestRejected!!.score) bestRejected=w

            // Each horizon must independently earn a signal. No global direction is imposed.
            if(w.score>=p.scoreMin && w.entry>=p.entryMin && w.conflict<=p.conflictMax && edge>=2.2){
                val q=votes.getOrPut(p.expiry){ArrayDeque()}; q.addLast(w.sign); while(q.size>3)q.removeFirst()
                if(q.count{it==w.sign}>=2) viable+=w
            } else votes[p.expiry]?.clear()
        }

        if(viable.isEmpty()){
            val b=bestRejected ?: return SignalResult("WAIT",0,0,0,100,"NO SETUP")
            return SignalResult("WAIT",0,b.score.toInt(),b.entry.toInt(),b.conflict.toInt(),"${b.reason}/H${b.expiry}")
        }

        // Opportunity-first selection: quality + entry, with a small conflict penalty.
        val best=viable.maxByOrNull{it.score + it.entry*.10 - it.conflict*.08}!!
        return SignalResult(if(best.sign>0)"UP" else "DOWN",best.expiry,best.score.toInt(),best.entry.toInt(),best.conflict.toInt(),best.reason)
    }

    private fun extract(bitmap:Bitmap):Features?{
        val w=bitmap.width; val h=bitmap.height
        if(w<240||h<360)return null
        // Chart-only ROI. Avoid the broker's right-side controls and bottom trade UI.
        val x0=(w*.045).toInt(); val x1=(w*.775).toInt(); val y0=(h*.145).toInt(); val y1=(h*.765).toInt()
        val step=max(2,(x1-x0)/300); val raw=ArrayList<Double>(); var x=x0
        while(x<x1){
            val hits=ArrayList<Int>(); var y=y0
            while(y<y1){
                val c=bitmap.getPixel(x,y); val r=(c shr 16)and 255; val g=(c shr 8)and 255; val b=c and 255
                val hi=max(r,max(g,b)); val lo=min(r,min(g,b))
                // Saturated candle/price pixels; reject gray grid/text as much as possible.
                if(hi>=105 && hi-lo>=46) hits+=y
                y+=2
            }
            if(hits.size>=2){hits.sort();raw+=-hits[hits.size/2].toDouble()}
            x+=step
        }
        if(raw.size<62)return null
        val micro=smooth(raw,1); val medium=smooth(raw,3); val wide=smooth(raw,7); val n=medium.size
        val deltas=medium.zipWithNext{a,b->abs(b-a)}; val noise=median(deltas).coerceAtLeast(1.0); val floor=max(h*.0018,noise*.92)
        fun move(v:List<Double>,a:Double,b:Double):Double{val i=(n*a).toInt().coerceIn(0,n-2);val j=(n*b).toInt().coerceIn(i+2,n);val q=max(2,(j-i)/4);return median(v.subList(j-q,j))-median(v.subList(i,i+q))}
        val broad=move(wide,.05,.62); val swing=move(wide,.38,.84); val fast=move(medium,.68,1.0); val mic=move(micro,.82,1.0); val ultra=move(micro,.94,1.0)
        val right=median(micro.takeLast(max(4,n/20))); val now=SystemClock.elapsedRealtime(); val dt=((now-previousAt).coerceAtLeast(1L))/1000.0
        val frame=previousRight?.let{(right-it)/dt}?:0.0; previousRight=right; previousAt=now
        val hist=wide.subList(0,max(18,(n*.82).toInt())); val support=percentile(hist,.10); val resistance=percentile(hist,.90); val range=(resistance-support).coerceAtLeast(floor*4)
        val pos=((right-support)/range).coerceIn(-.5,1.5)
        val recent=micro.takeLast(max(18,n/3)).zipWithNext{a,b->b-a}; var flips=0;var last=0
        for(d in recent){val s=when{d>floor*.10->1;d< -floor*.10->-1;else->0};if(s!=0){if(last!=0&&s!=last)flips++;last=s}}
        val chop=(flips.toDouble()/max(1,recent.size-1)).coerceIn(0.0,1.0)
        val q=max(4,recent.size/4); val velocity=recent.takeLast(q).average(); val prior=recent.dropLast(q).takeLast(q).let{if(it.isEmpty())0.0 else it.average()}
        return Features(floor,broad,swing,fast,mic,ultra,frame,velocity-prior,chop,(median(deltas)/floor).coerceIn(.4,3.2),pos,right,support,resistance)
    }

    private fun candidate(sign:Int,p:Profile,f:Features):Candidate{
        fun al(v:Double,s:Double)=((sign*v)/(f.floor*s)).coerceIn(-1.0,1.0)
        val broad=al(f.broad,3.0); val swing=al(f.swing,2.4); val fast=al(f.fast,1.45); val micro=al(f.micro,.95); val ultra=al(f.ultra,.70); val frame=al(f.frame,1.05); val accel=al(f.accel,.55)
        val microEvidence=(pos(micro)*.38+pos(ultra)*.26+pos(frame)*.22+pos(accel)*.14)
        val fastEvidence=(pos(fast)*.58+pos(micro)*.24+pos(accel)*.18)
        val structure=(pos(broad)*.46+pos(swing)*.38+pos(fast)*.16)
        val levelRoom=if(sign>0)((.88-f.pos)/.70).coerceIn(0.0,1.0) else ((f.pos-.12)/.70).coerceIn(0.0,1.0)
        val reversal=if(sign>0)((.28-f.pos)/.28).coerceIn(0.0,1.0)*pos(micro) else ((f.pos-.72)/.28).coerceIn(0.0,1.0)*pos(micro)
        val breakout=if(sign>0)((f.right-f.resistance)/(f.floor*1.4)).coerceIn(0.0,1.0) else ((f.support-f.right)/(f.floor*1.4)).coerceIn(0.0,1.0)
        val evidence=(microEvidence*p.microW + fastEvidence*p.fastW + structure*p.structureW).coerceIn(0.0,1.0)
        val opposite=(pos(-micro)*.34+pos(-frame)*.24+pos(-fast)*.24+pos(-swing)*.18)
        val exhaustion=(pos(ultra)*pos(micro)*(1.0-levelRoom)*(1.0-pos(accel))).coerceIn(0.0,1.0)
        val entry=(100*(microEvidence*.40+fastEvidence*.20+levelRoom*.17+reversal*.12+breakout*.11)-exhaustion*20-f.chop*9).coerceIn(0.0,100.0)
        val conflict=(100*(opposite*.66+f.chop*.20+exhaustion*.10+(if(f.volatility>2.55).04 else 0.0))).coerceIn(0.0,100.0)
        val score=(36+evidence*49+entry*.13-conflict*.15+MarketContextEngine.modifier(p.expiry)).coerceIn(0.0,96.0)
        val reason=when{reversal>.48->"REVERSAL";breakout>.48->"BREAKOUT";structure>.58&&fastEvidence>.50->"CONTINUATION";else->"MOMENTUM"}
        return Candidate(sign,p.expiry,score,entry,conflict,reason)
    }

    private fun pos(v:Double)=v.coerceIn(0.0,1.0)
    private fun smooth(v:List<Double>,r:Int)=v.indices.map{i->median(v.subList(max(0,i-r),min(v.size,i+r+1)))}
    private fun median(v:List<Double>):Double{if(v.isEmpty())return 0.0;val s=v.sorted();return if(s.size%2==1)s[s.size/2] else (s[s.size/2-1]+s[s.size/2])/2}
    private fun percentile(v:List<Double>,q:Double):Double{val s=v.sorted();return s[((s.size-1)*q).toInt().coerceIn(0,s.size-1)]}
}

object MarketContextEngine{
    fun modifier(expirySeconds:Int):Double{
        val c=Calendar.getInstance(java.util.TimeZone.getTimeZone("UTC"));val h=c.get(Calendar.HOUR_OF_DAY);val m=c.get(Calendar.MINUTE)
        var x=0.0;if(h in 7..16)x+=1.2;if(h==21||h==22)x-=2.5;if((m<2||m>57)&&expirySeconds<=60)x-=1.2;return x
    }
}
