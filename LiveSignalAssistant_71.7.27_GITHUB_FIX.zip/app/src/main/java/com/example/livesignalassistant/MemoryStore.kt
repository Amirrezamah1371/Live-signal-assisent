package com.example.livesignalassistant

import android.content.Context
import android.graphics.Bitmap
import android.provider.MediaStore
import android.content.ContentValues
import android.os.Build
import android.os.Environment
import android.os.SystemClock
import org.json.JSONObject
import java.io.*
import java.text.SimpleDateFormat
import java.util.*
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

class MemoryStore(private val ctx: Context) {
    private val sessionId = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
    private val dir = File(ctx.filesDir, "sessions/$sessionId").apply { mkdirs() }
    private val frames = File(dir,"frames").apply{mkdirs()}
    private val log = File(dir,"timeline.jsonl")
    @Synchronized fun event(type:String, data:Map<String,Any?> = emptyMap()) {
        val o=JSONObject(); o.put("ts_ms",System.currentTimeMillis());o.put("mono_ms",SystemClock.elapsedRealtime());o.put("type",type)
        data.forEach{(k,v)->o.put(k, JSONObject.wrap(v))}
        log.appendText(o.toString()+"\n")
    }
    @Synchronized fun frame(b:Bitmap, tag:String="observe"):String {
        val name="${System.currentTimeMillis()}_${tag}.jpg"; val f=File(frames,name)
        FileOutputStream(f).use{b.compress(Bitmap.CompressFormat.JPEG,72,it)}
        event("SCREEN_EVIDENCE", mapOf("file" to "frames/$name","tag" to tag)); return name
    }
    fun exportZip():String {
        event("EXPORT_REQUESTED")
        val tmp=File(ctx.cacheDir,"LiveSignalMemory_$sessionId.zip")
        ZipOutputStream(BufferedOutputStream(FileOutputStream(tmp))).use { z ->
            fun add(f:File, base:String){ if(f.isDirectory) f.listFiles()?.forEach{add(it,if(base.isEmpty())it.name else "$base/${it.name}")} else {z.putNextEntry(ZipEntry(base));f.inputStream().use{it.copyTo(z)};z.closeEntry()} }
            dir.listFiles()?.forEach{add(it,it.name)}
            z.putNextEntry(ZipEntry("README.txt")); z.write("Live Signal Assistant 7.0 ONE DECISION + MEMORY\nTimeline timestamps are epoch milliseconds. SCREEN_EVIDENCE files map visual chart evidence to decisions.\n".toByteArray()); z.closeEntry()
        }
        val values=ContentValues().apply{put(MediaStore.MediaColumns.DISPLAY_NAME,tmp.name);put(MediaStore.MediaColumns.MIME_TYPE,"application/zip");if(Build.VERSION.SDK_INT>=29)put(MediaStore.MediaColumns.RELATIVE_PATH,Environment.DIRECTORY_DOWNLOADS)}
        val uri=ctx.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI,values)?:return tmp.absolutePath
        ctx.contentResolver.openOutputStream(uri)?.use{out->tmp.inputStream().use{it.copyTo(out)}}
        return "Downloads/${tmp.name}"
    }
}
