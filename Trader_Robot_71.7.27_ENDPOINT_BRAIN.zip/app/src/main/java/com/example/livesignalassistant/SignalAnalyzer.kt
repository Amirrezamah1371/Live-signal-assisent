package com.example.livesignalassistant

import android.graphics.Bitmap
import android.os.SystemClock
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

data class SignalResult(
    val direction:String, val expirySeconds:Int, val confidence:Int,
    val entryQuality:Int=0, val conflict:Int=100, val reason:String="",
    val upScore:Int=0, val downScore:Int=0, val signalQuality:Int=0,
    val diagnostics:Map<String,Any?> = emptyMap()
)

/** V6.3 COHERENT ADAPTIVE — one market opinion first, then the holding horizon. Conflicting horizons abstain. */
object SignalAnalyzer {
    private data class View(val p:List<Double>, val floor:Double)
    private data class C(val sign:Int,val expiry:Int,val score:Double,val entry:Double,val conflict:Double,val reason:String, val diagnostics:Map<String,Any?> = emptyMap())
    private var prevRight:Double?=null; private var prevVelocity=0.0; private var prevAt=0L
    private val votes=mutableMapOf<Int,ArrayDeque<Int>>()
    private val directionVotes=ArrayDeque<Int>()
    private var lastSignalAt=0L; private var lastSignalSign=0; private var lastSignalExpiry=0
    private var lastSignalScore=0.0; private var lastSignalEntry=0.0
    private var lastSetupKey=""

    @Synchronized fun reset(){prevRight=null;prevVelocity=0.0;prevAt=0;votes.clear();directionVotes.clear();lastSignalAt=0;lastSignalSign=0;lastSignalExpiry=0;lastSignalScore=0.0;lastSignalEntry=0.0;lastSetupKey=""}

    @Synchronized fun analyze(b:Bitmap):SignalResult{
        val w=b.width; val h=b.height
        if(w<240||h<360) return wait("LOW VISIBILITY")
        // Keep controls/labels out; read the chart itself. Four time-scales are derived from progressively newer price history.
        val x0=(w*.055).toInt(); val x1=(w*.79).toInt(); val y0=(h*.12).toInt(); val y1=(h*.79).toInt()
        val step=max(2,(x1-x0)/320); val raw=ArrayList<Double>(); var x=x0; var previousY:Double?=null; var sampledColumns=0; var acceptedColumns=0
        // Vision 7.1: isolate the blue/cyan price trace instead of treating every saturated UI color as price.
        // Red/orange trade lines and markers are rejected by construction. Continuity selects the trace when
        // several blue pixels exist in the same column (filled chart area, labels, etc.).
        while(x<x1){sampledColumns++;val hits=ArrayList<Int>();var y=y0
            while(y<y1){val c=b.getPixel(x,y);val r=(c shr 16)and 255;val g=(c shr 8)and 255;val bl=c and 255
                val blueTrace=bl>=105 && (bl-r)>=28 && (g-r)>=8 && bl>=g-8 && r<190
                if(blueTrace)hits+=y;y+=2}
            if(hits.isNotEmpty()){
                val pick=previousY?.let{py->hits.minByOrNull{abs(it-py)}!!} ?: hits[hits.size/2]
                // Reject implausible one-column jumps; reacquire after gaps rather than following UI furniture.
                if(previousY==null || abs(pick-previousY!!) <= h*.10){raw+=-pick.toDouble();previousY=pick.toDouble();acceptedColumns++}
            };x+=step
        }
        val visionCoverage=acceptedColumns.toDouble()/sampledColumns.coerceAtLeast(1)
        if(raw.size<72 || visionCoverage<.30) return wait("LOW VISIBILITY")
        val all=smooth(raw,2);val n=all.size
        val wide=mk(all,h);val structure=mk(all.subList((n*.28).toInt(),n),h);val entry=mk(all.subList((n*.62).toInt(),n),h);val micro=mk(all.subList((n*.82).toInt(),n),h)
        val right=median(micro.p.takeLast(max(3,micro.p.size/7)));val now=SystemClock.elapsedRealtime();val dt=((now-prevAt).coerceAtLeast(1))/1000.0
        val velocity=prevRight?.let{(right-it)/dt}?:0.0;val accel=(velocity-prevVelocity)/dt;prevRight=right;prevVelocity=velocity;prevAt=now

        // COHERENT ADAPTIVE: first form ONE directional opinion across all horizons.
        // The old engine let 1m vote UP while 2m/4m/5m voted DOWN and could publish both.
        // Now disagreement is uncertainty -> WAIT. Only after direction is coherent may a horizon win.
        val expiries=intArrayOf(60,120,180,240,300);val cs=ArrayList<C>()
        for(e in expiries){cs+=candidate(1,e,wide,structure,entry,micro,velocity,accel);cs+=candidate(-1,e,wide,structure,entry,micro,velocity,accel)}
        val pairs=expiries.map { e ->
            val u=cs.first{it.expiry==e&&it.sign>0}; val d=cs.first{it.expiry==e&&it.sign<0}; Triple(e,u,d)
        }
        val deltas=pairs.map{it.second.score-it.third.score}
        // ENDPOINT MAP: preserve the model's separate directional evidence for every expiry.
        // These are diagnostic signed evidences, NOT calibrated probabilities.
        val endpointDiag=expiries.indices.associate { i -> "endpoint_delta_${expiries[i]}" to deltas[i] }
        val strongUp=deltas.count{it>=6.0}; val strongDown=deltas.count{it<=-6.0}
        val weightedDelta=deltas.withIndex().sumOf{(i,d)-> d*(1.0+i*.10)} / deltas.indices.sumOf{1.0+it*.10}
        val chosenSign=when {
            strongUp>=3 && strongDown<=1 && weightedDelta>=6.0 -> 1
            strongDown>=3 && strongUp<=1 && weightedDelta<=-6.0 -> -1
            else -> 0
        }
        val up=cs.filter{it.sign>0}.maxOf{it.score}.toInt();val down=cs.filter{it.sign<0}.maxOf{it.score}.toInt()
        val visionDiag=mapOf<String,Any?>("vision_coverage" to visionCoverage,"trace_points" to raw.size,"sampled_columns" to sampledColumns)
        if(chosenSign==0){
            val top=cs.maxByOrNull{it.score}!!
            return SignalResult("WAIT",0,top.score.toInt(),top.entry.toInt(),top.conflict.toInt(),"HORIZON_CONFLICT",up,down,0,visionDiag + top.diagnostics + endpointDiag)
        }
        val sameDirection=cs.filter{it.sign==chosenSign}
        val best=sameDirection.maxByOrNull{it.score}!!
        val opp=cs.first{it.expiry==best.expiry&&it.sign==-chosenSign}
        val margin=best.score-opp.score

        // Evidence from the first audited memory export: EXH entries were consistently late in that small sample.
        // Treat exhaustion as a no-entry condition until future out-of-sample data justifies otherwise.
        val bestExhaustion=(best.diagnostics["exhaustion"] as? Double)?:0.0
        val bestContinuation=(best.diagnostics["continuation"] as? Double)?:0.0
        if(best.reason=="EXH" || (bestExhaustion>=.52 && bestContinuation>=.30 && best.reason!="TURN" && best.reason!="FAIL_BRK"))
            return SignalResult("WAIT",0,best.score.toInt(),best.entry.toInt(),best.conflict.toInt(),"LATE_ENTRY_RISK",up,down,0,visionDiag + best.diagnostics + endpointDiag)

        // The selected expiry must agree with the global direction and independently clear quality gates.
        val minScore=68.0
        val minEntry=52.0
        val maxConflict=50.0
        val minMargin=9.0
        if(best.score<minScore || best.entry<minEntry || best.conflict>maxConflict || margin<minMargin)
            return SignalResult("WAIT",0,best.score.toInt(),best.entry.toInt(),best.conflict.toInt(),"FILTER",up,down,0,visionDiag + best.diagnostics + endpointDiag)

        // Causal direction persistence: a single noisy frame cannot reverse the whole market opinion.
        directionVotes.add(chosenSign); while(directionVotes.size>5) directionVotes.removeFirst()
        val directionPersistence=directionVotes.count{it==chosenSign}
        val structuralFlip=best.reason=="TURN" || best.reason=="REV" || best.reason=="BRK" || best.reason=="FAIL_BRK"
        if(directionVotes.size>=3 && directionPersistence<2 && !structuralFlip)
            return SignalResult("WAIT",0,best.score.toInt(),best.entry.toInt(),best.conflict.toInt(),"DIRECTION_UNSTABLE",up,down,0,visionDiag + best.diagnostics + endpointDiag)

        val q=votes.getOrPut(best.expiry){ArrayDeque()};q.add(best.sign);while(q.size>4)q.removeFirst()
        val persistence=q.count{it==best.sign}
        val fastPass=80.0
        if(best.score<fastPass && (q.size<3 || persistence<2)){
            return SignalResult("WAIT",0,best.score.toInt(),best.entry.toInt(),best.conflict.toInt(),"CONFIRM",up,down,0,visionDiag + best.diagnostics + endpointDiag)
        }

        // Direction can flip immediately when the new structural case is materially stronger.
        if(best.expiry==lastSignalExpiry && best.sign==-lastSignalSign){
            val reversalStrength=(best.score-lastSignalScore) + (best.entry-lastSignalEntry)*.45 + margin*.55
            val structural=best.reason=="TURN" || best.reason=="REV" || best.reason=="BRK" || best.reason=="FAIL_BRK"
            if(!structural && reversalStrength<14.0)
                return SignalResult("WAIT",0,best.score.toInt(),best.entry.toInt(),best.conflict.toInt(),"ANTI_FLIP",up,down,0,visionDiag + best.diagnostics + endpointDiag)
        }

        // Event semantics, not a quota/cooldown: identical market-state fingerprints publish once.
        // A materially new range position, swing phase, direction or reason can publish immediately.
        val hist=structure.p.dropLast(max(2,structure.p.size/12))
        val lo=percentile(hist,.10); val hi=percentile(hist,.90); val span=(hi-lo).coerceAtLeast(structure.floor*4)
        val pos=((right-lo)/span).coerceIn(-.5,1.5)
        val posBucket=(pos*10).toInt()
        val velBucket=when { velocity>micro.floor*.35 -> 1; velocity< -micro.floor*.35 -> -1; else -> 0 }
        val setupKey="${best.sign}|${best.reason}|$posBucket|$velBucket|${(best.entry/10).toInt()}"
        if(setupKey==lastSetupKey)
            return SignalResult("WAIT",0,best.score.toInt(),best.entry.toInt(),best.conflict.toInt(),"SAME_SETUP",up,down,0,visionDiag + best.diagnostics + endpointDiag)

        lastSetupKey=setupKey
        lastSignalAt=now;lastSignalSign=best.sign;lastSignalExpiry=best.expiry;lastSignalScore=best.score;lastSignalEntry=best.entry
        return SignalResult(if(best.sign>0)"UP" else "DOWN",best.expiry,best.score.toInt(),best.entry.toInt(),best.conflict.toInt(),best.reason,up,down,0,visionDiag + best.diagnostics + endpointDiag + mapOf("margin" to margin,"weighted_delta" to weightedDelta,"strong_up" to strongUp,"strong_down" to strongDown))
    }

    private fun mk(p:List<Double>,h:Int):View{val d=p.zipWithNext{a,c->abs(c-a)};return View(p,max(h*.0017,median(d).coerceAtLeast(1.0)*.90))}
    private fun candidate(sign:Int,e:Int,w:View,s:View,en:View,m:View,velocity:Double,accel:Double):C{
        fun mv(v:View,a:Double,b:Double):Double{val n=v.p.size;val i=(n*a).toInt().coerceIn(0,n-2);val j=(n*b).toInt().coerceIn(i+2,n);val q=max(2,(j-i)/4);return median(v.p.subList(j-q,j))-median(v.p.subList(i,i+q))}
        fun align(v:Double,f:Double,k:Double)=((sign*v)/(f*k)).coerceIn(-1.0,1.0)
        val wa=align(mv(w,.05,.95),w.floor,3.4);val sa=align(mv(s,.20,.98),s.floor,2.6);val ea=align(mv(en,.35,1.0),en.floor,1.7);val ma=align(mv(m,.42,1.0),m.floor,1.0)
        val va=align(velocity,m.floor,1.15);val aa=align(accel,m.floor,2.2)
        val hist=s.p.dropLast(max(2,s.p.size/12));val sup=percentile(hist,.10);val res=percentile(hist,.90);val r=median(m.p.takeLast(max(3,m.p.size/6)));val span=(res-sup).coerceAtLeast(s.floor*4);val pos=((r-sup)/span).coerceIn(-.5,1.5)
        // Symmetric location evidence: UP gets support-side reversal evidence; DOWN gets resistance-side reversal evidence.
        val level=if(sign>0)((.50-pos)/.50).coerceIn(0.0,1.0) else ((pos-.50)/.50).coerceIn(0.0,1.0)
        val breakout=if(sign>0)((r-res)/(s.floor*1.4)).coerceIn(0.0,1.0) else ((sup-r)/(s.floor*1.4)).coerceIn(0.0,1.0)
        val ds=m.p.zipWithNext{a,c->c-a};var flips=0;var last=0;for(d in ds){val z=if(d>m.floor*.1)1 else if(d< -m.floor*.1)-1 else 0;if(z!=0){if(last!=0&&z!=last)flips++;last=z}}
        val chop=flips.toDouble()/max(1,ds.size-1)
        // Horizon-specific evidence: short expiries require fresh micro confirmation; long expiries
        // require structural agreement. This prevents one fixed direction engine from being reused blindly.
        val t=((e-60)/240.0).coerceIn(0.0,1.0)
        val weights=doubleArrayOf(
            .10+.18*t, .18+.20*t, .27-.02*t, .27-.15*t, .12-.07*t, .06-.04*t
        )
        val aligned=listOf(wa,sa,ea,ma,va,aa);var directional=0.0;for(i in aligned.indices)directional+=max(0.0,aligned[i])*weights[i]
        val opposite=max(0.0,-ma)*.31+max(0.0,-ea)*.29+max(0.0,-sa)*.25+max(0.0,-wa)*.10+max(0.0,-va)*.05
        val reversal=(level*max(0.0,-sa)*(max(0.0,ma)+max(0.0,ea))/2).coerceIn(0.0,1.0)
        val continuation=(max(0.0,wa)*max(0.0,sa)*max(0.0,ea)).coerceIn(0.0,1.0)
        val timing=(.50*max(0.0,ma)+.28*max(0.0,ea)+.15*max(0.0,va)+.07*max(0.0,aa)).coerceIn(0.0,1.0)
        // A mature continuation should not chase an already stretched move whose micro momentum is fading.
        val edgeDistance=if(sign>0) ((r-res)/(s.floor*2.2)).coerceIn(0.0,1.4) else ((sup-r)/(s.floor*2.2)).coerceIn(0.0,1.4)
        val fading=(max(0.0,sa)*max(0.0,-ma) + max(0.0,ea)*max(0.0,-va)).coerceIn(0.0,1.0)
        val exhaustion=(edgeDistance*.55 + fading*.70 + max(0.0,-aa)*.18).coerceIn(0.0,1.0)
        val entryQ=(40+34*timing+18*max(0.0,ea)+10*level+8*breakout-21*chop-10*max(0.0,-va)-14*exhaustion).coerceIn(0.0,100.0)
        val conflict=(100*(opposite*.68+chop*.25+exhaustion*.07)).coerceIn(0.0,100.0)
        val horizonContext=(wa*(.18+.30*t)+sa*(.25+.20*t)+ea*(.37-.18*t)+ma*(.20-.12*t))
        val horizonBonus=(horizonContext*10).coerceIn(-10.0,10.0)
        val lateEntryPenalty=exhaustion*(3.2-1.5*t)

        // Match expiry to the observed move speed and regime instead of forcing a timeframe.
        val speed=(abs(ma)*.45+abs(va)*.35+abs(aa)*.20).coerceIn(0.0,1.0)
        val shortNeed=(speed*.55 + (1.0-chop)*.20 + max(0.0,ma)*.25).coerceIn(0.0,1.0)
        val longNeed=(abs(wa)*.40+abs(sa)*.40+max(0.0,ea)*.20).coerceIn(0.0,1.0)
        val horizonFit=((1.0-t)*shortNeed + t*longNeed)
        val horizonPenalty=abs(t-(longNeed/(shortNeed+longNeed+.001)))*9.0

        // 5m multi-scale turn logic. The analyzer already has four nested chart histories:
        // wide ~= zoomed-out context, structure ~= prior swing context, entry ~= recent leg, micro ~= current turn.
        // We do NOT blindly invert at an extreme: a lower extreme needs an actual lift; an upper extreme needs an actual roll-over.
        val wideHist=w.p.dropLast(max(3,w.p.size/12))
        val wideSup=percentile(wideHist,.10); val wideRes=percentile(wideHist,.90)
        val wideSpan=(wideRes-wideSup).coerceAtLeast(w.floor*5)
        val widePos=((r-wideSup)/wideSpan).coerceIn(-.5,1.5)
        val localLower=pos<=.30; val localUpper=pos>=.70
        val wideLower=widePos<=.34; val wideUpper=widePos>=.66
        val lowerZone=localLower && wideLower
        val upperZone=localUpper && wideUpper
        val lifting=(ma>.10 || (ea>.08 && va>-.10)) && aa>-.45
        val rolling=(ma<-.10 || (ea<-.08 && va<.10)) && aa<.45
        val priorDown=sa<-.06 || wa<-.05
        val priorUp=sa>.06 || wa>.05
        val lowerTurn=lowerZone && lifting && priorDown
        val upperTurn=upperZone && rolling && priorUp
        val zoneAdjustment=when {
            lowerTurn && sign<0 -> -58.0
            lowerTurn && sign>0 -> 25.0
            upperTurn && sign>0 -> -58.0
            upperTurn && sign<0 -> 25.0
            lowerZone && sign<0 && lifting -> -34.0
            upperZone && sign>0 && rolling -> -34.0
            else -> 0.0
        }

        // STRUCTURE FUSION: classify regime before trusting a pattern.
        val trendStrength=(abs(wa)*.42+abs(sa)*.38+abs(ea)*.20).coerceIn(0.0,1.0)
        val trendAgreement=if(wa*sa>0 && sa*ea>0) 1.0 else if(wa*sa>0 || sa*ea>0) .45 else 0.0
        val rangeRegime=(1.0-(trendStrength*.70+trendAgreement*.30)).coerceIn(0.0,1.0)
        val trendRegime=(trendStrength*.65+trendAgreement*.35).coerceIn(0.0,1.0)

        // Pivot geometry: higher-low/higher-high or lower-high/lower-low evidence.
        val piv=pivots(s.p,s.floor*.55)
        val lows=piv.filter{it.second<0}.takeLast(2).map{it.third}
        val highs=piv.filter{it.second>0}.takeLast(2).map{it.third}
        val higherLow=lows.size==2 && lows[1]>lows[0]+s.floor*.20
        val lowerHigh=highs.size==2 && highs[1]<highs[0]-s.floor*.20
        val higherHigh=highs.size==2 && highs[1]>highs[0]+s.floor*.20
        val lowerLow=lows.size==2 && lows[1]<lows[0]-s.floor*.20
        val swingBias=when(sign){
            1 -> (if(higherLow) .55 else 0.0)+(if(higherHigh) .25 else 0.0)-(if(lowerLow) .45 else 0.0)
            else -> (if(lowerHigh) .55 else 0.0)+(if(lowerLow) .25 else 0.0)-(if(higherHigh) .45 else 0.0)
        }

        // Expansion/contraction: breakouts need expansion; reversals benefit from rejection after exhaustion.
        val recentMoves=m.p.zipWithNext{a,c->abs(c-a)}
        val structMoves=s.p.zipWithNext{a,c->abs(c-a)}
        val recentVol=median(recentMoves.takeLast(max(3,recentMoves.size/2))).coerceAtLeast(.01)
        val baseVol=median(structMoves).coerceAtLeast(.01)
        val volExpansion=(recentVol/baseVol).coerceIn(.35,2.5)
        val expansionEvidence=((volExpansion-1.0)/1.0).coerceIn(0.0,1.0)
        val compressionEvidence=((1.0-volExpansion)/.65).coerceIn(0.0,1.0)

        // Failed-break / rejection: price probes beyond a structural edge then returns inside.
        val recentMax=m.p.maxOrNull()?:r; val recentMin=m.p.minOrNull()?:r
        val failedUp=(recentMax>res+s.floor*.18 && r<res-s.floor*.05)
        val failedDown=(recentMin<sup-s.floor*.18 && r>sup+s.floor*.05)
        val rejection=when { sign<0 && failedUp -> 1.0; sign>0 && failedDown -> 1.0; else -> 0.0 }

        // Shape memory: compare the newest normalized path with the preceding path and its mirror.
        val shape=shapeSimilarity(s.p)
        val mirrorTurn=if(sign>0) shape.second else shape.first

        // Context-specific evidence: trend continuation and range reversal are different setups.
        val trendContext=trendRegime*max(0.0,wa)*max(0.0,sa)*(.55+.45*expansionEvidence)
        val rangeContext=rangeRegime*level*max(0.0,ma)*(.60+.40*compressionEvidence)
        val structuralBonus=12*trendContext + 13*rangeContext + 9*swingBias + 8*rejection + 4*mirrorTurn

        // Strong counter-context penalty prevents a tiny micro wiggle from overruling the larger chart.
        val macroAgainst=max(0.0,-wa)*.48+max(0.0,-sa)*.38+max(0.0,-ea)*.14
        val contextPenalty=20*macroAgainst*(.65+.35*trendRegime)

        // REGIME-FIRST GATE: the zoomed-out structure gets veto power.
        // In a strong trend, a tiny counter-trend micro move is not enough to reverse direction.
        // At a genuine structural edge, a confirmed turn / failed break can override the trend.
        val macroAligned=max(0.0,wa)*.52+max(0.0,sa)*.34+max(0.0,ea)*.14
        val microAligned=max(0.0,ma)*.55+max(0.0,va)*.30+max(0.0,aa)*.15
        val confirmedEdgeTurn=(lowerTurn && sign>0) || (upperTurn && sign<0) || rejection>.5
        val counterTrendAttempt=trendRegime>.58 && macroAgainst>.34 && !confirmedEdgeTurn
        val trendContinuation=trendRegime>.52 && macroAligned>.34 && microAligned>.08
        val rangeEdgeTurn=rangeRegime>.45 && level>.45 && microAligned>.10
        val regimeAdjustment=when {
            counterTrendAttempt -> -32.0
            confirmedEdgeTurn -> 17.0
            trendContinuation -> 9.0
            rangeEdgeTurn -> 8.0
            else -> 0.0
        }

        val score=(38+directional*49+reversal*8+continuation*7+breakout*5+timing*6+entryQ*.09-conflict*.17-exhaustion*7+horizonBonus-lateEntryPenalty+zoneAdjustment+structuralBonus-contextPenalty+regimeAdjustment+horizonFit*7-horizonPenalty).coerceIn(0.0,96.0)
        val reason=when{rejection>.5->"FAIL_BRK";lowerTurn||upperTurn->"TURN";breakout>.45&&expansionEvidence>.18->"BRK";reversal>.45->"REV";exhaustion>.58->"EXH";trendContext>.32->"TREND";rangeContext>.28->"RANGE";else->"MOM"}
        return C(sign,e,score,entryQ,conflict,reason,mapOf(
            "wa" to wa,"sa" to sa,"ea" to ea,"ma" to ma,"va" to va,"aa" to aa,
            "support" to sup,"resistance" to res,"range_position" to pos,"wide_position" to widePos,
            "chop" to chop,"reversal" to reversal,"continuation" to continuation,"breakout" to breakout,
            "exhaustion" to exhaustion,"trend_regime" to trendRegime,"range_regime" to rangeRegime,
            "swing_bias" to swingBias,"vol_expansion" to volExpansion,"rejection" to rejection,
            "horizon_fit" to horizonFit,"entry_quality" to entryQ,"conflict_value" to conflict
        ))
    }
    private fun pivots(p:List<Double>,threshold:Double):List<Triple<Int,Int,Double>>{
        if(p.size<5)return emptyList();val out=ArrayList<Triple<Int,Int,Double>>()
        for(i in 2 until p.size-2){val v=p[i];val left=p.subList(i-2,i);val right=p.subList(i+1,i+3)
            if(v>=left.maxOrNull()!!&&v>=right.maxOrNull()!!&&(v-min(left.minOrNull()!!,right.minOrNull()!!))>=threshold)out+=Triple(i,1,v)
            else if(v<=left.minOrNull()!!&&v<=right.minOrNull()!!&&(max(left.maxOrNull()!!,right.maxOrNull()!!)-v)>=threshold)out+=Triple(i,-1,v)}
        return out
    }
    private fun shapeSimilarity(p:List<Double>):Pair<Double,Double>{
        if(p.size<24)return 0.0 to 0.0;val k=min(18,p.size/3);val a=p.subList(p.size-2*k,p.size-k);val b=p.takeLast(k)
        fun norm(x:List<Double>):List<Double>{val lo=x.minOrNull()!!;val hi=x.maxOrNull()!!;val sp=(hi-lo).coerceAtLeast(.001);return x.map{(it-lo)/sp}}
        val x=norm(a);val y=norm(b);var same=0.0;var mirror=0.0;for(i in 0 until k){same+=abs(x[i]-y[i]);mirror+=abs((1.0-x[i])-y[i])}
        return (1.0-same/k).coerceIn(0.0,1.0) to (1.0-mirror/k).coerceIn(0.0,1.0)
    }
    private fun smooth(v:List<Double>,r:Int)=v.indices.map{i->median(v.subList(max(0,i-r),min(v.size,i+r+1)))}
    private fun median(v:List<Double>):Double{if(v.isEmpty())return 0.0;val s=v.sorted();return if(s.size%2==1)s[s.size/2] else (s[s.size/2-1]+s[s.size/2])/2}
    private fun percentile(v:List<Double>,q:Double):Double{val s=v.sorted();return s[((s.size-1)*q).toInt().coerceIn(0,s.size-1)]}
    private fun wait(r:String)=SignalResult("WAIT",0,0,0,100,r,0,0,0)
}
