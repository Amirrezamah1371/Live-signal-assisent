package com.example.livesignalassistant

import android.graphics.Bitmap
import android.os.SystemClock
import java.util.Calendar
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

data class SignalResult(
    val direction: String,
    val expirySeconds: Int,
    val confidence: Int,
    val entryQuality: Int = 0,
    val conflict: Int = 100,
    val reason: String = ""
)

/** V5 PRO: multi-horizon, multi-scale, expiry-aware visual decision engine. */
object SignalAnalyzer {
    private data class Candidate(val sign:Int,val expiry:Int,val score:Double,val entry:Double,val conflict:Double,val reason:String)
    private val directionVotes = ArrayDeque<Int>()
    private var previousRight:Double? = null
    private var previousAt = 0L
    private var rememberedSign = 0
    private var rememberedStrength = 0.0

    @Synchronized fun reset(){ directionVotes.clear(); previousRight=null; previousAt=0; rememberedSign=0; rememberedStrength=0.0 }

    @Synchronized fun analyze(bitmap:Bitmap):SignalResult{
        val w=bitmap.width; val h=bitmap.height
        if(w<240||h<360) return wait(true,"LOW VISIBILITY")
        val x0=(w*.055).toInt(); val x1=(w*.79).toInt(); val y0=(h*.12).toInt(); val y1=(h*.79).toInt()
        val step=max(2,(x1-x0)/260); val raw=ArrayList<Double>(); var x=x0
        while(x<x1){
            val hits=ArrayList<Int>(); var y=y0
            while(y<y1){
                val c=bitmap.getPixel(x,y); val r=(c shr 16)and 255; val g=(c shr 8)and 255; val b=c and 255
                val hi=max(r,max(g,b)); val lo=min(r,min(g,b))
                if(hi>=95 && hi-lo>=38) hits.add(y)
                y+=2
            }
            if(hits.size>=2){ hits.sort(); raw.add(-hits[hits.size/2].toDouble()) }
            x+=step
        }
        if(raw.size<58) return wait(true,"LOW VISIBILITY")

        // Multi-eye views: same captured frame, different smoothing/context windows.
        val micro=smooth(raw,1); val medium=smooth(raw,3); val wide=smooth(raw,6); val n=medium.size
        val deltas=medium.zipWithNext{a,b->abs(b-a)}
        val noise=median(deltas).coerceAtLeast(1.0); val floor=max(h*.0019,noise*.95)
        fun move(p:List<Double>,a:Double,b:Double):Double{
            val i=(n*a).toInt().coerceIn(0,n-2); val j=(n*b).toInt().coerceIn(i+2,n); val q=max(2,(j-i)/4)
            return median(p.subList(j-q,j))-median(p.subList(i,i+q))
        }
        val broad=move(wide,.05,.62); val swing=move(wide,.38,.82); val fast=move(medium,.70,1.0)
        val microMove=move(micro,.84,1.0); val ultra=move(micro,.94,1.0)
        val right=median(micro.takeLast(max(4,n/20)))
        val now=SystemClock.elapsedRealtime(); val dt=((now-previousAt).coerceAtLeast(1L))/1000.0
        val frame=previousRight?.let{(right-it)/dt}?:0.0; previousRight=right; previousAt=now

        val hist=wide.subList(0,max(18,(n*.82).toInt())); val support=percentile(hist,.10); val resistance=percentile(hist,.90)
        val range=(resistance-support).coerceAtLeast(floor*4); val pos=((right-support)/range).coerceIn(-.5,1.5)

        val recent=micro.takeLast(max(18,n/3)).zipWithNext{a,b->b-a}; var flips=0; var last=0
        for(d in recent){ val s=when{d>floor*.10->1;d< -floor*.10->-1;else->0}; if(s!=0){if(last!=0&&s!=last)flips++;last=s}}
        val chop=(flips.toDouble()/max(1,recent.size-1)).coerceIn(0.0,1.0)
        val velocity=recent.takeLast(max(4,recent.size/4)).average()
        val priorVelocity=recent.take(max(4,recent.size*3/4)).takeLast(max(4,recent.size/4)).average()
        val acceleration=velocity-priorVelocity
        val volatility=(median(deltas)/floor).coerceIn(.4,3.0)

        val expiries=intArrayOf(30,60,120,180,300,600,900)
        fun candidate(sign:Int,expiry:Int):Candidate{
            fun al(v:Double,scale:Double)=((sign*v)/(floor*scale)).coerceIn(-1.0,1.0)
            val broadA=al(broad,3.0); val swingA=al(swing,2.4); val fastA=al(fast,1.5); val microA=al(microMove,1.0); val ultraA=al(ultra,.72)
            val frameA=((sign*frame)/(floor*1.0)).coerceIn(-1.0,1.0); val accelA=((sign*acceleration)/(floor*.55)).coerceIn(-1.0,1.0)
            val nearLevel=if(sign>0)((.40-pos)/.40).coerceIn(0.0,1.0) else ((pos-.60)/.40).coerceIn(0.0,1.0)
            val breakout=if(sign>0)((right-resistance)/(floor*1.5)).coerceIn(0.0,1.0) else ((support-right)/(floor*1.5)).coerceIn(0.0,1.0)
            val fresh=(max(0.0,ultraA)+max(0.0,microA)+max(0.0,frameA))/3.0
            val trend=(max(0.0,broadA)+max(0.0,swingA)+max(0.0,fastA))/3.0
            val reversal=(nearLevel*max(0.0,-broadA)*(max(0.0,microA)+max(0.0,ultraA))/2).coerceIn(0.0,1.0)
            val continuation=(max(0.0,broadA)*max(0.0,fastA)*max(0.0,microA)).coerceIn(0.0,1.0)
            val horizon=(expiry/900.0).coerceIn(0.0,1.0)
            // Short horizons favor fresh micro evidence; long horizons favor structure/context.
            val directional=(1-horizon)*(fresh*.46+max(0.0,fastA)*.24+max(0.0,accelA)*.12+reversal*.10+breakout*.08) +
                horizon*(trend*.48+continuation*.18+fresh*.15+breakout*.10+reversal*.09)
            val opposite=(max(0.0,-microA)*.38+max(0.0,-frameA)*.27+max(0.0,-fastA)*.20+max(0.0,-broadA)*.15)
            val lateChase=(max(0.0,ultraA)*max(0.0,microA)*(1.0-nearLevel)*(if(pos in .18.. .82) .35 else .65)).coerceIn(0.0,1.0)
            val entry=(100*(fresh*.48+nearLevel*.15+max(0.0,accelA)*.13+reversal*.12+breakout*.12)-lateChase*18-chop*10).coerceIn(0.0,100.0)
            val conflict=(100*(opposite*.68+chop*.22+if(volatility>2.3) .10 else 0.0)).coerceIn(0.0,100.0)
            val context=MarketContextEngine.modifier(expiry)
            val score=(34+directional*54+entry*.14-conflict*.18+context).coerceIn(0.0,96.0)
            val reason=when{reversal>.55->"REVERSAL";breakout>.55->"BREAKOUT";continuation>.45->"CONTINUATION";else->"MOMENTUM"}
            return Candidate(sign,expiry,score,entry,conflict,reason)
        }
        val all=ArrayList<Candidate>(); for(e in expiries){all+=candidate(1,e);all+=candidate(-1,e)}
        val sorted=all.sortedByDescending{it.score}; val best=sorted[0]
        val oppositeBest=sorted.filter{it.sign!=best.sign}.maxByOrNull{it.score}!!

        // Signal memory: minor uncertainty does not instantly erase a sound direction.
        if(best.score>=68 && best.entry>=57 && best.conflict<=47){
            if(rememberedSign==best.sign) rememberedStrength=(rememberedStrength*.65+best.score*.35).coerceAtMost(96.0)
            else {rememberedSign=best.sign; rememberedStrength=best.score}
        } else if(best.conflict>62 || oppositeBest.score>best.score+5){ rememberedSign=0; rememberedStrength=0.0 }

        val effective=if(rememberedSign==best.sign) max(best.score,rememberedStrength-3) else best.score
        if(effective<70 || best.entry<59 || best.conflict>52 || best.score-oppositeBest.score<4) return wait(false,best.reason)

        directionVotes.addLast(best.sign); while(directionVotes.size>3)directionVotes.removeFirst()
        if(directionVotes.count{it==best.sign}<2) return wait(false,"CONFIRMING")
        return SignalResult(if(best.sign>0)"UP" else "DOWN",best.expiry,effective.toInt(),best.entry.toInt(),best.conflict.toInt(),best.reason)
    }

    private fun smooth(v:List<Double>,r:Int)=v.indices.map{i->median(v.subList(max(0,i-r),min(v.size,i+r+1)))}
    private fun median(v:List<Double>):Double{if(v.isEmpty())return 0.0;val s=v.sorted();return if(s.size%2==1)s[s.size/2] else (s[s.size/2-1]+s[s.size/2])/2}
    private fun percentile(v:List<Double>,q:Double):Double{val s=v.sorted();return s[((s.size-1)*q).toInt().coerceIn(0,s.size-1)]}
    private fun wait(clear:Boolean=false,reason:String=""):SignalResult{if(clear)reset();return SignalResult("WAIT",0,0,0,100,reason)}
}

/** Lightweight local market context. Live news is intentionally NOT fabricated: it needs a real data API later. */
object MarketContextEngine{
    fun modifier(expirySeconds:Int):Double{
        val c=Calendar.getInstance(java.util.TimeZone.getTimeZone("UTC")); val h=c.get(Calendar.HOUR_OF_DAY); val m=c.get(Calendar.MINUTE)
        val liquid=h in 7..16
        val rollover=h==21 || h==22
        val boundary=m<2 || m>57
        var x=0.0
        if(liquid)x+=1.5
        if(rollover)x-=3.0
        if(boundary && expirySeconds<=60)x-=1.5
        return x
    }
}
