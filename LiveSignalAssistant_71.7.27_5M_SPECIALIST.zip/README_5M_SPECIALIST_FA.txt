Live Signal Assistant 71.7.27 — 5M SPECIALIST

هدف: فقط یک افق معاملاتی: T+300 ثانیه از لحظه OPEN/LOCK.
چرخه تصمیم: 360 ثانیه = 300 ثانیه context + 60 ثانیه final brain.

اصلاحات اصلی:
1) SignalAnalyzer برای expiry=300 تنظیم شده؛ 1M-only حذف شده.
2) هر observation دارای monotonic timestamp واقعی است؛ timestamp مصنوعی 1s fallback حذف شده.
3) trajectory چندپنجره‌ای 15/30/60/120/240s.
4) sudden change فقط با چند پنجره تایید می‌شود؛ single spike جهت را flip نمی‌کند.
5) Direction و Entry Quality جدا هستند؛ late impulse/regime transition می‌تواند WAIT بدهد.
6) trace_pos نرمال‌شده برای کاهش اثر auto-rescale در تحلیل cross-frame.
7) extractor به جای interior fill، upper edge هر blue run را دنبال می‌کند.
8) Experience پنج‌دقیقه‌ای مستقل: permanent_experience/experience_5m_v1.json.
9) old 1M Experience وارد تصمیم‌های 5M نمی‌شود.
10) score با عنوان STRENGTH نمایش داده می‌شود و probability برد تلقی نمی‌شود.
11) applicationId حفظ شده: com.example.livesignalassistant.finalbrain90
12) WIN/LOSS آموزش می‌دهد؛ VOID آموزش نمی‌دهد.
13) session export/clear نباید Experience دائمی را حذف کند.

نکته اعتبارسنجی:
این نسخه یک build مهندسی/آزمایشی است. نرخ برد تضمین یا کالیبره نشده و باید با replay/demo و سپس out-of-sample سنجیده شود.
