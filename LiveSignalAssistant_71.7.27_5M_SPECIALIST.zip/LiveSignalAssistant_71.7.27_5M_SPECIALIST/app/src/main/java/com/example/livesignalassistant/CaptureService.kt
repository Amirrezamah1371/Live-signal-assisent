package com.example.livesignalassistant

import android.app.*
import android.content.*
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.hardware.display.*
import android.media.ImageReader
import android.media.projection.*
import android.os.*
import android.provider.Settings
import android.view.*
import android.widget.*
import androidx.core.app.NotificationCompat
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean
import java.util.UUID
import kotlin.math.*

class CaptureService:Service(){
 companion object{const val EXTRA_RESULT_CODE="result_code";const val EXTRA_RESULT_DATA="result_data";const val ACTION_EXPORT="lsa.export";private const val CHANNEL="lsa_v70";private const val NID=1700}
 private var projection:MediaProjection?=null;private var reader:ImageReader?=null;private var display:VirtualDisplay?=null
 private var wm:WindowManager?=null;private var brain:TextView?=null;private val bubbles=mutableListOf<View>();private val main=Handler(Looper.getMainLooper());private val worker=Executors.newSingleThreadExecutor();private val evidenceWorker=Executors.newSingleThreadExecutor();private val busy=AtomicBoolean(false)
 private data class TimedObservation(val monoMs:Long,val elapsedMs:Long,val result:SignalResult)
 private lateinit var memory:MemoryStore;private lateinit var experience:ExperienceStore;private var lastFrameAt=0L;private var lastEvidenceAt=0L;private var cycleStart=SystemClock.elapsedRealtime();private var nextDecisionAt=cycleStart+360000L;private var nextObservationAt=cycleStart+1000L;private val observations=mutableListOf<TimedObservation>();private var cycle=1
 override fun onCreate(){super.onCreate();memory=MemoryStore(this);experience=ExperienceStore(this);channel();startForeground(NID,NotificationCompat.Builder(this,CHANNEL).setContentTitle("71/7/27 · 5M Specialist").setContentText("5m context · 60s final brain · 5m expiry").setSmallIcon(android.R.drawable.ic_menu_view).setOngoing(true).build());memory.event("SESSION_START")}
 override fun onStartCommand(i:Intent?,f:Int,id:Int):Int{
  if(i?.action==ACTION_EXPORT){val p=memory.exportZip();Toast.makeText(this,"Memory exported: $p",Toast.LENGTH_LONG).show();return START_NOT_STICKY}
  if(!Settings.canDrawOverlays(this)){stopSelf();return START_NOT_STICKY};showBrain();val code=i?.getIntExtra(EXTRA_RESULT_CODE,Activity.RESULT_CANCELED)?:Activity.RESULT_CANCELED;val data:Intent?=if(Build.VERSION.SDK_INT>=33)i?.getParcelableExtra(EXTRA_RESULT_DATA,Intent::class.java) else @Suppress("DEPRECATION") i?.getParcelableExtra(EXTRA_RESULT_DATA)
  if(code!=Activity.RESULT_OK||data==null){stopSelf();return START_NOT_STICKY};if(projection!=null)return START_NOT_STICKY;val mgr=getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager;projection=mgr.getMediaProjection(code,data);projection?.registerCallback(object:MediaProjection.Callback(){override fun onStop(){stopSelf()}},main);startCapture();return START_NOT_STICKY
 }
 private fun glass(stroke:Int=0x55FFFFFF)=GradientDrawable().apply{setColor(0xB8FFFFFF.toInt());cornerRadius=42f;setStroke(2,stroke)}
 private fun showBrain(){main.post{if(brain!=null)return@post;wm=getSystemService(WINDOW_SERVICE) as WindowManager;val v=TextView(this).apply{text="71/7/27 · 5M SPECIALIST\ncycle 1";textSize=13f;setTextColor(Color.BLACK);gravity=Gravity.CENTER;setPadding(18,12,18,12);background=glass();elevation=16f};val lp=params(Gravity.TOP or Gravity.END,18,190);wm!!.addView(v,lp);brain=v}}
 private fun params(g:Int,x:Int,y:Int)=WindowManager.LayoutParams(WindowManager.LayoutParams.WRAP_CONTENT,WindowManager.LayoutParams.WRAP_CONTENT,if(Build.VERSION.SDK_INT>=26)WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,PixelFormat.TRANSLUCENT).apply{gravity=g;this.x=x;this.y=y}
 private fun startCapture(){val m=resources.displayMetrics;reader=ImageReader.newInstance(m.widthPixels,m.heightPixels,PixelFormat.RGBA_8888,2);display=projection?.createVirtualDisplay("LSA70",m.widthPixels,m.heightPixels,m.densityDpi,DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,reader!!.surface,null,main);reader?.setOnImageAvailableListener({r->val now=SystemClock.elapsedRealtime();val im=r.acquireLatestImage()?:return@setOnImageAvailableListener;if(now-lastFrameAt<250||busy.get()){im.close();return@setOnImageAvailableListener};lastFrameAt=now;busy.set(true);try{val p=im.planes[0];val pad=p.rowStride-p.pixelStride*im.width;val tmp=Bitmap.createBitmap(im.width+pad/p.pixelStride,im.height,Bitmap.Config.ARGB_8888);tmp.copyPixelsFromBuffer(p.buffer);val b=Bitmap.createBitmap(tmp,0,0,im.width,im.height);tmp.recycle();worker.execute{try{processFrame(b,now)}finally{b.recycle();busy.set(false)}}}catch(_:Throwable){busy.set(false)}finally{im.close()}},main)}
 private fun recordFrameAsync(b:Bitmap,tag:String){
  val copy=b.copy(Bitmap.Config.ARGB_8888,false)
  evidenceWorker.execute{try{memory.frame(copy,tag)}catch(t:Throwable){memory.event("RECORDER_ERROR",mapOf("message" to (t.message?:t.javaClass.simpleName)))}finally{copy.recycle()}}
 }
 private fun processFrame(b:Bitmap,now:Long){
  // Black-box screenshots are sampled every 3s; analysis still runs at its normal cadence.
  // This cuts session storage sharply without weakening the live analyzer.
  if(now-lastEvidenceAt>=3000L){recordFrameAsync(b,"observe");lastEvidenceAt=now}
  val elapsed=now-cycleStart
  // 1M path clock: one analyzed observation each second. Capture itself may run faster;
  // decision timing is monotonic and independent from frame-arrival jitter.
  if(now>=nextObservationAt && now<nextDecisionAt){
   val r=SignalAnalyzer.analyze(b);synchronized(observations){observations+=TimedObservation(now,elapsed,r)}
   memory.event("BOT_OBSERVATION",mapOf("cycle" to cycle,"cycle_elapsed_ms" to elapsed,"phase" to if(elapsed<300000L)"CONTEXT_BUILD" else "FINAL_WINDOW","direction" to r.direction,"expiry_s" to r.expirySeconds,"raw_confidence" to r.confidence,"entry" to r.entryQuality,"conflict" to r.conflict,"reason" to r.reason,"up" to r.upScore,"down" to r.downScore,"diagnostics" to r.diagnostics))
   do{nextObservationAt+=1000L}while(nextObservationAt<=now)
  }
  val left=max(0,((nextDecisionAt-now+999)/1000).toInt())
   val phase=if(elapsed<300000L)"CONTEXT BUILD" else "FINAL BRAIN"
   main.post{brain?.text="71.7.27 · 5M · $phase ${left}s\ncycle $cycle"}
  if(now>=nextDecisionAt){
   finishCycle(b,nextDecisionAt)
   // Anchor cycles to the monotonic schedule, never to a late frame; this prevents cumulative drift.
   val late=now-nextDecisionAt
    // If Android was paused long enough to miss a boundary, skip stale cycles instead of emitting catch-up signals.
    cycleStart=nextDecisionAt
    nextDecisionAt+=360000L
    if(late>=360000L){
     val skipped=late/360000L
     cycleStart+=skipped*360000L
     nextDecisionAt=cycleStart+360000L
     memory.event("STALE_CYCLES_SKIPPED",mapOf("count" to skipped,"late_ms" to late))
    }
    nextObservationAt=cycleStart+1000L;cycle++
   synchronized(observations){observations.clear()}
  }
 }
 private fun finishCycle(b:Bitmap,boundaryMono:Long){
   val timed=synchronized(observations){observations.toList()}
   val list=timed.map{it.result}
   val usable=timed.filter{it.result.direction=="UP"||it.result.direction=="DOWN"}
   fun d(r:SignalResult,key:String)=((r.diagnostics[key] as? Number)?.toDouble())
   data class Pt(val t:Long,val p:Double,val floor:Double,val quality:Double)
   val path=timed.mapNotNull{o->
    val pr=d(o.result,"trace_right");val fl=d(o.result,"trace_floor");val cov=d(o.result,"vision_coverage")?:0.0
    if(pr!=null&&fl!=null&&cov>=.30)Pt(o.elapsedMs,pr,fl.coerceAtLeast(.01),cov)else null
   }
   fun tail(seconds:Int):List<Pt>{if(path.isEmpty())return emptyList();val cut=path.last().t-seconds*1000L;return path.filter{it.t>=cut}}
   fun slope(q:List<Pt>):Double{
    if(q.size<3)return 0.0
    val floor=q.map{it.floor}.average().coerceAtLeast(.01)
    val mt=q.map{it.t.toDouble()}.average();val mp=q.map{it.p}.average()
    var num=0.0;var den=0.0
    for(x in q){val dt=(x.t-mt)/1000.0;num+=dt*(x.p-mp);den+=dt*dt}
    return if(den<=1e-9)0.0 else (num/den)/floor
   }
   val s15=slope(tail(15));val s30=slope(tail(30));val s60=slope(tail(60));val s120=slope(tail(120));val s300=slope(tail(300))
   val finalMomentum=s15*.22+s30*.28+s60*.25+s120*.15+s300*.10
   val contextMomentum=s60*.25+s120*.35+s300*.40
   val acceleration=(s15-s60);val jerk=(s15-s30)-(s30-s60)
   val finalSign=when{finalMomentum>.010->1;finalMomentum<-.010->-1;else->0}
   val contextSign=when{contextMomentum>.006->1;contextMomentum<-.006->-1;else->0}
   val suddenChange=contextSign!=0&&finalSign==-contextSign&&abs(finalMomentum)>=.025&&abs(s15)>=.030&&abs(s30)>=.018
   val alignedFinal=listOf(s15,s30,s60).count{if(finalSign>0)it>.006 else if(finalSign<0)it<-.006 else false}
   val persistentChange=suddenChange&&alignedFinal>=2
   val extractionCoverage=if(timed.isEmpty())0.0 else path.size.toDouble()/timed.size
   val stalenessMs=if(path.isEmpty())Long.MAX_VALUE else (timed.lastOrNull()?.elapsedMs?:0L)-path.last().t
   val recent=usable.filter{it.elapsedMs>=(timed.lastOrNull()?.elapsedMs?:0L)-60000L}
   val recentFlips=recent.zipWithNext().count{(a,c)->a.result.direction!=c.result.direction}
   fun recencyWeight(ageMs:Long):Double=exp(-ageMs/110000.0)
   val endT=timed.lastOrNull()?.elapsedMs?:0L
   var upW=0.0;var downW=0.0
   for(o in usable){val age=(endT-o.elapsedMs).coerceAtLeast(0);val q=(0.55+o.result.entryQuality.coerceIn(0,100)/220.0)*recencyWeight(age);if(o.result.direction=="UP")upW+=q else downW+=q}
   val voteSide=when{upW>downW*1.10->"UP";downW>upW*1.10->"DOWN";else->"WAIT"}
   val trajectorySide=if(finalSign>0)"UP" else if(finalSign<0)"DOWN" else "WAIT"
   val contextSide=if(contextSign>0)"UP" else if(contextSign<0)"DOWN" else "WAIT"
   val deterministicSide=when{
    persistentChange->trajectorySide
    trajectorySide!="WAIT"&&contextSide==trajectorySide->trajectorySide
    trajectorySide!="WAIT"&&voteSide==trajectorySide->trajectorySide
    contextSide!="WAIT"&&voteSide==contextSide&&abs(finalMomentum)<.018->contextSide
    else->"WAIT"
   }
   val lateStretch=abs(s15)>.075&&abs(s15)>abs(s60)*1.8
   val exhaustion=lateStretch&&sign(s15)==sign(s30)&&abs(acceleration)>.045&&sign(acceleration)!=sign(s15-s120)
   val unstable=recentFlips>8 || (sign(s15)!=0.0&&sign(s30)!=0.0&&sign(s15)!=sign(s30)&&abs(s15)>.025)
   val qualityOk=extractionCoverage>=.55&&stalenessMs<=3500L&&path.size>=90
   val entryOk=!exhaustion&&!unstable&&(alignedFinal>=2||abs(contextMomentum)>=.015)
   val experienceFeatures=mapOf<String,Any?>(
    "slope_15s" to s15,"slope_30s" to s30,"slope_60s" to s60,"slope_120s" to s120,"slope_300s" to s300,
    "trajectory_jerk" to jerk,"counter_magnitude" to if(contextSign==0)0.0 else max(0.0,-contextSign*finalMomentum),
    "persistence_decay" to if(contextSign==0)0.0 else max(0.0,contextSign*(contextMomentum-finalMomentum)),
    "recent_direction_flips" to recentFlips,"trend_regime" to min(1.0,abs(contextMomentum)*12),"range_regime" to max(0.0,1.0-min(1.0,abs(contextMomentum)*12)))
   val advice=experience.advise(contextSide,trajectorySide,deterministicSide,experienceFeatures)
   val side=if(deterministicSide=="WAIT")"WAIT" else advice.side
   val chosen=usable.filter{it.result.direction==side}.map{it.result}
   val representative=chosen.takeLast(min(20,chosen.size)).maxByOrNull{it.entryQuality*.50-it.conflict*.20+it.signalQuality*.08}
   val strength=(45.0+min(25.0,abs(finalMomentum)*240)+min(15.0,abs(contextMomentum)*180)+(if(persistentChange)5 else 0)-(recentFlips*1.5)).coerceIn(0.0,95.0).toInt()
   val reason=when{!qualityOk->"TRACE_QUALITY";unstable->"REGIME_UNSTABLE";exhaustion->"LATE_ENTRY_RISK";side=="WAIT"->"NO_5M_CONSENSUS";persistentChange->"CONFIRMED_CHANGE";else->"5M_CONSENSUS"}
   val diag=mapOf<String,Any?>(
    "cycle_mode" to "5M_SPECIALIST_300_PLUS_60","context_ms" to 300000,"final_window_ms" to 60000,"fixed_horizon_ms" to 300000,"timeframe" to "5m",
    "slope_15s" to s15,"slope_30s" to s30,"slope_60s" to s60,"slope_120s" to s120,"slope_300s" to s300,
    "final_momentum" to finalMomentum,"context_momentum" to contextMomentum,"trajectory_jerk" to jerk,"sudden_change" to suddenChange,"persistent_change" to persistentChange,
    "extraction_coverage" to extractionCoverage,"path_points" to path.size,"staleness_ms" to stalenessMs,"recent_direction_flips" to recentFlips,
    "base_side" to contextSide,"final_recent_side" to trajectorySide,"vote_side" to voteSide,"deterministic_side" to deterministicSide,
    "entry_ok" to entryOk,"late_stretch" to lateStretch,"exhaustion" to exhaustion,"experience_applied" to advice.applied,"experience_samples" to advice.samples,"experience_delta" to advice.learnedDelta,
    "experience_chosen_rate" to advice.chosenRate,"experience_alternate_rate" to advice.alternateRate,"experience_key" to advice.key)+experienceFeatures
   val result=if(side!="WAIT"&&qualityOk&&entryOk&&representative!=null)
    representative.copy(direction=side,expirySeconds=300,confidence=-1,signalQuality=strength,reason=reason,diagnostics=representative.diagnostics+diag)
   else SignalResult("WAIT",300,-1,reason=reason,diagnostics=diag)
   recordFrameAsync(b,"decision")
   val actual=SystemClock.elapsedRealtime();memory.event("FIVE_MINUTE_DECISION",mapOf(
    "cycle" to cycle,"cycle_mode" to "5M_SPECIALIST_300_PLUS_60","timeframe" to "5m","fixed_expiry_ms" to 300000,
    "scheduled_boundary_mono_ms" to boundaryMono,"actual_decision_mono_ms" to actual,"decision_latency_ms" to (actual-boundaryMono).coerceAtLeast(0),
    "direction" to result.direction,"expiry_s" to 300,"observations" to timed.size,"usable" to usable.size,"reason" to result.reason,"diagnostics" to result.diagnostics))
   main.post{brain?.text=if(result.direction=="WAIT")"WAIT · 5M SPECIALIST\\ncycle $cycle" else "${if(result.direction=="UP")"↑" else "↓"} ${result.direction} · 5m\\nFINAL";if(result.direction!="WAIT")spawn(result.copy(expirySeconds=300))}
  }
 private fun dp(v:Int)=(v*resources.displayMetrics.density).roundToInt()
 private fun spawn(r:SignalResult){
  val manager=wm?:return;val arrow=if(r.direction=="UP")"↑" else "↓";val signalId=UUID.randomUUID().toString()
  val percentText=if(r.signalQuality>0)"SCORE ${r.signalQuality}" else "SCORE --"
  val v=TextView(this).apply{text="$arrow ${r.direction} · ${r.expirySeconds/60}m · $percentText\nOPEN";textSize=11f;setTextColor(Color.BLACK);gravity=Gravity.CENTER;setPadding(dp(8),dp(5),dp(8),dp(5));background=glass();elevation=18f}
  val lp=params(Gravity.TOP or Gravity.START,dp(4),dp(120)+bubbles.size*dp(52));manager.addView(v,lp);bubbles+=v;restack()
  memory.event("SIGNAL_PUBLISHED",mapOf("signal_id" to signalId,"direction" to r.direction,"expiry_s" to r.expirySeconds,"confidence_state" to "CALIBRATING","model_score" to r.signalQuality,"auto_expire_s" to 15,"diagnostics" to r.diagnostics));var locked=false
  val expire=Runnable{if(!locked){memory.event("SIGNAL_NOT_EXECUTED_TIMEOUT",mapOf("signal_id" to signalId,"direction" to r.direction,"expiry_s" to r.expirySeconds,"model_score" to r.signalQuality,"visible_for_s" to 15));try{manager.removeView(v)}catch(_:Throwable){};bubbles.remove(v);restack()}}
  main.postDelayed(expire,15000L)
  v.setOnClickListener{if(locked)return@setOnClickListener;locked=true;main.removeCallbacks(expire);val startedNs=SystemClock.elapsedRealtimeNanos();val targetNs=startedNs+r.expirySeconds.toLong()*1_000_000_000L;memory.event("TRADE_USER_OPENED",mapOf("signal_id" to signalId,"direction" to r.direction,"expiry_s" to r.expirySeconds,"entry_mono_ns" to startedNs,"target_mono_ns" to targetNs,"model_score" to r.signalQuality));fun tick(){val nowNs=SystemClock.elapsedRealtimeNanos();val remainNs=(targetNs-nowNs).coerceAtLeast(0L);if(remainNs>0){val cs=(remainNs/10_000_000L);val sec=cs/100;val hundredths=cs%100;v.text="$arrow ${r.direction} · $percentText\nLOCKED · ${sec}.${hundredths.toString().padStart(2,'0')}s";main.postDelayed({tick()},10)}else{memory.event("EXPIRY_CLOCK",mapOf("signal_id" to signalId,"target_mono_ns" to targetNs,"actual_mono_ns" to nowNs,"timer_error_ns" to (nowNs-targetNs).coerceAtLeast(0L)));showResultButtons(v,r,signalId)}};tick()}
 }
 private fun showResultButtons(old:TextView,r:SignalResult,signalId:String){val manager=wm?:return;val lp=old.layoutParams as WindowManager.LayoutParams;try{manager.removeView(old)}catch(_:Throwable){};bubbles.remove(old);val row=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;background=glass();setPadding(8,6,8,6)};fun btn(t:String){row.addView(Button(this).apply{text=t;textSize=10f;setOnClickListener{
   memory.event("TRADE_RESULT",mapOf("signal_id" to signalId,"result" to t,"direction" to r.direction,"expiry_s" to r.expirySeconds,"model_score" to r.signalQuality,"diagnostics" to r.diagnostics))
   if(t=="WIN"||t=="LOSS"){
    val base=(r.diagnostics["base_side"] as? String)?:"WAIT"
    val recent=(r.diagnostics["final_recent_side"] as? String)?:"WAIT"
    experience.learn(base,recent,r.direction,t,r.diagnostics)
    val st=experience.stats();memory.event("EXPERIENCE_LEARNED",mapOf("signal_id" to signalId,"result" to t,"lifetime_results" to st.first,"profiles" to st.second))
   }
   try{manager.removeView(row)}catch(_:Throwable){};bubbles.remove(row);restack()
  }})};btn("WIN");btn("LOSS");btn("VOID");manager.addView(row,lp);bubbles+=row;restack();memory.event("RESULT_REQUESTED",mapOf("signal_id" to signalId,"direction" to r.direction,"expiry_s" to r.expirySeconds,"model_score" to r.signalQuality))}
 private fun restack(){bubbles.forEachIndexed{i,v->try{val lp=v.layoutParams as WindowManager.LayoutParams;lp.y=dp(120)+i*dp(52);wm?.updateViewLayout(v,lp)}catch(_:Throwable){}}}
 private fun channel(){if(Build.VERSION.SDK_INT>=26)getSystemService(NotificationManager::class.java).createNotificationChannel(NotificationChannel(CHANNEL,"Live Signal 7.1 Memory",NotificationManager.IMPORTANCE_LOW))}
 override fun onDestroy(){memory.event("SESSION_STOP");reader?.setOnImageAvailableListener(null,null);display?.release();reader?.close();try{projection?.stop()}catch(_:Throwable){};worker.shutdownNow();evidenceWorker.shutdown();main.post{try{brain?.let{wm?.removeView(it)}}catch(_:Throwable){};bubbles.toList().forEach{try{wm?.removeView(it)}catch(_:Throwable){}}};super.onDestroy()}
 override fun onBind(i:Intent?):IBinder?=null
}
