package com.example.livesignalassistant

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/**
 * Permanent, compact learning memory.
 *
 * Deliberately separate from /files/sessions: normal session export/clear never touches this store.
 * It stores aggregated setup statistics only — no screenshots and no per-second observations.
 */
class ExperienceStore(private val ctx: Context) {
    data class Advice(
        val side:String,
        val applied:Boolean,
        val learnedDelta:Double,
        val samples:Int,
        val chosenRate:Double?,
        val alternateRate:Double?,
        val key:String
    )
    private val file=File(ctx.filesDir,"permanent_experience/experience_5m_v1.json")
    private val lock=Any()
    private val maxProfiles=384

    private fun num(m:Map<String,Any?>,k:String)=((m[k] as? Number)?.toDouble())?:0.0
    private fun bin(v:Double,step:Double,lo:Int=-9,hi:Int=9)=
        kotlin.math.floor(v/step).toInt().coerceIn(lo,hi)
    private fun regime(m:Map<String,Any?>):String{
        val t=num(m,"trend_regime");val r=num(m,"range_regime")
        return when{t>=.62->"TREND";r>=.55->"RANGE";else->"MIXED"}
    }
    // Coarse bins are intentional: nearby states share experience instead of memorising exact noise.
    private fun contextKey(base:String,recent:String,m:Map<String,Any?>):String =
        listOf(
            "b=$base","r=$recent","rg=${regime(m)}",
            "c=${bin(num(m,"counter_magnitude"),.18,0,8)}",
            "p=${bin(num(m,"persistence_decay"),.20,0,8)}",
            "j=${bin(num(m,"trajectory_jerk"),.35,-8,8)}",
            "s30=${bin(num(m,"slope_30s"),.10,-8,8)}",
            "s60=${bin(num(m,"slope_60s"),.08,-8,8)}",
            "s120=${bin(num(m,"slope_120s"),.06,-8,8)}",
            "eq=${bin(num(m,"entry_quality_5m"),12.5,0,8)}",
            "x=${bin(num(m,"recent_direction_flips"),1.5,0,6)}"
        ).joinToString("|")

    private fun load():JSONObject{
        file.parentFile?.mkdirs()
        if(!file.exists())return JSONObject().put("version",1).put("profiles",JSONObject()).put("total_results",0)
        return try{JSONObject(file.readText())}catch(_:Throwable){JSONObject().put("version",1).put("profiles",JSONObject()).put("total_results",0)}
    }
    private fun save(o:JSONObject){
        file.parentFile?.mkdirs()
        val tmp=File(file.parentFile,"experience_5m_v1.tmp")
        tmp.writeText(o.toString())
        if(file.exists())file.delete()
        tmp.renameTo(file)
    }
    private fun rate(p:JSONObject?):Pair<Double,Int>{
        if(p==null)return .5 to 0
        val w=p.optDouble("win_weight",0.0);val l=p.optDouble("loss_weight",0.0)
        val n=p.optInt("samples",0)
        // Beta prior prevents tiny samples from dominating.
        return ((w+3.0)/(w+l+6.0)) to n
    }

    fun advise(base:String,recent:String,proposed:String,features:Map<String,Any?>):Advice=synchronized(lock){
        if(proposed!="UP"&&proposed!="DOWN")return@synchronized Advice(proposed,false,0.0,0,null,null,"")
        val o=load();val ps=o.optJSONObject("profiles")?:JSONObject()
        val key=contextKey(base,recent,features)
        val chosen=ps.optJSONObject("$key|a=$proposed")
        val altSide=if(proposed=="UP")"DOWN" else "UP"
        val alt=ps.optJSONObject("$key|a=$altSide")
        val (cr,cn)=rate(chosen);val (ar,an)=rate(alt)
        val evidence=min(cn,an)
        val delta=ar-cr
        // Learning may reverse a proposal only with two-sided history and a material edge.
        // Otherwise it only records diagnostics and lets the deterministic brain lead.
        val switch=evidence>=6 && delta>=.10 && an>=6 && cn>=6
        Advice(if(switch)altSide else proposed,switch,delta,evidence,if(cn>0)cr else null,if(an>0)ar else null,key)
    }

    fun learn(base:String,recent:String,executed:String,result:String,features:Map<String,Any?>){
        if(executed!="UP"&&executed!="DOWN")return
        if(result!="WIN"&&result!="LOSS")return // VOID never trains.
        synchronized(lock){
            val o=load();val ps=o.optJSONObject("profiles")?:JSONObject().also{o.put("profiles",it)}
            val key=contextKey(base,recent,features)+"|a=$executed"
            val p=ps.optJSONObject(key)?:JSONObject().also{
                it.put("samples",0);it.put("wins",0);it.put("losses",0)
                it.put("win_weight",0.0);it.put("loss_weight",0.0);it.put("last_ts",0L);ps.put(key,it)
            }
            // Long-memory with gentle decay in weighted evidence; raw lifetime counts are never discarded.
            val ww=p.optDouble("win_weight",0.0)*.997
            val lw=p.optDouble("loss_weight",0.0)*.997
            p.put("samples",p.optInt("samples",0)+1)
            if(result=="WIN"){p.put("wins",p.optInt("wins",0)+1);p.put("win_weight",ww+1.0);p.put("loss_weight",lw)}
            else{p.put("losses",p.optInt("losses",0)+1);p.put("win_weight",ww);p.put("loss_weight",lw+1.0)}
            p.put("last_ts",System.currentTimeMillis())
            o.put("total_results",o.optInt("total_results",0)+1)

            // Bound storage: merge/prune only least-used profiles; lifetime aggregate remains tiny.
            if(ps.length()>maxProfiles){
                val keys=ps.keys().asSequence().toList()
                val victim=keys.minByOrNull{ps.optJSONObject(it)?.optInt("samples",0)?:0}
                if(victim!=null && victim!=key)ps.remove(victim)
            }
            save(o)
        }
    }

    fun snapshotFile():File?=synchronized(lock){if(file.exists())file else null}
    fun stats(): Pair<Int, Int> = synchronized(lock) {
        val o=load(); val p=o.optJSONObject("profiles")
        (o.optInt("total_results",0)) to (p?.length()?:0)
    }
}
