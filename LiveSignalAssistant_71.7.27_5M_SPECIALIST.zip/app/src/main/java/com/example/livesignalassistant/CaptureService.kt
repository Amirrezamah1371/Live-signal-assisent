package com.example.livesignalassistant

import android.app.*
import android.content.*
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.hardware.display.*
import android.media.ImageReader
import android.media.projection.*
import android.os.*
import android.provider.Settings
import android.view.*
import android.widget.*
import androidx.core.app.NotificationCompat
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean
import java.util.UUID
import kotlin.math.*

class CaptureService:Service(){
 companion object{const val EXTRA_RESULT_CODE="result_code";const val EXTRA_RESULT_DATA="result_data";const val ACTION_EXPORT="lsa.export";private const val CHANNEL="lsa_v70";private const val NID=1700;private const val CYCLE_MS=360000L;private const val FINAL_MS=60000L;private const val EXPIRY_S=300}
 private data class Obs(val t:Long,val r:SignalResult)
 private data class Pt(val t:Long,val p:Double)
 private var projection:MediaProjection?=null;private var reader:ImageReader?=null;private var display:VirtualDisplay?=null
 private var wm:WindowManager?=null;private var brain:TextView?=null;private val bubbles=mutableListOf<View>();private val main=Handler(Looper.getMainLooper());private val worker=Executors.newSingleThreadExecutor();private val evidenceWorker=Executors.newSingleThreadExecutor();private val busy=AtomicBoolean(false)
 private lateinit var memory:MemoryStore;private lateinit var experience:ExperienceStore;private var lastFrameAt=0L;private var lastEvidenceAt=0L;private var cycleStart=SystemClock.elapsedRealtime();private var nextDecisionAt=cycleStart+CYCLE_MS;private var nextObservationAt=cycleStart+2000L;private val observations=mutableListOf<Obs>();private var cycle=1
 override fun onCreate(){super.onCreate();memory=MemoryStore(this);experience=ExperienceStore(this);channel();startForeground(NID,NotificationCompat.Builder(this,CHANNEL).setContentTitle("71/7/27 · 5M Specialist").setContentText("6m context · 1m final brain · 5m expiry").setSmallIcon(android.R.drawable.ic_menu_view).setOngoing(true).build());memory.event("SESSION_START",mapOf("mode" to "5M_SPECIALIST","cycle_ms" to CYCLE_MS,"expiry_s" to EXPIRY_S))}
 override fun onStartCommand(i:Intent?,f:Int,id:Int):Int{
  if(i?.action==ACTION_EXPORT){val p=memory.exportZip();Toast.makeText(this,"Memory exported: $p",Toast.LENGTH_LONG).show();return START_NOT_STICKY}
  if(!Settings.canDrawOverlays(this)){stopSelf();return START_NOT_STICKY};showBrain();val code=i?.getIntExtra(EXTRA_RESULT_CODE,Activity.RESULT_CANCELED)?:Activity.RESULT_CANCELED;val data:Intent?=if(Build.VERSION.SDK_INT>=33)i?.getParcelableExtra(EXTRA_RESULT_DATA,Intent::class.java) else @Suppress("DEPRECATION") i?.getParcelableExtra(EXTRA_RESULT_DATA)
  if(code!=Activity.RESULT_OK||data==null){stopSelf();return START_NOT_STICKY};if(projection!=null)return START_NOT_STICKY;val mgr=getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager;projection=mgr.getMediaProjection(code,data);projection?.registerCallback(object:MediaProjection.Callback(){override fun onStop(){stopSelf()}},main);startCapture();return START_NOT_STICKY
 }
 private fun glass(stroke:Int=0x55FFFFFF)=GradientDrawable().apply{setColor(0xB8FFFFFF.toInt());cornerRadius=42f;setStroke(2,stroke)}
 private fun showBrain(){main.post{if(brain!=null)return@post;wm=getSystemService(WINDOW_SERVICE) as WindowManager;val v=TextView(this).apply{text="71/7/27 · 5M SPECIALIST\ncontext 6:00";textSize=13f;setTextColor(Color.BLACK);gravity=Gravity.CENTER;setPadding(18,12,18,12);background=glass();elevation=16f};val lp=params(Gravity.TOP or Gravity.END,18,190);wm!!.addView(v,lp);brain=v}}
 private fun params(g:Int,x:Int,y:Int)=WindowManager.LayoutParams(WindowManager.LayoutParams.WRAP_CONTENT,WindowManager.LayoutParams.WRAP_CONTENT,if(Build.VERSION.SDK_INT>=26)WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,PixelFormat.TRANSLUCENT).apply{gravity=g;this.x=x;this.y=y}
 private fun startCapture(){val m=resources.displayMetrics;reader=ImageReader.newInstance(m.widthPixels,m.heightPixels,PixelFormat.RGBA_8888,2);display=projection?.createVirtualDisplay("LSA5M",m.widthPixels,m.heightPixels,m.densityDpi,DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,reader!!.surface,null,main);reader?.setOnImageAvailableListener({r->val now=SystemClock.elapsedRealtime();val im=r.acquireLatestImage()?:return@setOnImageAvailableListener;if(now-lastFrameAt<250||busy.get()){im.close();return@setOnImageAvailableListener};lastFrameAt=now;busy.set(true);try{val p=im.planes[0];val pad=p.rowStride-p.pixelStride*im.width;val tmp=Bitmap.createBitmap(im.width+pad/p.pixelStride,im.height,Bitmap.Config.ARGB_8888);tmp.copyPixelsFromBuffer(p.buffer);val b=Bitmap.createBitmap(tmp,0,0,im.width,im.height);tmp.recycle();worker.execute{try{processFrame(b,now)}finally{b.recycle();busy.set(false)}}}catch(_:Throwable){busy.set(false)}finally{im.close()}},main)}
 private fun recordFrameAsync(b:Bitmap,tag:String){val copy=b.copy(Bitmap.Config.ARGB_8888,false);evidenceWorker.execute{try{memory.frame(copy,tag)}catch(t:Throwable){memory.event("RECORDER_ERROR",mapOf("message" to (t.message?:t.javaClass.simpleName)))}finally{copy.recycle()}}}
 private fun processFrame(b:Bitmap,now:Long){
  if(now-lastEvidenceAt>=5000L){recordFrameAsync(b,"observe");lastEvidenceAt=now}
  val elapsed=now-cycleStart
  if(now>=nextObservationAt && now<nextDecisionAt){
   val base=SignalAnalyzer.analyze(b);val r=base.copy(diagnostics=base.diagnostics+mapOf("cycle_elapsed_ms" to elapsed,"observation_mono_ms" to now));synchronized(observations){observations+=Obs(now,r)}
   memory.event("BOT_OBSERVATION",mapOf("cycle" to cycle,"cycle_elapsed_ms" to elapsed,"phase" to if(elapsed<CYCLE_MS-FINAL_MS)"CONTEXT" else "FINAL_BRAIN","direction" to r.direction,"expiry_s" to r.expirySeconds,"entry" to r.entryQuality,"conflict" to r.conflict,"reason" to r.reason,"up" to r.upScore,"down" to r.downScore,"diagnostics" to r.diagnostics))
   do{nextObservationAt+=2000L}while(nextObservationAt<=now)
  }
  val left=max(0,((nextDecisionAt-now+999)/1000).toInt());val phase=if(elapsed<CYCLE_MS-FINAL_MS)"CONTEXT" else "FINAL BRAIN"
  main.post{brain?.text="71.7.27 · 5M · $phase ${left}s\ncycle $cycle"}
  if(now>=nextDecisionAt){
   finishCycle(b,nextDecisionAt);val late=now-nextDecisionAt;cycleStart=nextDecisionAt;nextDecisionAt+=CYCLE_MS
   if(late>=CYCLE_MS){val skipped=late/CYCLE_MS;cycleStart+=skipped*CYCLE_MS;nextDecisionAt=cycleStart+CYCLE_MS;memory.event("STALE_CYCLES_SKIPPED",mapOf("count" to skipped,"late_ms" to late))}
   nextObservationAt=cycleStart+2000L;cycle++;synchronized(observations){observations.clear()};SignalAnalyzer.reset()
  }
 }
 private fun finishCycle(b:Bitmap,boundaryMono:Long){
  val all=synchronized(observations){observations.toList()};val usable=all.filter{it.r.direction=="UP"||it.r.direction=="DOWN"}
  fun num(r:SignalResult,k:String)=((r.diagnostics[k] as? Number)?.toDouble())
  val path=all.mapNotNull{o->num(o.r,"trace_pos")?.let{Pt(o.t,it)}}
  fun slope(sec:Int):Double{if(path.size<2)return 0.0;val q=path.filter{it.t>=path.last().t-sec*1000L};if(q.size<2)return 0.0;val dt=(q.last().t-q.first().t).coerceAtLeast(1)/1000.0;return (q.last().p-q.first().p)/dt}
  val s15=slope(15);val s30=slope(30);val s60=slope(60);val s120=slope(120);val s240=slope(240)
  val recentMomentum=s15*.18+s30*.27+s60*.30+s120*.17+s240*.08
  val structuralMomentum=s60*.25+s120*.35+s240*.40
  val recentSign=when{recentMomentum>.0007->1;recentMomentum<-.0007->-1;else->0};val structuralSign=when{structuralMomentum>.00035->1;structuralMomentum<-.00035->-1;else->0}
  val changeConfirmed=recentSign!=0&&structuralSign!=0&&recentSign!=structuralSign&&abs(recentMomentum)>=abs(structuralMomentum)*1.25&&listOf(s15,s30,s60).count{if(recentSign>0)it>.00045 else it<-.00045}>=2
  fun w(o:Obs):Double{val age=(boundaryMono-o.t).coerceAtLeast(0).toDouble();val recency=exp(-age/150000.0);val q=(o.r.entryQuality.coerceIn(0,100)/100.0);val c=1.0-o.r.conflict.coerceIn(0,100)/130.0;return (.35+.65*recency)*(.55+.30*q+.15*c)}
  val upW=usable.filter{it.r.direction=="UP"}.sumOf{w(it)};val dnW=usable.filter{it.r.direction=="DOWN"}.sumOf{w(it)};val total=upW+dnW;val voteBias=if(total>0)(upW-dnW)/total else 0.0
  var combined=voteBias*.62 + tanh(recentMomentum*260.0)*.23 + tanh(structuralMomentum*420.0)*.15
  if(changeConfirmed)combined=tanh(recentMomentum*360.0)*.70+voteBias*.30
  val deterministic=when{combined>.09->"UP";combined<-.09->"DOWN";else->"WAIT"}
  val finalMinute=usable.filter{it.t>=boundaryMono-60000L};val finalFlips=finalMinute.zipWithNext().count{(a,c)->a.r.direction!=c.r.direction}
  val extractionQuality=if(all.isEmpty())0.0 else all.map{num(it.r,"vision_coverage")?:0.0}.average()
  val timeCoverage=if(all.size<2)0.0 else ((all.last().t-all.first().t).toDouble()/CYCLE_MS).coerceIn(0.0,1.0)
  val avgEntry=if(finalMinute.isEmpty())0.0 else finalMinute.map{it.r.entryQuality.toDouble()}.average()
  val shock=finalMinute.mapNotNull{num(it.r,"vol_expansion")}.maxOrNull()?:1.0
  val unstable=finalFlips>8 || (recentSign!=0&&structuralSign!=0&&recentSign!=structuralSign&&!changeConfirmed)
  val lateImpulse=abs(s15)>abs(s60)*2.6 && abs(s15)>.0020 && !changeConfirmed
  val entry5=(avgEntry - finalFlips*2.2 - if(unstable)18 else 0 - if(lateImpulse)16 else 0 - if(shock>2.2)10 else 0).coerceIn(0.0,100.0)
  val base=deterministic;val recent=if(recentSign>0)"UP" else if(recentSign<0)"DOWN" else "WAIT"
  val expFeatures=mapOf<String,Any?>("slope_30s" to s30,"slope_60s" to s60,"slope_120s" to s120,"counter_magnitude" to if(structuralSign!=0)max(0.0,-structuralSign*recentMomentum) else 0.0,"persistence_decay" to abs(structuralMomentum)-abs(recentMomentum),"trajectory_jerk" to (s15-s30)-(s60-s120),"recent_direction_flips" to finalFlips,"entry_quality_5m" to entry5,"trend_regime" to (usable.lastOrNull()?.r?.diagnostics?.get("trend_regime")?:0.0),"range_regime" to (usable.lastOrNull()?.r?.diagnostics?.get("range_regime")?:0.0))
  val advice=experience.advise(base,recent,base,expFeatures);val side=advice.side
  val chosen=usable.filter{it.r.direction==side};val representative=chosen.takeLast(min(18,chosen.size)).maxByOrNull{it.r.entryQuality*.55-it.r.conflict*.22+it.r.signalQuality*.08}?.r
  val enough=usable.size>=24&&path.size>=24&&timeCoverage>=.70&&extractionQuality>=.30
  val reason=when{!enough->"INSUFFICIENT_PATH";side=="WAIT"->"NO_EDGE";unstable->"REGIME_TRANSITION";lateImpulse->"LATE_IMPULSE";entry5<43->"ENTRY_WEAK";abs(combined)<.12->"EDGE_WEAK";else->"5M_READY"}
  val result=if(reason=="5M_READY"&&representative!=null)representative.copy(direction=side,expirySeconds=EXPIRY_S,confidence=-1,signalQuality=(50+min(45.0,abs(combined)*120.0)+min(5.0,entry5/20.0)).toInt().coerceIn(0,95),diagnostics=representative.diagnostics+expFeatures+mapOf("cycle_mode" to "6M_CONTEXT_1M_FINAL","fixed_horizon_ms" to 300000,"timeframe" to "5m","vote_bias" to voteBias,"combined_edge" to combined,"slope_15s" to s15,"slope_30s" to s30,"slope_60s" to s60,"slope_120s" to s120,"slope_240s" to s240,"change_confirmed" to changeConfirmed,"entry_quality_5m" to entry5,"vision_quality_cycle" to extractionQuality,"time_coverage" to timeCoverage,"experience_applied" to advice.applied,"experience_samples" to advice.samples,"experience_delta" to advice.learnedDelta,"base_side" to base,"final_recent_side" to recent)) else SignalResult("WAIT",EXPIRY_S,-1,entryQuality=entry5.toInt(),reason=reason,diagnostics=expFeatures+mapOf("combined_edge" to combined,"vision_quality_cycle" to extractionQuality,"time_coverage" to timeCoverage,"change_confirmed" to changeConfirmed))
  recordFrameAsync(b,"decision");val actual=SystemClock.elapsedRealtime();memory.event("FIVE_MINUTE_DECISION",mapOf("cycle" to cycle,"cycle_mode" to "6M_CONTEXT_1M_FINAL","timeframe" to "5m","fixed_expiry_ms" to 300000,"scheduled_boundary_mono_ms" to boundaryMono,"actual_decision_mono_ms" to actual,"decision_latency_ms" to (actual-boundaryMono).coerceAtLeast(0),"direction" to result.direction,"expiry_s" to EXPIRY_S,"observations" to all.size,"usable" to usable.size,"combined_edge" to combined,"entry_quality_5m" to entry5,"slope_15s" to s15,"slope_30s" to s30,"slope_60s" to s60,"slope_120s" to s120,"slope_240s" to s240,"change_confirmed" to changeConfirmed,"reason" to result.reason,"diagnostics" to result.diagnostics))
  main.post{brain?.text=if(result.direction=="WAIT")"WAIT · 5M SPECIALIST\n${result.reason}" else "${if(result.direction=="UP")"↑" else "↓"} ${result.direction} · 5m\nREADY";if(result.direction!="WAIT")spawn(result)}
 }
 private fun dp(v:Int)=(v*resources.displayMetrics.density).roundToInt()
 private fun spawn(r:SignalResult){
  val manager=wm?:return;val arrow=if(r.direction=="UP")"↑" else "↓";val signalId=UUID.randomUUID().toString();val scoreText=if(r.signalQuality>0)"STRENGTH ${r.signalQuality}" else "STRENGTH --"
  val v=TextView(this).apply{text="$arrow ${r.direction} · 5m · $scoreText\nOPEN";textSize=11f;setTextColor(Color.BLACK);gravity=Gravity.CENTER;setPadding(dp(8),dp(5),dp(8),dp(5));background=glass();elevation=18f}
  val lp=params(Gravity.TOP or Gravity.START,dp(4),dp(120)+bubbles.size*dp(52));manager.addView(v,lp);bubbles+=v;restack();memory.event("SIGNAL_PUBLISHED",mapOf("signal_id" to signalId,"direction" to r.direction,"expiry_s" to EXPIRY_S,"confidence_state" to "UNCALIBRATED_STRENGTH","decision_strength" to r.signalQuality,"auto_expire_s" to 20,"diagnostics" to r.diagnostics));var locked=false
  val expire=Runnable{if(!locked){memory.event("SIGNAL_NOT_EXECUTED_TIMEOUT",mapOf("signal_id" to signalId,"direction" to r.direction,"expiry_s" to EXPIRY_S,"visible_for_s" to 20));try{manager.removeView(v)}catch(_:Throwable){};bubbles.remove(v);restack()}};main.postDelayed(expire,20000L)
  v.setOnClickListener{if(locked)return@setOnClickListener;locked=true;main.removeCallbacks(expire);val startedNs=SystemClock.elapsedRealtimeNanos();val targetNs=startedNs+300_000_000_000L;memory.event("TRADE_USER_OPENED",mapOf("signal_id" to signalId,"direction" to r.direction,"expiry_s" to EXPIRY_S,"entry_mono_ns" to startedNs,"target_mono_ns" to targetNs,"decision_strength" to r.signalQuality));fun tick(){val nowNs=SystemClock.elapsedRealtimeNanos();val remainNs=(targetNs-nowNs).coerceAtLeast(0L);if(remainNs>0){val cs=remainNs/10_000_000L;val sec=cs/100;val hundredths=cs%100;v.text="$arrow ${r.direction} · $scoreText\nLOCKED · ${sec}.${hundredths.toString().padStart(2,'0')}s";main.postDelayed({tick()},20)}else{memory.event("EXPIRY_CLOCK",mapOf("signal_id" to signalId,"target_mono_ns" to targetNs,"actual_mono_ns" to nowNs,"timer_error_ns" to (nowNs-targetNs).coerceAtLeast(0L)));showResultButtons(v,r,signalId)}};tick()}
 }
 private fun showResultButtons(old:TextView,r:SignalResult,signalId:String){val manager=wm?:return;val lp=old.layoutParams as WindowManager.LayoutParams;try{manager.removeView(old)}catch(_:Throwable){};bubbles.remove(old);val row=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;background=glass();setPadding(8,6,8,6)};fun btn(t:String){row.addView(Button(this).apply{text=t;textSize=10f;setOnClickListener{memory.event("TRADE_RESULT",mapOf("signal_id" to signalId,"result" to t,"direction" to r.direction,"expiry_s" to EXPIRY_S,"decision_strength" to r.signalQuality,"diagnostics" to r.diagnostics));if(t=="WIN"||t=="LOSS"){val base=(r.diagnostics["base_side"] as? String)?:"WAIT";val recent=(r.diagnostics["final_recent_side"] as? String)?:"WAIT";experience.learn(base,recent,r.direction,t,r.diagnostics);val st=experience.stats();memory.event("EXPERIENCE_5M_LEARNED",mapOf("signal_id" to signalId,"result" to t,"lifetime_results" to st.first,"profiles" to st.second))};try{manager.removeView(row)}catch(_:Throwable){};bubbles.remove(row);restack()}})};btn("WIN");btn("LOSS");btn("VOID");manager.addView(row,lp);bubbles+=row;restack();memory.event("RESULT_REQUESTED",mapOf("signal_id" to signalId,"direction" to r.direction,"expiry_s" to EXPIRY_S))}
 private fun restack(){bubbles.forEachIndexed{i,v->try{val lp=v.layoutParams as WindowManager.LayoutParams;lp.y=dp(120)+i*dp(52);wm?.updateViewLayout(v,lp)}catch(_:Throwable){}}}
 private fun channel(){if(Build.VERSION.SDK_INT>=26)getSystemService(NotificationManager::class.java).createNotificationChannel(NotificationChannel(CHANNEL,"Live Signal 5M Specialist",NotificationManager.IMPORTANCE_LOW))}
 override fun onDestroy(){memory.event("SESSION_STOP");reader?.setOnImageAvailableListener(null,null);display?.release();reader?.close();try{projection?.stop()}catch(_:Throwable){};worker.shutdownNow();evidenceWorker.shutdown();main.post{try{brain?.let{wm?.removeView(it)}}catch(_:Throwable){};bubbles.toList().forEach{try{wm?.removeView(it)}catch(_:Throwable){}}};super.onDestroy()}
 override fun onBind(i:Intent?):IBinder?=null
}
