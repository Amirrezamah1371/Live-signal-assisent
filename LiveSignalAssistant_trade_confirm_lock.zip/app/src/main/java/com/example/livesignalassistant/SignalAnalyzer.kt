package com.example.livesignalassistant

import android.graphics.Bitmap
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

data class SignalResult(val direction: String, val timeframeMinutes: Int, val confidence: Int)

object SignalAnalyzer {
    private const val MIN_SIGNAL_CONFIDENCE = 80
    private val setupVotes = ArrayDeque<Int>()
    private var previousRightY: Double? = null

    @Synchronized
    fun reset() {
        setupVotes.clear()
        previousRightY = null
    }

    @Synchronized
    fun analyze(bitmap: Bitmap): SignalResult {
        val w = bitmap.width; val h = bitmap.height
        if (w < 240 || h < 360) return waitResult(true)

        // Extract the visible price path/candle centres from the live chart area.
        val x0=(w*.57).toInt(); val x1=(w*.958).toInt()
        val y0=(h*.16).toInt(); val y1=(h*.78).toInt()
        val stepX=max(2,(x1-x0)/150)
        val ys=ArrayList<Double>()
        var x=x0
        while(x<x1){
            val hits=ArrayList<Int>(); var y=y0
            while(y<y1){
                val c=bitmap.getPixel(x,y)
                val r=(c shr 16) and 255; val g=(c shr 8) and 255; val b=c and 255
                val hi=max(r,max(g,b)); val lo=min(r,min(g,b))
                if(hi>=112 && hi-lo>=42) hits.add(y)
                y+=2
            }
            if(hits.size>=2){ hits.sort(); ys.add(hits[hits.size/2].toDouble()) }
            x+=stepX
        }
        if(ys.size<36) return waitResult(true)

        // Convert screen Y to a price-like series: rising price = positive movement.
        val p=ys.map{-it}
        val n=p.size
        val noise=median(p.zipWithNext{a,b->abs(b-a)}).coerceAtLeast(1.0)
        val moveFloor=max(h*.0028,noise*1.05)

        fun blockMove(fromFrac:Double,toFrac:Double):Double{
            val a=(n*fromFrac).toInt().coerceIn(0,n-1)
            val b=(n*toFrac).toInt().coerceIn(a+1,n)
            val q=max(2,(b-a)/4)
            return median(p.subList(max(a,b-q),b))-median(p.subList(a,min(b,a+q)))
        }

        // Three different horizons. Background trend is context only; it can never emit a signal.
        val background=blockMove(.08,.62)
        val pullback=blockMove(.58,.84)
        val trigger=blockMove(.82,1.00)
        val right=median(p.takeLast(max(4,n/14)))
        val frameMove=previousRightY?.let{right-it} ?: 0.0
        previousRightY=right

        val hist=p.subList(0,max(8,(n*.82).toInt()))
        val support=percentile(hist,.12)       // low-price area
        val resistance=percentile(hist,.88)   // high-price area
        val range=(resistance-support).coerceAtLeast(moveFloor*3)
        val nearSupport=((right-support)/range).coerceIn(-1.0,2.0) <= .18
        val nearResistance=((resistance-right)/range).coerceIn(-1.0,2.0) <= .18

        val bgDir=dir(background,moveFloor*1.15)
        val pbDir=dir(pullback,moveFloor*.72)
        val trDir=dir(trigger,moveFloor*.55)
        val frameDir=dir(frameMove,moveFloor*.28)

        // IMPORTANT: no setup event = WAIT. A trend by itself is never a setup.
        // Accepted setups:
        // 1) pullback + resumption, 2) rejection/reversal at a local level, 3) fresh breakout.
        var candidate=0
        var setupQuality=0.0

        val continuationUp = bgDir==1 && pbDir==-1 && trDir==1
        val continuationDown = bgDir==-1 && pbDir==1 && trDir==-1
        val reversalUp = nearSupport && trDir==1 && (pbDir==-1 || frameDir==1)
        val reversalDown = nearResistance && trDir==-1 && (pbDir==1 || frameDir==-1)
        val breakoutUp = right > resistance + moveFloor*.45 && trDir==1 && frameDir==1
        val breakoutDown = right < support - moveFloor*.45 && trDir==-1 && frameDir==-1

        when {
            continuationUp -> { candidate=1; setupQuality=2.4 }
            continuationDown -> { candidate=-1; setupQuality=2.4 }
            reversalUp -> { candidate=1; setupQuality=2.15 }
            reversalDown -> { candidate=-1; setupQuality=2.15 }
            breakoutUp -> { candidate=1; setupQuality=2.0 }
            breakoutDown -> { candidate=-1; setupQuality=2.0 }
            else -> return waitResult(false)
        }

        // The newest movement must confirm the entry; otherwise WAIT.
        if(frameDir!=0 && frameDir!=candidate) return waitResult(false)
        if(trDir!=candidate) return waitResult(false)

        // Require the same entry setup to survive several independent screen captures.
        setupVotes.addLast(candidate); while(setupVotes.size>5) setupVotes.removeFirst()
        if(setupVotes.count{it==candidate}<3) return waitResult(false)

        val triggerStrength=(abs(trigger)/(moveFloor*2.2)).coerceIn(0.0,1.0)
        val frameStrength=(abs(frameMove)/(moveFloor*1.5)).coerceIn(0.0,1.0)
        val levelBonus=when(candidate){1->if(nearSupport)1.0 else 0.0;else->if(nearResistance)1.0 else 0.0}
        val confidence=(58 + setupQuality*6 + triggerStrength*12 + frameStrength*7 + levelBonus*5)
            .toInt().coerceIn(0,95)
        if(confidence<MIN_SIGNAL_CONFIDENCE) return waitResult(false,confidence)

        // Expiry is chosen once from setup speed, then CaptureService locks it.
        val tf=when {
            triggerStrength>=.82 && frameStrength>=.55 -> 1
            triggerStrength>=.58 -> 2
            else -> 3
        }
        return SignalResult(if(candidate>0) "UP" else "DOWN",tf,confidence)
    }

    private fun dir(v:Double,t:Double)=when{v>t->1;v< -t->-1;else->0}
    private fun median(v:List<Double>):Double{if(v.isEmpty())return 0.0;val s=v.sorted();return if(s.size%2==1)s[s.size/2] else (s[s.size/2-1]+s[s.size/2])/2.0}
    private fun percentile(v:List<Double>,q:Double):Double{if(v.isEmpty())return 0.0;val s=v.sorted();return s[((s.size-1)*q).toInt().coerceIn(0,s.size-1)]}
    private fun waitResult(clear:Boolean=false,conf:Int=0):SignalResult{
        if(clear) reset()
        return SignalResult("WAIT",0,conf.coerceIn(0,95))
    }
}
