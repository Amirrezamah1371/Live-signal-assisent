package com.example.livesignalassistant

import android.graphics.Bitmap
import kotlin.math.abs

/**
 * Pixel-only confirmation that the Pocket Option UI changed into an "open trade" state.
 * MediaProjection cannot read semantic UI state, so this deliberately requires a
 * persistent change in non-chart control/status regions instead of treating a tap or
 * candle movement as confirmation.
 */
object TradeOpenDetector {
    private var baseline: IntArray? = null
    private var baselineAt = 0L
    private var changedFrames = 0

    @Synchronized fun arm(bitmap: Bitmap) {
        baseline = fingerprint(bitmap)
        baselineAt = System.currentTimeMillis()
        changedFrames = 0
    }

    @Synchronized fun cancel() {
        baseline = null
        baselineAt = 0L
        changedFrames = 0
    }

    @Synchronized fun isTradeOpen(bitmap: Bitmap): Boolean {
        val base = baseline ?: return false
        val now = System.currentTimeMillis()
        if (now - baselineAt < 1100L) return false // ignore the actual tap/button animation
        val cur = fingerprint(bitmap)
        if (cur.size != base.size || cur.isEmpty()) return false
        var changed = 0
        for (i in cur.indices) {
            val a = base[i]; val b = cur[i]
            val ar=(a shr 16) and 255; val ag=(a shr 8) and 255; val ab=a and 255
            val br=(b shr 16) and 255; val bg=(b shr 8) and 255; val bb=b and 255
            if (abs(ar-br)+abs(ag-bg)+abs(ab-bb) > 105) changed++
        }
        val ratio = changed.toDouble()/cur.size
        // Persistent UI change, not one transient frame.
        if (ratio >= .115) changedFrames++ else changedFrames = 0
        return changedFrames >= 3
    }

    private fun fingerprint(b: Bitmap): IntArray {
        val w=b.width; val h=b.height
        val out=ArrayList<Int>(180)
        fun sample(x0:Double,y0:Double,x1:Double,y1:Double,cols:Int,rows:Int){
            for (ry in 0 until rows) for (cx in 0 until cols) {
                val x=((x0+(x1-x0)*(cx+.5)/cols)*w).toInt().coerceIn(0,w-1)
                val y=((y0+(y1-y0)*(ry+.5)/rows)*h).toInt().coerceIn(0,h-1)
                out.add(b.getPixel(x,y))
            }
        }
        // Right-side trading controls/status + lower status/order area. Avoid the main chart.
        sample(.82,.10,.985,.94,6,14)
        sample(.12,.80,.80,.975,10,5)
        return out.toIntArray()
    }
}
