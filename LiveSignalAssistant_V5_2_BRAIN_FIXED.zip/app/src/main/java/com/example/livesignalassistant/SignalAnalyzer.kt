package com.example.livesignalassistant

import android.graphics.Bitmap
import android.os.SystemClock
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

data class SignalResult(
    val direction:String, val expirySeconds:Int, val confidence:Int,
    val entryQuality:Int=0, val conflict:Int=100, val reason:String="",
    val upScore:Int=0, val downScore:Int=0
)

/** V5.2 BRAIN — horizon-specific evidence engine. Each expiry is judged independently. */
object SignalAnalyzer {
    private data class View(val p:List<Double>, val floor:Double)
    private data class C(val sign:Int,val expiry:Int,val score:Double,val entry:Double,val conflict:Double,val reason:String)
    private var prevRight:Double?=null; private var prevAt=0L
    private val votes=mutableMapOf<Int,ArrayDeque<Int>>()

    @Synchronized fun reset(){ prevRight=null;prevAt=0;votes.clear() }

    @Synchronized fun analyze(b:Bitmap):SignalResult{
        val w=b.width; val h=b.height
        if(w<240||h<360) return wait("LOW VISIBILITY")
        // Chart-only scan: deliberately excludes right controls and bottom trade UI.
        val x0=(w*.055).toInt(); val x1=(w*.79).toInt(); val y0=(h*.12).toInt(); val y1=(h*.79).toInt()
        val step=max(2,(x1-x0)/300); val raw=ArrayList<Double>(); var x=x0
        while(x<x1){ val hits=ArrayList<Int>(); var y=y0
            while(y<y1){ val c=b.getPixel(x,y);val r=(c shr 16)and 255;val g=(c shr 8)and 255;val bl=c and 255;val hi=max(r,max(g,bl));val lo=min(r,min(g,bl));if(hi>=95&&hi-lo>=38)hits+=y;y+=2 }
            if(hits.size>=2){hits.sort();raw+=-hits[hits.size/2].toDouble()};x+=step
        }
        if(raw.size<70) return wait("LOW VISIBILITY")
        val all=smooth(raw,2); val n=all.size
        // Four logical eyes from distinct horizontal history windows.
        val wide=mk(all.subList(0,n),h)
        val structure=mk(all.subList((n*.28).toInt(),n),h)
        val entry=mk(all.subList((n*.62).toInt(),n),h)
        val micro=mk(all.subList((n*.82).toInt(),n),h)
        val right=median(micro.p.takeLast(max(3,micro.p.size/7)))
        val now=SystemClock.elapsedRealtime(); val dt=((now-prevAt).coerceAtLeast(1))/1000.0
        val frame=prevRight?.let{(right-it)/dt}?:0.0;prevRight=right;prevAt=now
        val expiries=intArrayOf(30,60,120,180,300,600,900)
        val cs=ArrayList<C>()
        for(e in expiries){cs+=candidate(1,e,wide,structure,entry,micro,frame);cs+=candidate(-1,e,wide,structure,entry,micro,frame)}
        val best=cs.maxByOrNull{it.score}!!
        val sameExpiryOpp=cs.first{it.expiry==best.expiry&&it.sign==-best.sign}
        val margin=best.score-sameExpiryOpp.score
        val up=cs.filter{it.sign>0}.maxOf{it.score}.toInt(); val down=cs.filter{it.sign<0}.maxOf{it.score}.toInt()
        // Opportunity-forward: WAIT still requires a concrete reason, but dangerous conflict remains a veto.
        if(best.score<58 || best.entry<38 || best.conflict>67 || margin<3.0)
            return SignalResult("WAIT",0,best.score.toInt(),best.entry.toInt(),best.conflict.toInt(),best.reason,up,down)
        val q=votes.getOrPut(best.expiry){ArrayDeque()};q.addLast(best.sign);while(q.size>2)q.removeFirst()
        // One-frame confirmation only when evidence is marginal; strong setups can fire immediately.
        if(best.score<69 && q.size==2 && q.count{it==best.sign}<2)
            return SignalResult("WAIT",0,best.score.toInt(),best.entry.toInt(),best.conflict.toInt(),"CONFIRM",up,down)
        return SignalResult(if(best.sign>0)"UP" else "DOWN",best.expiry,best.score.toInt(),best.entry.toInt(),best.conflict.toInt(),best.reason,up,down)
    }

    private fun mk(p:List<Double>,h:Int):View{val d=p.zipWithNext{a,c->abs(c-a)};return View(p, max(h*.0017,median(d).coerceAtLeast(1.0)*.90))}
    private fun candidate(sign:Int,e:Int,w:View,s:View,en:View,m:View,frame:Double):C{
        fun mv(v:View,a:Double,b:Double):Double{val n=v.p.size;val i=(n*a).toInt().coerceIn(0,n-2);val j=(n*b).toInt().coerceIn(i+2,n);val q=max(2,(j-i)/4);return median(v.p.subList(j-q,j))-median(v.p.subList(i,i+q))}
        fun al(v:Double,f:Double,k:Double)=((sign*v)/(f*k)).coerceIn(-1.0,1.0)
        val wa=al(mv(w,.05,.95),w.floor,3.4);val sa=al(mv(s,.20,.98),s.floor,2.6);val ea=al(mv(en,.35,1.0),en.floor,1.7);val ma=al(mv(m,.42,1.0),m.floor,1.0);val fa=al(frame,m.floor,1.1)
        val hist=s.p.dropLast(max(2,s.p.size/12));val sup=percentile(hist,.10);val res=percentile(hist,.90);val r=median(m.p.takeLast(max(3,m.p.size/6)));val span=(res-sup).coerceAtLeast(s.floor*4);val pos=((r-sup)/span).coerceIn(-.5,1.5)
        val level=if(sign>0)((.48-pos)/.48).coerceIn(0.0,1.0) else ((pos-.52)/.48).coerceIn(0.0,1.0)
        val breakout=if(sign>0)((r-res)/(s.floor*1.4)).coerceIn(0.0,1.0) else ((sup-r)/(s.floor*1.4)).coerceIn(0.0,1.0)
        val ds=m.p.zipWithNext{a,c->c-a};var flips=0;var last=0;for(d in ds){val z=if(d>m.floor*.1)1 else if(d< -m.floor*.1)-1 else 0;if(z!=0){if(last!=0&&z!=last)flips++;last=z}}
        val chop=flips.toDouble()/max(1,ds.size-1)
        val microPos=max(0.0,ma);val entryPos=max(0.0,ea);val structPos=max(0.0,sa);val widePos=max(0.0,wa);val framePos=max(0.0,fa)
        val weights=when(e){30->doubleArrayOf(.08,.12,.30,.38,.12);60->doubleArrayOf(.10,.17,.31,.31,.11);120,180->doubleArrayOf(.16,.29,.31,.17,.07);300->doubleArrayOf(.23,.34,.27,.11,.05);else->doubleArrayOf(.34,.38,.20,.06,.02)}
        val directional=widePos*weights[0]+structPos*weights[1]+entryPos*weights[2]+microPos*weights[3]+framePos*weights[4]
        val opposite=max(0.0,-ma)*.34+max(0.0,-ea)*.29+max(0.0,-sa)*.23+max(0.0,-wa)*.14
        val reversal=(level*max(0.0,-sa)*(microPos+entryPos)/2).coerceIn(0.0,1.0)
        val continuation=(widePos*structPos*entryPos).coerceIn(0.0,1.0)
        val entryQ=(42+34*microPos+22*entryPos+12*level+10*breakout-18*chop).coerceIn(0.0,100.0)
        val conflict=(100*(opposite*.72+chop*.28)).coerceIn(0.0,100.0)
        val score=(38+directional*48+reversal*8+continuation*7+breakout*5+entryQ*.10-conflict*.16).coerceIn(0.0,96.0)
        val reason=when{reversal>.45->"REV";breakout>.45->"BRK";continuation>.38->"CONT";else->"MOM"}
        return C(sign,e,score,entryQ,conflict,reason)
    }
    private fun smooth(v:List<Double>,r:Int)=v.indices.map{i->median(v.subList(max(0,i-r),min(v.size,i+r+1)))}
    private fun median(v:List<Double>):Double{if(v.isEmpty())return 0.0;val s=v.sorted();return if(s.size%2==1)s[s.size/2] else (s[s.size/2-1]+s[s.size/2])/2}
    private fun percentile(v:List<Double>,q:Double):Double{val s=v.sorted();return s[((s.size-1)*q).toInt().coerceIn(0,s.size-1)]}
    private fun wait(r:String)=SignalResult("WAIT",0,0,0,100,r,0,0)
}
