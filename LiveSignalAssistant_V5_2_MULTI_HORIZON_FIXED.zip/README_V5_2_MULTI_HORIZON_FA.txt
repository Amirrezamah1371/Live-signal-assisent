Live Signal Assistant V5.2 Multi-Horizon

Changes from V5.1:
- Four distinct chart analysis regions: Wide, Structure, Entry, Micro.
- Independent UP/DOWN competition for every expiry: 30s, 1m, 2m, 3m, 5m, 10m, 15m.
- Short expiries weight Micro/Entry more; long expiries weight Structure/Wide more.
- Removed global trade lock: an open 15m trade no longer freezes new 30s/1m/2m/etc opportunities.
- Only rapid duplicate direction+expiry signals are suppressed; other horizons continue scanning.
- Opportunity-first thresholds replace the old stacked 64/44/60 + 2-of-3 choke point.
- Symmetric UP/DOWN evidence and conflict scoring.
- 5-second display hold does not freeze analysis.
- Separate applicationId: com.example.livesignalassistant.v52multi

Demo testing only until enough samples are collected. No automatic trade execution.
