package com.example.livesignalassistant

import android.graphics.Bitmap
import android.os.SystemClock
import java.util.Calendar
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

data class SignalResult(
    val direction: String,
    val expirySeconds: Int,
    val confidence: Int,
    val entryQuality: Int = 0,
    val conflict: Int = 100,
    val reason: String = ""
)

/** V5.2: independent visual regions + independent horizon decisions. */
object SignalAnalyzer {
    private data class Features(
        val broad:Double, val swing:Double, val fast:Double, val micro:Double,
        val noise:Double, val pos:Double, val chop:Double, val accel:Double,
        val velocity:Double, val volatility:Double, val right:Double
    )
    private data class Candidate(val sign:Int,val expiry:Int,val score:Double,val entry:Double,val conflict:Double,val reason:String)
    private data class Memory(var sign:Int=0,var strength:Double=0.0,var votes:ArrayDeque<Int> = ArrayDeque())

    private val memories = mutableMapOf<Int,Memory>()
    private val previousRight = mutableMapOf<String,Pair<Double,Long>>()

    @Synchronized fun reset(){ memories.clear(); previousRight.clear() }

    @Synchronized fun analyze(bitmap: Bitmap): SignalResult {
        if(bitmap.width < 240 || bitmap.height < 360) return SignalResult("WAIT",0,0,0,100,"LOW VISIBILITY")

        // Four genuinely different horizontal chart views. All exclude broker controls on the far right.
        val wide = features(bitmap, .055, .79, "wide") ?: return SignalResult("WAIT",0,0,0,100,"LOW VISIBILITY")
        val structure = features(bitmap, .25, .79, "structure") ?: wide
        val entry = features(bitmap, .49, .79, "entry") ?: structure
        val micro = features(bitmap, .64, .79, "micro") ?: entry

        val expiries = intArrayOf(30,60,120,180,300,600,900)
        val candidates = ArrayList<Candidate>()
        for(e in expiries){
            candidates += candidate(1,e,wide,structure,entry,micro)
            candidates += candidate(-1,e,wide,structure,entry,micro)
        }

        // Each expiry first competes UP vs DOWN independently; only then do horizons compete.
        val horizonWinners = expiries.map { e ->
            val pair = candidates.filter { it.expiry == e }
            val up = pair.first { it.sign > 0 }; val down = pair.first { it.sign < 0 }
            val best = if(up.score >= down.score) up else down
            val other = if(best.sign > 0) down else up
            Triple(best, other, best.score-other.score)
        }

        val qualified = horizonWinners.mapNotNull { (raw,other,margin) ->
            val mem = memories.getOrPut(raw.expiry){ Memory() }
            if(raw.score >= 55 && raw.entry >= 38 && raw.conflict <= 67){
                if(mem.sign == raw.sign) mem.strength = mem.strength*.55 + raw.score*.45
                else { mem.sign=raw.sign; mem.strength=raw.score; mem.votes.clear() }
            } else if(raw.conflict > 78 || other.score > raw.score+10){ mem.sign=0; mem.strength=0.0; mem.votes.clear() }
            val effective = if(mem.sign==raw.sign) max(raw.score,mem.strength-4) else raw.score
            mem.votes.addLast(raw.sign); while(mem.votes.size>2) mem.votes.removeFirst()
            val stable = mem.votes.count{it==raw.sign} >= 1 // opportunity-first: no 2-of-3 global choke point
            if(effective >= 57 && raw.entry >= 39 && raw.conflict <= 68 && margin >= 1.5 && stable)
                raw.copy(score=effective)
            else null
        }

        if(qualified.isEmpty()){
            val best = horizonWinners.maxByOrNull { it.first.score }?.first
            return if(best==null) SignalResult("WAIT",0,0,0,100,"NO SETUP")
            else SignalResult("WAIT",0,best.score.toInt(),best.entry.toInt(),best.conflict.toInt(),best.reason)
        }

        // Prefer quality, but give short-lived opportunities a small freshness bonus instead of always picking 15m.
        val best = qualified.maxBy { it.score + it.entry*.10 - it.conflict*.06 + if(it.expiry<=60) 2.0 else 0.0 }
        return SignalResult(if(best.sign>0)"UP" else "DOWN",best.expiry,best.score.toInt(),best.entry.toInt(),best.conflict.toInt(),best.reason)
    }

    private fun candidate(sign:Int,e:Int,w:Features,s:Features,en:Features,m:Features):Candidate{
        fun align(v:Double,floor:Double,scale:Double)=((sign*v)/(floor*scale)).coerceIn(-1.0,1.0)
        fun evidence(f:Features):Double {
            val a=align(f.fast,f.noise,1.4); val b=align(f.micro,f.noise,.9); val c=align(f.swing,f.noise,2.0)
            return (max(0.0,a)*.38+max(0.0,b)*.38+max(0.0,c)*.24).coerceIn(0.0,1.0)
        }
        fun opposition(f:Features):Double {
            val a=align(f.fast,f.noise,1.3); val b=align(f.micro,f.noise,.85); val c=align(f.swing,f.noise,1.9)
            return (max(0.0,-a)*.40+max(0.0,-b)*.40+max(0.0,-c)*.20).coerceIn(0.0,1.0)
        }
        val ew=evidence(w); val es=evidence(s); val ee=evidence(en); val em=evidence(m)
        val ow=opposition(w); val os=opposition(s); val oe=opposition(en); val om=opposition(m)
        val h=e/900.0
        val directional = when {
            e<=60 -> em*.43 + ee*.34 + es*.17 + ew*.06
            e<=300 -> em*.16 + ee*.36 + es*.34 + ew*.14
            else -> em*.07 + ee*.18 + es*.39 + ew*.36
        }
        val opposite = when {
            e<=60 -> om*.45 + oe*.33 + os*.16 + ow*.06
            e<=300 -> om*.17 + oe*.35 + os*.34 + ow*.14
            else -> om*.07 + oe*.18 + os*.40 + ow*.35
        }
        val accel = (max(0.0,sign*m.accel/(m.noise*.55))*0.55 + max(0.0,sign*en.accel/(en.noise*.65))*0.45).coerceIn(0.0,1.0)
        val levelSupport = if(sign>0) ((.48-s.pos)/.48).coerceIn(0.0,1.0) else ((s.pos-.52)/.48).coerceIn(0.0,1.0)
        val exhaustionPenalty = if(sign>0 && s.pos>.88 || sign<0 && s.pos<.12) .16 else 0.0
        val chop = (m.chop*.45+en.chop*.35+s.chop*.20).coerceIn(0.0,1.0)
        val entry = (100*(em*.40+ee*.27+accel*.17+levelSupport*.10+(1-chop)*.06)-exhaustionPenalty*35).coerceIn(0.0,100.0)
        val conflict = (100*(opposite*.67+chop*.23+if(m.volatility>2.6).10 else 0.0)).coerceIn(0.0,100.0)
        val score=(35+directional*49+entry*.15-conflict*.16+MarketContextEngine.modifier(e)-exhaustionPenalty*18).coerceIn(0.0,96.0)
        val reason=when{
            levelSupport>.65 && em>.45 -> "REVERSAL"
            ew>.55 && es>.55 && ee>.45 -> "STRUCTURE"
            em>.60 && ee>.50 -> "MOMENTUM"
            else -> "SETUP"
        }
        return Candidate(sign,e,score,entry,conflict,reason)
    }

    private fun features(bitmap:Bitmap,xStart:Double,xEnd:Double,key:String):Features?{
        val w=bitmap.width; val h=bitmap.height
        val x0=(w*xStart).toInt(); val x1=(w*xEnd).toInt(); val y0=(h*.12).toInt(); val y1=(h*.79).toInt()
        val step=max(1,(x1-x0)/180); val raw=ArrayList<Double>(); var x=x0
        while(x<x1){
            val hits=ArrayList<Int>(); var y=y0
            while(y<y1){
                val c=bitmap.getPixel(x,y); val r=(c shr 16)and 255; val g=(c shr 8)and 255; val b=c and 255
                val hi=max(r,max(g,b)); val lo=min(r,min(g,b))
                if(hi>=95 && hi-lo>=38) hits.add(y)
                y+=2
            }
            if(hits.size>=2){hits.sort();raw.add(-hits[hits.size/2].toDouble())}; x+=step
        }
        if(raw.size<18) return null
        val p=smooth(raw, if(raw.size>70)2 else 1); val n=p.size
        val deltas=p.zipWithNext{a,b->abs(b-a)}; val floor=max(h*.0018,median(deltas).coerceAtLeast(1.0))
        fun move(a:Double,b:Double):Double{val i=(n*a).toInt().coerceIn(0,n-2);val j=(n*b).toInt().coerceIn(i+2,n);val q=max(2,(j-i)/4);return median(p.subList(j-q,j))-median(p.subList(i,i+q))}
        val broad=move(.04,.62); val swing=move(.35,.84); val fast=move(.68,1.0); val micro=move(.86,1.0)
        val right=median(p.takeLast(max(3,n/16))); val now=SystemClock.elapsedRealtime(); val prev=previousRight[key]
        val velocity=if(prev==null)0.0 else (right-prev.first)/(((now-prev.second).coerceAtLeast(1))/1000.0); previousRight[key]=right to now
        val recent=p.takeLast(max(8,n/3)).zipWithNext{a,b->b-a}; var flips=0;var last=0
        for(d in recent){val sg=when{d>floor*.10->1;d< -floor*.10->-1;else->0};if(sg!=0){if(last!=0&&sg!=last)flips++;last=sg}}
        val chop=(flips.toDouble()/max(1,recent.size-1)).coerceIn(0.0,1.0)
        val rv=recent.takeLast(max(3,recent.size/4)).average(); val pv=recent.take(max(3,recent.size*3/4)).takeLast(max(3,recent.size/4)).average(); val accel=rv-pv
        val hist=p.take(max(8,(n*.82).toInt())); val support=percentile(hist,.10);val resistance=percentile(hist,.90);val range=(resistance-support).coerceAtLeast(floor*4)
        val pos=((right-support)/range).coerceIn(-.5,1.5); val vol=(median(deltas)/floor).coerceIn(.4,3.2)
        return Features(broad,swing,fast,micro,floor,pos,chop,accel,velocity,vol,right)
    }

    private fun smooth(v:List<Double>,r:Int)=v.indices.map{i->median(v.subList(max(0,i-r),min(v.size,i+r+1)))}
    private fun median(v:List<Double>):Double{if(v.isEmpty())return 0.0;val s=v.sorted();return if(s.size%2==1)s[s.size/2] else (s[s.size/2-1]+s[s.size/2])/2}
    private fun percentile(v:List<Double>,q:Double):Double{val s=v.sorted();return s[((s.size-1)*q).toInt().coerceIn(0,s.size-1)]}
}

object MarketContextEngine{
    fun modifier(expirySeconds:Int):Double{
        val c=Calendar.getInstance(java.util.TimeZone.getTimeZone("UTC"));val h=c.get(Calendar.HOUR_OF_DAY);val m=c.get(Calendar.MINUTE)
        var x=0.0;if(h in 7..16)x+=1.0;if(h==21||h==22)x-=2.0;if((m<2||m>57)&&expirySeconds<=60)x-=1.0;return x
    }
}
