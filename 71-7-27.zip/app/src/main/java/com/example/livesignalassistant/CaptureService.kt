package com.example.livesignalassistant

import android.app.*
import android.content.*
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.hardware.display.*
import android.media.ImageReader
import android.media.projection.*
import android.os.*
import android.provider.Settings
import android.view.*
import android.widget.*
import androidx.core.app.NotificationCompat
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean
import java.util.UUID
import kotlin.math.*

class CaptureService:Service(){
 companion object{const val EXTRA_RESULT_CODE="result_code";const val EXTRA_RESULT_DATA="result_data";const val ACTION_EXPORT="lsa.export";private const val CHANNEL="lsa_v70";private const val NID=1700}
 private var projection:MediaProjection?=null;private var reader:ImageReader?=null;private var display:VirtualDisplay?=null
 private var wm:WindowManager?=null;private var brain:TextView?=null;private val bubbles=mutableListOf<View>();private val main=Handler(Looper.getMainLooper());private val worker=Executors.newSingleThreadExecutor();private val evidenceWorker=Executors.newSingleThreadExecutor();private val busy=AtomicBoolean(false)
 private lateinit var memory:MemoryStore;private var lastFrameAt=0L;private var cycleStart=SystemClock.elapsedRealtime();private var nextDecisionAt=cycleStart+60000L;private var nextObservationAt=cycleStart+3000L;private val observations=mutableListOf<SignalResult>();private var cycle=1
 override fun onCreate(){super.onCreate();memory=MemoryStore(this);channel();startForeground(NID,NotificationCompat.Builder(this,CHANNEL).setContentTitle("71/7/27").setContentText("59s observe · 1 decision · memory recording").setSmallIcon(android.R.drawable.ic_menu_view).setOngoing(true).build());memory.event("SESSION_START")}
 override fun onStartCommand(i:Intent?,f:Int,id:Int):Int{
  if(i?.action==ACTION_EXPORT){val p=memory.exportZip();Toast.makeText(this,"Memory exported: $p",Toast.LENGTH_LONG).show();return START_NOT_STICKY}
  if(!Settings.canDrawOverlays(this)){stopSelf();return START_NOT_STICKY};showBrain();val code=i?.getIntExtra(EXTRA_RESULT_CODE,Activity.RESULT_CANCELED)?:Activity.RESULT_CANCELED;val data:Intent?=if(Build.VERSION.SDK_INT>=33)i?.getParcelableExtra(EXTRA_RESULT_DATA,Intent::class.java) else @Suppress("DEPRECATION") i?.getParcelableExtra(EXTRA_RESULT_DATA)
  if(code!=Activity.RESULT_OK||data==null){stopSelf();return START_NOT_STICKY};if(projection!=null)return START_NOT_STICKY;val mgr=getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager;projection=mgr.getMediaProjection(code,data);projection?.registerCallback(object:MediaProjection.Callback(){override fun onStop(){stopSelf()}},main);startCapture();return START_NOT_STICKY
 }
 private fun glass(stroke:Int=0x55FFFFFF)=GradientDrawable().apply{setColor(0xB8FFFFFF.toInt());cornerRadius=42f;setStroke(2,stroke)}
 private fun showBrain(){main.post{if(brain!=null)return@post;wm=getSystemService(WINDOW_SERVICE) as WindowManager;val v=TextView(this).apply{text="71/7/27\ncycle 1";textSize=13f;setTextColor(Color.BLACK);gravity=Gravity.CENTER;setPadding(18,12,18,12);background=glass();elevation=16f};val lp=params(Gravity.TOP or Gravity.END,18,190);wm!!.addView(v,lp);brain=v}}
 private fun params(g:Int,x:Int,y:Int)=WindowManager.LayoutParams(WindowManager.LayoutParams.WRAP_CONTENT,WindowManager.LayoutParams.WRAP_CONTENT,if(Build.VERSION.SDK_INT>=26)WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,PixelFormat.TRANSLUCENT).apply{gravity=g;this.x=x;this.y=y}
 private fun startCapture(){val m=resources.displayMetrics;reader=ImageReader.newInstance(m.widthPixels,m.heightPixels,PixelFormat.RGBA_8888,2);display=projection?.createVirtualDisplay("LSA70",m.widthPixels,m.heightPixels,m.densityDpi,DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,reader!!.surface,null,main);reader?.setOnImageAvailableListener({r->val now=SystemClock.elapsedRealtime();val im=r.acquireLatestImage()?:return@setOnImageAvailableListener;if(now-lastFrameAt<1000||busy.get()){im.close();return@setOnImageAvailableListener};lastFrameAt=now;busy.set(true);try{val p=im.planes[0];val pad=p.rowStride-p.pixelStride*im.width;val tmp=Bitmap.createBitmap(im.width+pad/p.pixelStride,im.height,Bitmap.Config.ARGB_8888);tmp.copyPixelsFromBuffer(p.buffer);val b=Bitmap.createBitmap(tmp,0,0,im.width,im.height);tmp.recycle();worker.execute{try{processFrame(b,now)}finally{b.recycle();busy.set(false)}}}catch(_:Throwable){busy.set(false)}finally{im.close()}},main)}
 private fun recordFrameAsync(b:Bitmap,tag:String){
  val copy=b.copy(Bitmap.Config.ARGB_8888,false)
  evidenceWorker.execute{try{memory.frame(copy,tag)}catch(t:Throwable){memory.event("RECORDER_ERROR",mapOf("message" to (t.message?:t.javaClass.simpleName)))}finally{copy.recycle()}}
 }
 private fun processFrame(b:Bitmap,now:Long){
  recordFrameAsync(b,"observe")
  val elapsed=now-cycleStart
  // Deterministic observation clock: one observation every 2s after the first 3s.
  // It is independent of frame-arrival modulo arithmetic, so every cycle has comparable sampling.
  if(now>=nextObservationAt && now<nextDecisionAt){
   val r=SignalAnalyzer.analyze(b);synchronized(observations){observations+=r}
   memory.event("BOT_OBSERVATION",mapOf("cycle" to cycle,"cycle_elapsed_ms" to elapsed,"direction" to r.direction,"expiry_s" to r.expirySeconds,"raw_confidence" to r.confidence,"entry" to r.entryQuality,"conflict" to r.conflict,"reason" to r.reason,"up" to r.upScore,"down" to r.downScore,"diagnostics" to r.diagnostics))
   do{nextObservationAt+=2000L}while(nextObservationAt<=now)
  }
  val left=max(0,((nextDecisionAt-now+999)/1000).toInt());main.post{brain?.text="71/7/27 · ANALYZING ${left}s\ncycle $cycle"}
  if(now>=nextDecisionAt){
   finishCycle(b,nextDecisionAt)
   // Anchor cycles to the monotonic schedule, never to a late frame; this prevents cumulative drift.
   cycleStart=nextDecisionAt;nextDecisionAt+=60000L;nextObservationAt=cycleStart+3000L;cycle++
   synchronized(observations){observations.clear()}
  }
 }
 private fun finishCycle(b:Bitmap,boundaryMono:Long){
  val list=synchronized(observations){observations.toList()};val usable=list.filter{it.direction=="UP"||it.direction=="DOWN"}
  // Preserve temporal order: recent evidence is weighted more strongly than stale evidence.
  fun weight(i:Int,n:Int)=0.55+0.45*((i+1).toDouble()/n.coerceAtLeast(1))
  val upWeight=usable.mapIndexed{i,r->if(r.direction=="UP")weight(i,usable.size) else 0.0}.sum()
  val downWeight=usable.mapIndexed{i,r->if(r.direction=="DOWN")weight(i,usable.size) else 0.0}.sum()
  val side=when{upWeight>downWeight*1.12->"UP";downWeight>upWeight*1.12->"DOWN";else->"WAIT"}
  val chosen=usable.filter{it.direction==side};val totalWeight=upWeight+downWeight;val consistency=if(totalWeight==0.0)0.0 else max(upWeight,downWeight)/totalWeight
  val result=if(side!="WAIT"&&chosen.size>=3&&consistency>=.62){
   // TRAJECTORY BRAIN: same proven signal gate; the whole minute now informs expiry.
   val expWeights=linkedMapOf<Int,Double>()
   val expSwitches=chosen.zipWithNext().count{(a,c)->a.expirySeconds!=c.expirySeconds}
   val dirSwitches=usable.zipWithNext().count{(a,c)->a.direction!=c.direction}
   val reasonSwitches=chosen.zipWithNext().count{(a,c)->a.reason!=c.reason}
   chosen.forEachIndexed{i,r->
    val recency=weight(i,chosen.size)
    val quality=0.55+(r.entryQuality.coerceIn(0,100)/100.0)*0.25+((100-r.conflict.coerceIn(0,100))/100.0)*0.20
    expWeights[r.expirySeconds]=(expWeights[r.expirySeconds]?:0.0)+recency*quality
   }
   val expiry=expWeights.maxByOrNull{it.value}!!.key
   val same=chosen.filter{it.expirySeconds==expiry}
   // Quality ranks evidence; it is not a new veto.
   val representative=same.mapIndexed{i,r->Pair(r,i.toDouble()/same.size.coerceAtLeast(1))}
    .maxByOrNull{(r,rec)->rec*.55+r.entryQuality*.003+(100-r.conflict)*.0015}!!.first
   val horizonShare=(expWeights[expiry]?:0.0)/(expWeights.values.sum().coerceAtLeast(.0001))
   representative.copy(confidence=-1,signalQuality=representative.confidence,diagnostics=representative.diagnostics+mapOf(
    "trajectory_expiry_switches" to expSwitches,"trajectory_direction_switches" to dirSwitches,
    "trajectory_reason_switches" to reasonSwitches,"trajectory_horizon_share" to horizonShare,
    "trajectory_consistency" to consistency,"trajectory_usable" to usable.size,"trajectory_chosen" to chosen.size,
    "trajectory_expiry_weights" to expWeights.mapKeys{it.key.toString()}))
  } else SignalResult("WAIT",0,-1,reason=if(usable.isEmpty())"NO_VALID_SETUP" else "MINUTE_INCOHERENT")
  recordFrameAsync(b,"decision")
  memory.event("MINUTE_DECISION",mapOf("cycle" to cycle,"scheduled_boundary_mono_ms" to boundaryMono,"actual_decision_mono_ms" to SystemClock.elapsedRealtime(),"decision_latency_ms" to (SystemClock.elapsedRealtime()-boundaryMono).coerceAtLeast(0),"direction" to result.direction,"expiry_s" to result.expirySeconds,"confidence_state" to "CALIBRATING","observations" to list.size,"usable" to usable.size,"up_weight" to upWeight,"down_weight" to downWeight,"consistency" to consistency,"reason" to result.reason,"diagnostics" to result.diagnostics))
  main.post{brain?.text=if(result.direction=="WAIT")"WAIT · CALIBRATING\ncycle $cycle" else "${if(result.direction=="UP")"↑" else "↓"} ${result.direction} · ${result.expirySeconds/60}m\nCONF: CALIBRATING";if(result.direction!="WAIT")spawn(result)}
 }
 private fun dp(v:Int)=(v*resources.displayMetrics.density).roundToInt()
 private fun spawn(r:SignalResult){
  val manager=wm?:return;val arrow=if(r.direction=="UP")"↑" else "↓";val signalId=UUID.randomUUID().toString()
  val percentText=if(r.signalQuality>0)"${r.signalQuality}%" else "--%"
  val v=TextView(this).apply{text="$arrow ${r.direction} · ${r.expirySeconds/60}m · $percentText\nOPEN";textSize=11f;setTextColor(Color.BLACK);gravity=Gravity.CENTER;setPadding(dp(8),dp(5),dp(8),dp(5));background=glass();elevation=18f}
  val lp=params(Gravity.TOP or Gravity.START,dp(4),dp(120)+bubbles.size*dp(52));manager.addView(v,lp);bubbles+=v;restack()
  memory.event("SIGNAL_PUBLISHED",mapOf("signal_id" to signalId,"direction" to r.direction,"expiry_s" to r.expirySeconds,"confidence_state" to "CALIBRATING","model_score" to r.signalQuality,"auto_expire_s" to 15,"diagnostics" to r.diagnostics));var locked=false
  val expire=Runnable{if(!locked){memory.event("SIGNAL_NOT_EXECUTED_TIMEOUT",mapOf("signal_id" to signalId,"direction" to r.direction,"expiry_s" to r.expirySeconds,"model_score" to r.signalQuality,"visible_for_s" to 15));try{manager.removeView(v)}catch(_:Throwable){};bubbles.remove(v);restack()}}
  main.postDelayed(expire,15000L)
  v.setOnClickListener{if(locked)return@setOnClickListener;locked=true;main.removeCallbacks(expire);val started=SystemClock.elapsedRealtime();memory.event("TRADE_USER_OPENED",mapOf("signal_id" to signalId,"direction" to r.direction,"expiry_s" to r.expirySeconds,"model_score" to r.signalQuality));fun tick(){val remain=(r.expirySeconds*1000-(SystemClock.elapsedRealtime()-started)).coerceAtLeast(0);if(remain>0){v.text="$arrow ${r.direction} · $percentText\nLOCKED · ${remain/60000}:${((remain/1000)%60).toString().padStart(2,'0')}";main.postDelayed({tick()},250)}else showResultButtons(v,r,signalId)};tick()}
 }
 private fun showResultButtons(old:TextView,r:SignalResult,signalId:String){val manager=wm?:return;val lp=old.layoutParams as WindowManager.LayoutParams;try{manager.removeView(old)}catch(_:Throwable){};bubbles.remove(old);val row=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;background=glass();setPadding(8,6,8,6)};fun btn(t:String){row.addView(Button(this).apply{text=t;textSize=10f;setOnClickListener{memory.event("TRADE_RESULT",mapOf("signal_id" to signalId,"result" to t,"direction" to r.direction,"expiry_s" to r.expirySeconds,"model_score" to r.signalQuality));try{manager.removeView(row)}catch(_:Throwable){};bubbles.remove(row);restack()}})};btn("WIN");btn("LOSS");btn("VOID");manager.addView(row,lp);bubbles+=row;restack();memory.event("RESULT_REQUESTED",mapOf("signal_id" to signalId,"direction" to r.direction,"expiry_s" to r.expirySeconds,"model_score" to r.signalQuality))}
 private fun restack(){bubbles.forEachIndexed{i,v->try{val lp=v.layoutParams as WindowManager.LayoutParams;lp.y=dp(120)+i*dp(52);wm?.updateViewLayout(v,lp)}catch(_:Throwable){}}}
 private fun channel(){if(Build.VERSION.SDK_INT>=26)getSystemService(NotificationManager::class.java).createNotificationChannel(NotificationChannel(CHANNEL,"Live Signal 7.1 Memory",NotificationManager.IMPORTANCE_LOW))}
 override fun onDestroy(){memory.event("SESSION_STOP");reader?.setOnImageAvailableListener(null,null);display?.release();reader?.close();try{projection?.stop()}catch(_:Throwable){};worker.shutdownNow();evidenceWorker.shutdown();main.post{try{brain?.let{wm?.removeView(it)}}catch(_:Throwable){};bubbles.toList().forEach{try{wm?.removeView(it)}catch(_:Throwable){}}};super.onDestroy()}
 override fun onBind(i:Intent?):IBinder?=null
}
